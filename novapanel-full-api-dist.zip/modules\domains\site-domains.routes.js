import { DomainsService } from './domains.service.js';
import { WebsitesService } from '../websites/websites.service.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { AppError } from '../../errors.js';
import { eq } from 'drizzle-orm';
import { db } from '../../db/index.js';
import { domains, subdomains, addonDomains } from '../../db/schema/domains.js';
import { websites } from '../../db/schema/websites.js';
// Zod schemas for validation
import { z } from 'zod';
const createSubdomainSchema = z.object({
    name: z.string().min(1).max(255),
    documentRoot: z.string().optional(),
    phpVersion: z.string().optional(),
    websiteId: z.string().optional(), // If creating subdomain as a separate site
});
const createAddonDomainSchema = z.object({
    name: z.string().min(1).max(255),
    documentRoot: z.string().min(1),
    cnameAlias: z.string().optional(),
    createAssociatedSite: z.boolean().default(true),
});
const createAliasSchema = z.object({
    alias: z.string().min(1).max(255),
});
const createRedirectSchema = z.object({
    sourcePath: z.string().min(1),
    targetUrl: z.string().min(1),
    type: z.enum(['301', '302']).default('301'),
});
export default async function siteDomainsRoutes(fastify) {
    const domainsService = new DomainsService();
    const websitesService = new WebsitesService();
    // All routes require authentication
    fastify.addHook('preHandler', requireAuth);
    // GET /api/v1/sites/:siteId/domains — List all domain info for a site
    fastify.get('/', async (req) => {
        const { siteId } = req.params;
        // Get all domains associated with this site
        const siteDomains = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        const primaryDomain = siteDomains.find(d => d.type === 'primary');
        // Get primary domain info
        let primaryDomainData = null;
        if (primaryDomain) {
            primaryDomainData = {
                ...primaryDomain,
                subdomains: await domainsService.listSubdomains(primaryDomain.id),
                aliases: await domainsService.listAliases(primaryDomain.id),
                redirects: await domainsService.listRedirects(primaryDomain.id),
            };
        }
        // Get subdomains for this site that are attached to different websites
        const siteSubs = await db.select({
            sub: subdomains,
            parentDomain: domains,
        })
            .from(subdomains)
            .leftJoin(domains, eq(subdomains.domainId, domains.id))
            .where(eq(subdomains.websiteId, siteId));
        // Get addon domains for this site
        const siteAddonDomains = await db.select().from(addonDomains).where(eq(addonDomains.siteId, siteId));
        // Get site info
        const [site] = await db.select().from(websites).where(eq(websites.id, siteId));
        if (!site) {
            throw new AppError(404, 'SITE_NOT_FOUND', `Site ${siteId} not found`);
        }
        return {
            success: true,
            data: {
                site,
                primaryDomain: primaryDomainData,
                subdomains: siteSubs.map(s => ({
                    ...s.sub,
                    parentDomain: s.parentDomain,
                })),
                addonDomains: siteAddonDomains,
            },
        };
    });
    // GET /api/v1/sites/:siteId/domains/primary — Get primary domain for site
    fastify.get('/primary', async (req) => {
        const { siteId } = req.params;
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            return { success: true, data: null };
        }
        const fullDomain = await domainsService.get(domain.id);
        return { success: true, data: fullDomain };
    });
    // --- Subdomains ---
    // GET /api/v1/sites/:siteId/domains/subdomains — List subdomains for site
    fastify.get('/subdomains', async (req) => {
        const { siteId } = req.params;
        // Get all subdomains attached to this site
        const siteSubs = await db.select({
            sub: subdomains,
            parentDomain: domains,
        })
            .from(subdomains)
            .leftJoin(domains, eq(subdomains.domainId, domains.id))
            .where(eq(subdomains.websiteId, siteId));
        return {
            success: true,
            data: siteSubs.map(s => ({
                ...s.sub,
                parentDomain: s.parentDomain,
            })),
        };
    });
    // POST /api/v1/sites/:siteId/domains/subdomains — Create subdomain for site
    fastify.post('/subdomains', async (req, reply) => {
        const { siteId } = req.params;
        const data = createSubdomainSchema.parse(req.body);
        // Get the primary domain for this site
        const [primaryDomain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!primaryDomain) {
            throw new AppError(400, 'NO_PRIMARY_DOMAIN', 'Site has no primary domain. Please create a domain first.');
        }
        // Create subdomain under the primary domain
        const sub = await domainsService.createSubdomain(primaryDomain.id, {
            name: data.name,
            documentRoot: data.documentRoot,
            phpVersion: data.phpVersion,
            websiteId: data.websiteId, // If provided, subdomain will be attached to different site
        }, req.user.id, req.ip);
        return reply.status(201).send({ success: true, data: sub });
    });
    // DELETE /api/v1/sites/:siteId/domains/subdomains/:subId — Delete subdomain
    fastify.delete('/subdomains/:subId', async (req) => {
        const { siteId, subId } = req.params;
        // Verify subdomain is associated with this site
        const [sub] = await db.select().from(subdomains).where(eq(subdomains.id, subId));
        if (!sub) {
            throw new AppError(404, 'SUBDOMAIN_NOT_FOUND', 'Subdomain not found');
        }
        // Get parent domain to call deleteSubdomain
        const [parentDomain] = await db.select().from(domains).where(eq(domains.id, sub.domainId));
        if (!parentDomain) {
            throw new AppError(404, 'PARENT_DOMAIN_NOT_FOUND', 'Parent domain not found');
        }
        await domainsService.deleteSubdomain(parentDomain.id, subId, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // --- Addon Domains ---
    // GET /api/v1/sites/:siteId/domains/addon-domains — List addon domains for site
    fastify.get('/addon-domains', async (req) => {
        const { siteId } = req.params;
        const addons = await db.select().from(addonDomains).where(eq(addonDomains.siteId, siteId));
        return { success: true, data: addons };
    });
    // POST /api/v1/sites/:siteId/domains/addon-domains — Create addon domain
    fastify.post('/addon-domains', async (req, reply) => {
        const { siteId } = req.params;
        const data = createAddonDomainSchema.parse(req.body);
        // Get the site
        const [site] = await db.select().from(websites).where(eq(websites.id, siteId));
        if (!site) {
            throw new AppError(404, 'SITE_NOT_FOUND', 'Site not found');
        }
        // Create addon domain
        const addonId = require('nanoid')();
        let autoCreatedSiteId = null;
        // If creating associated site, create it now
        // Note: WebsitesService.create() auto-generates documentRoot as {siteDir}/httpdocs
        // We pass name so it creates the site with proper defaults
        if (data.createAssociatedSite) {
            const newSite = await websitesService.create({
                name: data.name,
                phpVersion: site.phpVersion,
                phpHandler: site.phpHandler,
                webServer: site.webServer,
            }, req.user.id, req.ip);
            autoCreatedSiteId = newSite.id;
        }
        await db.insert(addonDomains).values({
            id: addonId,
            siteId,
            name: data.name,
            documentRoot: data.documentRoot,
            cnameAlias: data.cnameAlias,
            autoCreatedSiteId,
            status: 'active',
        });
        const [addon] = await db.select().from(addonDomains).where(eq(addonDomains.id, addonId));
        return reply.status(201).send({ success: true, data: addon });
    });
    // DELETE /api/v1/sites/:siteId/domains/addon-domains/:addonId — Delete addon domain
    fastify.delete('/addon-domains/:addonId', async (req) => {
        const { siteId, addonId } = req.params;
        const { deleteSite = false } = req.body || {};
        const [addon] = await db.select().from(addonDomains).where(eq(addonDomains.id, addonId));
        if (!addon) {
            throw new AppError(404, 'ADDON_DOMAIN_NOT_FOUND', 'Addon domain not found');
        }
        // Optionally delete the associated site
        if (deleteSite && addon.autoCreatedSiteId) {
            // Note: This would cascade to delete the addon domain due to FK, so we delete site first
            // Actually, we need to be careful - deleting site will cascade delete addon
            // So just mark addon as deleted
        }
        await db.delete(addonDomains).where(eq(addonDomains.id, addonId));
        return { success: true, data: null };
    });
    // --- Aliases ---
    // GET /api/v1/sites/:siteId/domains/aliases — List aliases for site's primary domain
    fastify.get('/aliases', async (req) => {
        const { siteId } = req.params;
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            return { success: true, data: [] };
        }
        const aliases = await domainsService.listAliases(domain.id);
        return { success: true, data: aliases };
    });
    // POST /api/v1/sites/:siteId/domains/aliases — Create alias
    fastify.post('/aliases', async (req, reply) => {
        const { siteId } = req.params;
        const { alias } = createAliasSchema.parse(req.body);
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            throw new AppError(400, 'NO_PRIMARY_DOMAIN', 'Site has no primary domain');
        }
        const result = await domainsService.createAlias(domain.id, alias, req.user.id, req.ip);
        return reply.status(201).send({ success: true, data: result });
    });
    // DELETE /api/v1/sites/:siteId/domains/aliases/:aliasId — Delete alias
    fastify.delete('/aliases/:aliasId', async (req) => {
        const { siteId, aliasId } = req.params;
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            throw new AppError(400, 'NO_PRIMARY_DOMAIN', 'Site has no primary domain');
        }
        await domainsService.deleteAlias(domain.id, aliasId, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // --- Redirects ---
    // GET /api/v1/sites/:siteId/domains/redirects — List redirects
    fastify.get('/redirects', async (req) => {
        const { siteId } = req.params;
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            return { success: true, data: [] };
        }
        const redirects = await domainsService.listRedirects(domain.id);
        return { success: true, data: redirects };
    });
    // POST /api/v1/sites/:siteId/domains/redirects — Create redirect
    fastify.post('/redirects', async (req, reply) => {
        const { siteId } = req.params;
        const data = createRedirectSchema.parse(req.body);
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            throw new AppError(400, 'NO_PRIMARY_DOMAIN', 'Site has no primary domain');
        }
        const result = await domainsService.createRedirect(domain.id, data, req.user.id, req.ip);
        return reply.status(201).send({ success: true, data: result });
    });
    // DELETE /api/v1/sites/:siteId/domains/redirects/:redirectId — Delete redirect
    fastify.delete('/redirects/:redirectId', async (req) => {
        const { siteId, redirectId } = req.params;
        // Get primary domain
        const [domain] = await db.select().from(domains).where(eq(domains.websiteId, siteId));
        if (!domain) {
            throw new AppError(400, 'NO_PRIMARY_DOMAIN', 'Site has no primary domain');
        }
        await domainsService.deleteRedirect(domain.id, redirectId, req.user.id, req.ip);
        return { success: true, data: null };
    });
}
//# sourceMappingURL=site-domains.routes.js.map