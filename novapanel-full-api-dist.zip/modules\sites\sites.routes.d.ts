import type { FastifyInstance } from 'fastify';
export default function siteRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=sites.routes.d.ts.map