export declare class DnsService {
    getZone(domainId: string): Promise<{
        zone: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            projectId: string;
            dnssecEnabled: boolean;
            domainId: string;
            soa: unknown;
            nsRecords: unknown;
            dnssecKeys: unknown;
        };
        records: {
            value: string;
            type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            port: number | null;
            zoneId: string;
            ttl: number;
            priority: number | null;
            weight: number | null;
            proxied: boolean;
        }[];
    }>;
    ensureZone(domainId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    createRecord(domainId: string, data: {
        type: string;
        name: string;
        value: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        value: string;
        type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        port: number | null;
        zoneId: string;
        ttl: number;
        priority: number | null;
        weight: number | null;
        proxied: boolean;
    }>;
    updateRecord(recordId: string, data: {
        name?: string;
        value?: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        value: string;
        type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        port: number | null;
        zoneId: string;
        ttl: number;
        priority: number | null;
        weight: number | null;
        proxied: boolean;
    }>;
    deleteRecord(recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    importZone(domainId: string, bindFormat: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    exportZone(domainId: string): Promise<string>;
    resetToDefaults(domainId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    getRawZone(domainId: string): Promise<string>;
    checkPropagation(domainId: string): Promise<{
        checks: Array<{
            nameserver: string;
            ip: string;
            resolves: boolean;
        }>;
    }>;
    updateSoa(domainId: string, data: {
        primaryNs?: string;
        adminEmail?: string;
        refresh?: number;
        retry?: number;
        expire?: number;
        minimumTtl?: number;
    }, userId?: string, ipAddress?: string): Promise<any>;
    getCloudflareConfig(domainId: string): Promise<{
        enabled: boolean;
        apiToken: string;
        zoneId: string;
        zoneName: string;
        lastSyncAt: null;
    }>;
    updateCloudflareConfig(domainId: string, data: {
        enabled?: boolean;
        apiToken?: string;
        zoneId?: string;
        zoneName?: string;
    }): Promise<{
        enabled: boolean;
        apiToken: string;
        zoneId: string;
        zoneName: string;
        lastSyncAt: null;
    }>;
    syncCloudflareRecords(domainId: string): Promise<{
        synced: boolean;
        recordsProcessed: number;
        message: string;
    }>;
    deleteZone(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    syncZoneToDisk(_zoneId: string): Promise<void>;
    private syncRecordToCloudflare;
}
export declare const dnsService: DnsService;
//# sourceMappingURL=dns.service.d.ts.map