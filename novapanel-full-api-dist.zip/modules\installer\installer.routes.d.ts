import type { FastifyInstance } from 'fastify';
export default function installerRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=installer.routes.d.ts.map