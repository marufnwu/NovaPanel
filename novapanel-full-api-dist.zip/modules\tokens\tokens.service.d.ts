interface ValidateTokenResult {
    valid: boolean;
    user?: {
        id: string;
    };
    token?: {
        id: string;
        permissions: string;
    };
}
export declare class TokensService {
    createToken(userId: string, name: string, expiresAt?: Date, ipAddress?: string): Promise<{
        key: string;
        name: string;
        expiresAt: Date | undefined;
    }>;
    listTokens(userId: string): Promise<{
        id: string;
        name: string;
        keyPrefix: string;
        createdAt: Date;
        expiresAt: Date | null;
    }[]>;
    revokeToken(tokenId: string, userId: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    validateToken(token: string): Promise<ValidateTokenResult | null>;
}
export declare const tokensService: TokensService;
export {};
//# sourceMappingURL=tokens.service.d.ts.map