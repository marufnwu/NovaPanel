import { NginxRenderer, SiteModel } from './types.js';
export declare class DefaultNginxRenderer implements NginxRenderer {
    private readonly NGINX_SITES_AVAILABLE;
    constructor();
    getConfigPath(siteId: string): string;
    render(_model: SiteModel): string;
    validate(_config: string): Promise<boolean>;
}
export declare const nginxRenderer: DefaultNginxRenderer;
//# sourceMappingURL=nginx.renderer.d.ts.map