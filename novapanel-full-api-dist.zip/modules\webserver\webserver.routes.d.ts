import type { FastifyInstance } from 'fastify';
export default function webServerRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=webserver.routes.d.ts.map