import type { FastifyInstance } from 'fastify';
export default function fileRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=files.routes.d.ts.map