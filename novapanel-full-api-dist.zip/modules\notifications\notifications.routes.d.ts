import type { FastifyInstance } from 'fastify';
export default function notificationsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=notifications.routes.d.ts.map