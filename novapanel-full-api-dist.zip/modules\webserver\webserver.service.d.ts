export declare class WebServerService {
    applyWebsiteConfig(_websiteId: string): Promise<void>;
    removeWebsiteConfig(_websiteId: string): Promise<void>;
    getConfig(domainId: string): Promise<string>;
    getConfigByName(domainName: string): Promise<string>;
    updateConfig(domainId: string, _userId: string | undefined, data: any): Promise<string>;
    updateConfigByName(domainName: string, userId: string | undefined, data: any): Promise<string>;
    previewConfig(domainId: string): Promise<string>;
    testConfig(_domainId: string): Promise<{
        valid: boolean;
        output: string;
    }>;
    listDomains(): Promise<{
        id: string;
        name: string;
        siteId: string | null;
        status: "active" | "suspended" | "pending";
    }[]>;
    getErrorPages(_domainName: string): Promise<never[]>;
    updateErrorPages(_domainName: string, _errorPages: any[], _userId?: string): Promise<{
        success: boolean;
    }>;
    getRateLimitConfig(_domainName: string): Promise<{
        enabled: boolean;
        requestsPerSecond: number;
        burstSize: number;
        timeoutSeconds: number;
    }>;
    updateRateLimitConfig(_domainName: string, _data: any, _userId?: string): Promise<{
        success: boolean;
    }>;
}
export declare const webServerService: WebServerService;
//# sourceMappingURL=webserver.service.d.ts.map