export declare class DeploymentService {
    getDeployments(_siteId: string): Promise<void>;
    getDeployment(_id: string): Promise<void>;
    getCurrentDeployment(_siteId: string): Promise<void>;
    create(_data: any): Promise<void>;
    build(_data: any): Promise<void>;
    deploy(_deploymentId: string): Promise<void>;
    rollback(_siteId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    deleteDeployment(_id: string): Promise<void>;
}
export declare const deploymentService: DeploymentService;
//# sourceMappingURL=deployment.service.d.ts.map