import { logger } from '../../config/logger.js';
const activeLogSessions = new Map();
export async function registerTunnelLogsWs(fastify) {
    // @ts-ignore — @fastify/websocket augments FastifyInstance with websocket route handler
    fastify.get('/ws/tunnel/logs', { websocket: true }, async (socket, req) => {
        logger.info({ url: req.url }, 'WebSocket connection to tunnel logs');
    });
}
//# sourceMappingURL=tunnel.ws.js.map