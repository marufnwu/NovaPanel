import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';
import { projects } from './projects.js';
export const sites = sqliteTable('sites', {
    id: text('id').primaryKey(),
    projectId: text('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
    name: text('name').notNull(),
    slug: text('slug').notNull(),
    description: text('description'),
    runtime: text('runtime', { enum: ['docker', 'node', 'python', 'php', 'go', 'ruby', 'rust', 'static'] }).notNull(),
    runtimeVersion: text('runtime_version'),
    sourceType: text('source_type', { enum: ['git', 'docker_registry', 'upload', 'empty'] }).default('empty').notNull(),
    gitRepo: text('git_repo'),
    gitBranch: text('git_branch').default('main'),
    gitWebhookSecret: text('git_webhook_secret'),
    buildCommand: text('build_command'),
    outputDirectory: text('output_directory').default('dist'),
    installCommand: text('install_command'),
    startCommand: text('start_command'),
    port: integer('port'),
    replicas: integer('replicas').default(1).notNull(),
    autoRestart: integer('auto_restart', { mode: 'boolean' }).default(true).notNull(),
    memoryLimit: integer('memory_limit'),
    cpuLimit: integer('cpu_limit'),
    status: text('status', { enum: ['active', 'building', 'deploying', 'error', 'suspended'] }).default('active').notNull(),
    healthCheckPath: text('health_check_path').default('/health'),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull().default(sql `(unixepoch())`),
    updatedAt: integer('updated_at', { mode: 'timestamp' }),
});
//# sourceMappingURL=sites_v5.js.map