export declare class RegistriesService {
    list(orgId?: string): Promise<{
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        password: string | null;
        provider: "dockerhub" | "ghcr" | "ecr" | "gcr" | "selfhosted";
        url: string | null;
    }[]>;
    get(id: string): Promise<{
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        password: string | null;
        provider: "dockerhub" | "ghcr" | "ecr" | "gcr" | "selfhosted";
        url: string | null;
    }>;
    create(data: {
        orgId: string;
        name: string;
        provider: 'dockerhub' | 'ghcr' | 'ecr' | 'gcr' | 'selfhosted';
        url?: string;
        username?: string;
        password?: string;
    }): Promise<{
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        password: string | null;
        provider: "dockerhub" | "ghcr" | "ecr" | "gcr" | "selfhosted";
        url: string | null;
    }>;
    update(id: string, data: Partial<{
        name: string;
        url: string;
        username: string;
        password: string;
    }>): Promise<{
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        password: string | null;
        provider: "dockerhub" | "ghcr" | "ecr" | "gcr" | "selfhosted";
        url: string | null;
    }>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
}
export declare const registriesService: RegistriesService;
//# sourceMappingURL=registries.service.d.ts.map