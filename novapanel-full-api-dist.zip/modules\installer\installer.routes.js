import { installerService } from './installer.service.js';
import { requireAuth } from '../auth/auth.middleware.js';
export default async function installerRoutes(fastify) {
    fastify.addHook('preHandler', requireAuth);
    fastify.get('/installer/apps', async () => {
        return { success: true, data: await installerService.getAvailableApps() };
    });
    fastify.get('/installer/apps/:id', async (req) => {
        const { id } = req.params;
        return { success: true, data: await installerService.getApp(id) };
    });
}
//# sourceMappingURL=installer.routes.js.map