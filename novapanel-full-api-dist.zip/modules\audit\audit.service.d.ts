interface AuditLogInput {
    orgId?: string;
    projectId?: string;
    actorType?: 'user' | 'api_key' | 'system';
    actorId?: string;
    action: string;
    resourceType?: string;
    resourceId?: string;
    metadata?: string;
    ipAddress?: string;
    userAgent?: string;
    userId?: string;
    resource?: string;
    details?: string;
}
export declare class AuditService {
    log(data: AuditLogInput): Promise<void>;
    list(filters: {
        orgId?: string;
        projectId?: string;
        actorType?: string;
        action?: string;
        resourceType?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        id: string;
        createdAt: Date;
        userAgent: string | null;
        ipAddress: string | null;
        orgId: string;
        projectId: string | null;
        resourceType: string;
        resourceId: string | null;
        action: string;
        actorType: "user" | "api_key" | "system";
        actorId: string;
        metadata: unknown;
    }[]>;
}
export declare const auditService: AuditService;
export {};
//# sourceMappingURL=audit.service.d.ts.map