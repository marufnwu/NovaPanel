import { z } from 'zod';
export declare const createBackupSchema: z.ZodEffects<z.ZodObject<{
    type: z.ZodDefault<z.ZodEnum<["full", "files", "database", "dns", "mail", "config"]>>;
    /** Enable encryption for the backup */
    encryptionEnabled: z.ZodDefault<z.ZodBoolean>;
    /** Password used to encrypt the backup (required if encryptionEnabled is true) */
    encryptionPassword: z.ZodOptional<z.ZodString>;
    /** Encryption algorithm */
    encryptionAlgorithm: z.ZodDefault<z.ZodEnum<["aes-256-cbc", "aes-256-gcm"]>>;
}, "strip", z.ZodTypeAny, {
    type: "config" | "database" | "full" | "dns" | "files" | "mail";
    encryptionEnabled: boolean;
    encryptionAlgorithm: "aes-256-gcm" | "aes-256-cbc";
    encryptionPassword?: string | undefined;
}, {
    type?: "config" | "database" | "full" | "dns" | "files" | "mail" | undefined;
    encryptionEnabled?: boolean | undefined;
    encryptionPassword?: string | undefined;
    encryptionAlgorithm?: "aes-256-gcm" | "aes-256-cbc" | undefined;
}>, {
    type: "config" | "database" | "full" | "dns" | "files" | "mail";
    encryptionEnabled: boolean;
    encryptionAlgorithm: "aes-256-gcm" | "aes-256-cbc";
    encryptionPassword?: string | undefined;
}, {
    type?: "config" | "database" | "full" | "dns" | "files" | "mail" | undefined;
    encryptionEnabled?: boolean | undefined;
    encryptionPassword?: string | undefined;
    encryptionAlgorithm?: "aes-256-gcm" | "aes-256-cbc" | undefined;
}>;
export declare const restoreBackupSchema: z.ZodObject<{
    files: z.ZodDefault<z.ZodBoolean>;
    databases: z.ZodDefault<z.ZodBoolean>;
    dns: z.ZodDefault<z.ZodBoolean>;
    /** Password to decrypt the backup (required if backup is encrypted) */
    encryptionPassword: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    databases: boolean;
    dns: boolean;
    files: boolean;
    encryptionPassword?: string | undefined;
}, {
    databases?: boolean | undefined;
    dns?: boolean | undefined;
    files?: boolean | undefined;
    encryptionPassword?: string | undefined;
}>;
export declare const createScheduleSchema: z.ZodEffects<z.ZodObject<{
    cronExpression: z.ZodDefault<z.ZodString>;
    scope: z.ZodDefault<z.ZodString>;
    retentionCount: z.ZodDefault<z.ZodNumber>;
    storageType: z.ZodDefault<z.ZodEnum<["local", "s3", "sftp", "b2"]>>;
    storageConfig: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    /** Enable encryption for scheduled backups */
    encryptionEnabled: z.ZodDefault<z.ZodBoolean>;
    /** Password used to encrypt scheduled backups (required if encryptionEnabled is true) */
    encryptionPassword: z.ZodOptional<z.ZodString>;
    /** Encryption algorithm */
    encryptionAlgorithm: z.ZodDefault<z.ZodEnum<["aes-256-cbc", "aes-256-gcm"]>>;
}, "strip", z.ZodTypeAny, {
    scope: string;
    cronExpression: string;
    encryptionEnabled: boolean;
    encryptionAlgorithm: "aes-256-gcm" | "aes-256-cbc";
    retentionCount: number;
    storageType: "local" | "s3" | "b2" | "sftp";
    encryptionPassword?: string | undefined;
    storageConfig?: Record<string, string> | undefined;
}, {
    scope?: string | undefined;
    cronExpression?: string | undefined;
    encryptionEnabled?: boolean | undefined;
    encryptionPassword?: string | undefined;
    encryptionAlgorithm?: "aes-256-gcm" | "aes-256-cbc" | undefined;
    retentionCount?: number | undefined;
    storageType?: "local" | "s3" | "b2" | "sftp" | undefined;
    storageConfig?: Record<string, string> | undefined;
}>, {
    scope: string;
    cronExpression: string;
    encryptionEnabled: boolean;
    encryptionAlgorithm: "aes-256-gcm" | "aes-256-cbc";
    retentionCount: number;
    storageType: "local" | "s3" | "b2" | "sftp";
    encryptionPassword?: string | undefined;
    storageConfig?: Record<string, string> | undefined;
}, {
    scope?: string | undefined;
    cronExpression?: string | undefined;
    encryptionEnabled?: boolean | undefined;
    encryptionPassword?: string | undefined;
    encryptionAlgorithm?: "aes-256-gcm" | "aes-256-cbc" | undefined;
    retentionCount?: number | undefined;
    storageType?: "local" | "s3" | "b2" | "sftp" | undefined;
    storageConfig?: Record<string, string> | undefined;
}>;
export declare const updateStorageConfigSchema: z.ZodObject<{
    type: z.ZodEnum<["local", "s3", "sftp", "b2"]>;
    s3: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    sftp: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, "strip", z.ZodTypeAny, {
    type: "local" | "s3" | "b2" | "sftp";
    s3?: Record<string, string> | undefined;
    sftp?: Record<string, string> | undefined;
}, {
    type: "local" | "s3" | "b2" | "sftp";
    s3?: Record<string, string> | undefined;
    sftp?: Record<string, string> | undefined;
}>;
//# sourceMappingURL=backup.schema.d.ts.map