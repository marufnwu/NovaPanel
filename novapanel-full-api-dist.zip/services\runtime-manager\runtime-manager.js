import { AppError } from '../../errors.js';
const EPHEMERAL_PORT_START = 30000;
const EPHEMERAL_PORT_END = 40000;
const RUNTIME_INFO = {
    php: { runtime: 'php', version: '8.2' },
    node: { runtime: 'node', version: '20' },
    python: { runtime: 'python', version: '3.11' },
    static: { runtime: 'static', version: 'n/a' },
};
export class RuntimeManager {
    async getRuntime(_siteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Runtime manager not yet migrated to v5 schema');
    }
    async createRuntime(_siteId, _config) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Runtime manager not yet migrated to v5 schema');
    }
    async updateRuntime(_siteId, _config) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Runtime manager not yet migrated to v5 schema');
    }
    async allocatePort(_siteId) {
        return Math.floor(Math.random() * (EPHEMERAL_PORT_END - EPHEMERAL_PORT_START)) + EPHEMERAL_PORT_START;
    }
    async ensureRuntimeInstalled(_siteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Runtime manager not yet migrated to v5 schema');
    }
    validateConfig(_config) {
        return { valid: true, errors: [] };
    }
    parseRuntimeConfig(_runtime) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Runtime manager not yet migrated to v5 schema');
    }
}
export const runtimeManager = new RuntimeManager();
//# sourceMappingURL=runtime-manager.js.map