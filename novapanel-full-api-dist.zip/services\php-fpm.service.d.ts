import type { SystemService, ServiceInfo } from './types.js';
export declare class PhpFpmService implements SystemService {
    private version;
    constructor(version: string);
    readonly name: string;
    readonly displayName: string;
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    static getInstalledVersions(): Promise<string[]>;
    static generateWebsitePool(_siteId: string): Promise<void>;
    static removeWebsitePool(_siteId: string): Promise<void>;
    static reloadPhpFpm(_phpVersion: string): Promise<void>;
    private getPoolDir;
    createPool(_domain: string, _systemUser: string, _documentRoot: string): Promise<void>;
    deletePool(_domain: string): Promise<void>;
}
export declare const phpFpmServices: {
    '8.1': PhpFpmService;
    '8.2': PhpFpmService;
    '8.3': PhpFpmService;
    '8.4': PhpFpmService;
};
//# sourceMappingURL=php-fpm.service.d.ts.map