import type { FastifyInstance } from 'fastify';
export declare function registerTunnelLogsWs(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=tunnel.ws.d.ts.map