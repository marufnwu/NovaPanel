export declare class ProjectsService {
    listByOrg(orgId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        settings: unknown;
        orgId: string;
        description: string | null;
        environment: "development" | "production" | "staging";
    }[]>;
    get(id: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        settings: unknown;
        orgId: string;
        description: string | null;
        environment: "development" | "production" | "staging";
    }>;
    create(data: {
        name: string;
        slug: string;
        orgId: string;
        environment?: 'production' | 'staging' | 'development';
    }, _userId?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        settings: unknown;
        orgId: string;
        description: string | null;
        environment: "development" | "production" | "staging";
    }>;
    update(id: string, data: {
        name?: string;
        environment?: 'production' | 'staging' | 'development';
    }): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        settings: unknown;
        orgId: string;
        description: string | null;
        environment: "development" | "production" | "staging";
    }>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
}
export declare const projectsService: ProjectsService;
//# sourceMappingURL=projects.service.d.ts.map