import type { FastifyInstance } from 'fastify';
export declare function registerTerminalWs(fastify: FastifyInstance): Promise<void>;
export declare function cleanupStaleSessions(): void;
//# sourceMappingURL=terminal.ws.d.ts.map