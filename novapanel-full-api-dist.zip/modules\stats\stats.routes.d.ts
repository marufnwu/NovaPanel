import type { FastifyInstance } from 'fastify';
export default function statsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=stats.routes.d.ts.map