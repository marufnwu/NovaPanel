import { run } from './executor.js';
import { logger } from '../config/logger.js';
/**
 * Escape a string for safe interpolation into SQL single-quoted values.
 * Replaces ' → '' and \ → \\
 */
function escapeSqlString(val) {
    return val.replace(/\\/g, '\\\\').replace(/'/g, "''");
}
export class MariaDbService {
    name = 'mariadb';
    displayName = 'MariaDB';
    async start() {
        await run('systemctl', ['start', 'mariadb'], { sudo: true });
    }
    async stop() {
        await run('systemctl', ['stop', 'mariadb'], { sudo: true });
    }
    async restart() {
        await run('systemctl', ['restart', 'mariadb'], { sudo: true });
    }
    async reload() {
        await run('systemctl', ['reload', 'mariadb'], { sudo: true });
    }
    async status() {
        const result = await run('systemctl', ['is-active', 'mariadb'], { sudo: true });
        const status = result.stdout.trim() === 'active' ? 'running' : 'stopped';
        return { name: this.name, displayName: this.displayName, status };
    }
    async isInstalled() {
        const result = await run('which', ['mysql']);
        return result.success;
    }
    /**
     * Create a database
     */
    async createDatabase(name) {
        await run('mysql', ['-u', 'root', '-e', `CREATE DATABASE \`${name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`], { sudo: true });
        logger.info({ database: name }, 'MariaDB database created');
    }
    /**
     * Drop a database
     */
    async dropDatabase(name) {
        await run('mysql', ['-u', 'root', '-e', `DROP DATABASE IF EXISTS \`${name}\`;`], { sudo: true });
        logger.info({ database: name }, 'MariaDB database dropped');
    }
    /**
     * Create a database user
     */
    async createUser(username, password, host = 'localhost') {
        await run('mysql', ['-u', 'root', '-e', `CREATE USER '${escapeSqlString(username)}'@'${escapeSqlString(host)}' IDENTIFIED BY '${escapeSqlString(password)}';`], { sudo: true });
        logger.info({ username, host }, 'MariaDB user created');
    }
    /**
     * Grant privileges to a user on a database
     */
    async grantPrivileges(username, database, host = 'localhost') {
        await run('mysql', ['-u', 'root', '-e', `GRANT ALL PRIVILEGES ON \`${database}\`.* TO '${escapeSqlString(username)}'@'${escapeSqlString(host)}'; FLUSH PRIVILEGES;`], { sudo: true });
        logger.info({ username, database }, 'MariaDB privileges granted');
    }
    /**
     * Drop a user
     */
    async dropUser(username, host = 'localhost') {
        await run('mysql', ['-u', 'root', '-e', `DROP USER IF EXISTS '${escapeSqlString(username)}'@'${escapeSqlString(host)}'; FLUSH PRIVILEGES;`], { sudo: true });
        logger.info({ username }, 'MariaDB user dropped');
    }
    /**
     * Dump a database to SQL
     */
    async dumpDatabase(name, outputPath) {
        await run('mysqldump', ['-u', 'root', name], { sudo: true });
        logger.info({ database: name, outputPath }, 'MariaDB database dumped');
    }
    /**
     * Change a user's password
     */
    async changePassword(username, password, host = 'localhost') {
        await run('mysql', ['-u', 'root', '-e', `ALTER USER '${escapeSqlString(username)}'@'${escapeSqlString(host)}' IDENTIFIED BY '${escapeSqlString(password)}'; FLUSH PRIVILEGES;`], { sudo: true });
        logger.info({ username }, 'MariaDB user password changed');
    }
    /**
     * Export a database to SQL string
     */
    async exportDatabase(name) {
        const result = await run('mysqldump', ['-u', 'root', name], { sudo: true });
        return result.stdout;
    }
    /**
     * Import SQL into a database
     */
    async importDatabase(name, sql) {
        const { writeFile: writeTmp, unlink } = await import('node:fs/promises');
        const tmpPath = `/tmp/sf_import_${Date.now()}.sql`;
        await writeTmp(tmpPath, sql, 'utf-8');
        await run('mysql', ['-u', 'root', name, '-e', `source ${tmpPath}`], { sudo: true });
        await unlink(tmpPath).catch(() => { });
        logger.info({ database: name }, 'MariaDB database imported');
    }
    /**
     * Get database size in bytes
     */
    async getDatabaseSize(name) {
        const result = await run('mysql', ['-u', 'root', '-N', '-e',
            `SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.tables WHERE table_schema = '${escapeSqlString(name)}';`
        ], { sudo: true });
        const size = parseInt(result.stdout.trim(), 10);
        return isNaN(size) ? 0 : size;
    }
    /**
     * Repair database tables
     */
    async repairDatabase(name) {
        const result = await run('mysqlcheck', ['-u', 'root', '--repair', name], { sudo: true });
        return { success: result.success, output: result.stdout };
    }
    /**
     * Optimize database tables
     */
    async optimizeDatabase(name) {
        const result = await run('mysqlcheck', ['-u', 'root', '--optimize', name], { sudo: true });
        return { success: result.success, output: result.stdout };
    }
    /**
     * Clone database to a new name
     */
    async cloneDatabase(sourceName, targetName) {
        const dumpResult = await run('mysqldump', ['-u', 'root', sourceName], { sudo: true });
        await run('mysql', ['-u', 'root', '-e', `CREATE DATABASE IF NOT EXISTS \`${targetName}\`;`], { sudo: true });
        await run('mysql', ['-u', 'root', targetName], { sudo: true, input: dumpResult.stdout });
        logger.info({ source: sourceName, target: targetName }, 'MariaDB database cloned');
    }
    /**
     * Run a read-only SQL query.
     * Omits -N so the first row of output contains column headers.
     */
    async runQuery(name, sql) {
        const result = await run('mysql', ['-u', 'root', '-e', sql, name], { sudo: true });
        const lines = result.stdout.split('\n').filter(l => l.trim());
        if (lines.length === 0)
            return { columns: [], rows: [], rowCount: 0 };
        // First line is column headers (tab-separated)
        const columns = lines[0].split('\t');
        const rows = lines.slice(1).map(line => {
            const values = line.split('\t');
            const obj = {};
            columns.forEach((col, i) => { obj[col] = values[i] ?? null; });
            return obj;
        });
        return { columns, rows, rowCount: rows.length };
    }
}
export const mariadbService = new MariaDbService();
//# sourceMappingURL=mariadb.service.js.map