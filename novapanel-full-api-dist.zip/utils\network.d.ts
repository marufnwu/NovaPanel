/**
 * Network detection result
 */
export interface NetworkInfo {
    localIps: string[];
    hasPublicIp: boolean;
    publicIp: string | null;
    primaryIp: string;
}
/**
 * Detect network information for this server
 * Results are cached for 5 minutes to avoid excessive external calls
 */
export declare function detectNetworkInfo(): Promise<NetworkInfo>;
/**
 * Check if a URL contains a private IP address
 */
export declare function isPrivateUrl(urlString: string): boolean;
/**
 * Parse PANEL_URL and determine if it's private
 */
export declare function getPanelUrlInfo(): {
    panelUrl: string;
    panelUrlIsPrivate: boolean;
};
/**
 * DNS verification result
 */
export interface DnsVerificationResult {
    domain: string;
    resolvesTo: string[];
    pointsToServer: boolean;
    serverIp: string;
    error?: string;
}
/**
 * Verify that a domain's A record(s) point to a specific IP address.
 * Used to verify domain ownership before attachment.
 */
export declare function verifyDomainPointsToIp(domain: string, targetIp: string): Promise<DnsVerificationResult>;
/**
 * Get nameservers for a domain by querying NS records
 */
export declare function getDomainNameservers(domain: string): Promise<string[]>;
//# sourceMappingURL=network.d.ts.map