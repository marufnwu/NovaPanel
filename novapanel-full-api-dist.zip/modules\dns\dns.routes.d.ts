import type { FastifyInstance } from 'fastify';
export default function dnsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=dns.routes.d.ts.map