export declare class OrganizationsService {
    listByUser(userId: string): Promise<{
        role: "member" | "owner" | "admin" | "billing";
        joinedAt: Date;
        status: "active" | "suspended" | "cancelled";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        plan: "free" | "starter" | "pro" | "enterprise";
        settings: unknown;
        quotas: unknown;
        branding: unknown;
    }[]>;
    get(id: string, userId?: string): Promise<{
        status: "active" | "suspended" | "cancelled";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        plan: "free" | "starter" | "pro" | "enterprise";
        settings: unknown;
        quotas: unknown;
        branding: unknown;
    } | {
        role: "member" | "owner" | "admin" | "billing";
        status: "active" | "suspended" | "cancelled";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        plan: "free" | "starter" | "pro" | "enterprise";
        settings: unknown;
        quotas: unknown;
        branding: unknown;
    } | null>;
    create(data: {
        name: string;
        slug: string;
    }, userId: string): Promise<{
        status: "active" | "suspended" | "cancelled";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        plan: "free" | "starter" | "pro" | "enterprise";
        settings: unknown;
        quotas: unknown;
        branding: unknown;
    }>;
    update(id: string, data: {
        name?: string;
        plan?: 'free' | 'starter' | 'pro' | 'enterprise';
        status?: 'active' | 'suspended' | 'cancelled';
    }): Promise<{
        status: "active" | "suspended" | "cancelled";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        plan: "free" | "starter" | "pro" | "enterprise";
        settings: unknown;
        quotas: unknown;
        branding: unknown;
    }>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
    listMembers(orgId: string): Promise<{
        id: string;
        role: "member" | "owner" | "admin" | "billing";
        permissions: unknown;
        joinedAt: Date;
        userId: string;
        username: string;
        email: string;
        displayName: string | null;
    }[]>;
    inviteMember(orgId: string, email: string, role: string, invitedBy: string): Promise<{
        success: boolean;
    }>;
    removeMember(orgId: string, userId: string): Promise<{
        success: boolean;
    }>;
    updateMemberRole(orgId: string, userId: string, role: string): Promise<{
        success: boolean;
    }>;
}
export declare const organizationsService: OrganizationsService;
//# sourceMappingURL=organizations.service.d.ts.map