interface ListOptions {
    page?: number;
    perPage?: number;
    search?: string;
    siteId?: string;
    type?: string;
}
interface ListResult {
    items: any[];
    total: number;
    page: number;
    perPage: number;
}
export declare class DomainsService {
    list(options?: ListOptions): Promise<ListResult>;
    get(id: string): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }>;
    create(data: {
        name: string;
        siteId?: string;
        type?: string;
        projectId?: string;
        userId?: string;
        ipAddress?: string;
    }): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }>;
    update(id: string, data: {
        name?: string;
        sslStatus?: string;
        forceHttps?: boolean;
        hstsEnabled?: boolean;
        proxyEnabled?: boolean;
        sslAutoRenew?: boolean;
        customNginxConfig?: string;
        status?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }>;
    delete(id: string, userId?: string, ipAddress?: string): Promise<void>;
    makePrimary(_domainId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    listSubdomains(_domainId: string): Promise<never[]>;
    createSubdomain(_domainId: string, _data: {
        name: string;
        documentRoot?: string;
        sslEnabled?: boolean;
    }): Promise<void>;
    deleteSubdomain(_domainId: string, _subdomainId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    verifyDomain(id: string, userId?: string, ipAddress?: string): Promise<{
        verified: boolean;
        domain: string;
        zoneId: string;
    } | {
        verified: boolean;
        domain: string;
        zoneId?: undefined;
    }>;
    getDomainSsl(domainId: string): Promise<{
        enabled: boolean;
        certificate: import("../ssl/ssl.service.js").CertInfo | null;
    }>;
    enableAutoSsl(domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    disableAutoSsl(domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    requestSsl(domainId: string, type: string, userId?: string, ipAddress?: string): Promise<import("../ssl/ssl.service.js").CertInfo>;
    renewSsl(domainId: string, userId?: string, ipAddress?: string): Promise<import("../ssl/ssl.service.js").CertInfo>;
    deleteSsl(domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    downloadSslCert(domainId: string): Promise<string>;
    checkPropagation(id: string): Promise<{
        checks: Array<{
            nameserver: string;
            ip: string;
            resolves: boolean;
        }>;
    }>;
    getDnsSettings(id: string): Promise<{
        zoneId: string;
        zoneName: string;
        dnssecEnabled: boolean;
        soa: unknown;
    }>;
    updateDnsSettings(_id: string, _data: {
        primaryDns?: string;
        secondaryDns?: string;
    }): Promise<{
        success: boolean;
    }>;
    getNameservers(id: string): Promise<{
        nameservers: {};
        zoneName: string;
    }>;
    getCloudflareStatus(id: string): Promise<{
        enabled: boolean;
        status: string;
    }>;
    enableCloudflare(id: string, data: {
        enabled?: boolean;
        proxyEnabled?: boolean;
        sslMode?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
        proxyEnabled: boolean;
    }>;
    disableCloudflare(id: string, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
    }>;
    getZone(id: string): Promise<{
        zone: {
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            projectId: string;
            dnssecEnabled: boolean;
            domainId: string;
            soa: unknown;
            nsRecords: unknown;
            dnssecKeys: unknown;
        };
        records: {
            value: string;
            type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            port: number | null;
            zoneId: string;
            ttl: number;
            priority: number | null;
            weight: number | null;
            proxied: boolean;
        }[];
    }>;
    createZone(id: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    deleteZone(id: string, userId?: string, ipAddress?: string): Promise<void>;
    listZoneRecords(id: string): Promise<{
        value: string;
        type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        port: number | null;
        zoneId: string;
        ttl: number;
        priority: number | null;
        weight: number | null;
        proxied: boolean;
    }[]>;
    createZoneRecord(domainId: string, data: {
        type: string;
        name: string;
        value: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        value: string;
        type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        port: number | null;
        zoneId: string;
        ttl: number;
        priority: number | null;
        weight: number | null;
        proxied: boolean;
    }>;
    updateZoneRecord(_zoneId: string, recordId: string, data: {
        name?: string;
        value?: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        value: string;
        type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        port: number | null;
        zoneId: string;
        ttl: number;
        priority: number | null;
        weight: number | null;
        proxied: boolean;
    }>;
    deleteZoneRecord(_zoneId: string, recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    importZoneRecords(domainId: string, bindFormat: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    exportZoneRecords(domainId: string): Promise<string>;
    resetZoneToDefaults(domainId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        dnssecEnabled: boolean;
        domainId: string;
        soa: unknown;
        nsRecords: unknown;
        dnssecKeys: unknown;
    }>;
    updateSoa(domainId: string, data: {
        primaryNs?: string;
        adminEmail?: string;
        refresh?: number;
        retry?: number;
        expire?: number;
        minimumTtl?: number;
    }, userId?: string, ipAddress?: string): Promise<any>;
    syncCloudflare(domainId: string): Promise<{
        synced: boolean;
        recordsProcessed: number;
        message: string;
    }>;
    listBySite(siteId: string): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }[]>;
    suspend(id: string, userId?: string, ipAddress?: string): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }>;
    unsuspend(id: string, userId?: string, ipAddress?: string): Promise<{
        type: "apex" | "subdomain" | "wildcard";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        siteId: string | null;
        dnsZoneId: string | null;
        nameservers: unknown;
        dnssecEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
        sslCertId: string | null;
        sslAutoRenew: boolean;
        forceHttps: boolean;
        hstsEnabled: boolean;
        proxyEnabled: boolean;
        customNginxConfig: string | null;
    }>;
}
export declare const domainsService: DomainsService;
export {};
//# sourceMappingURL=domains.service.d.ts.map