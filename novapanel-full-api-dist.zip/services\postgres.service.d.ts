import type { SystemService, ServiceInfo } from './types.js';
export declare class PostgresService implements SystemService {
    readonly name = "postgresql";
    readonly displayName = "PostgreSQL";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    createDatabase(name: string): Promise<void>;
    dropDatabase(name: string): Promise<void>;
    createUser(username: string, password: string): Promise<void>;
    dropUser(username: string): Promise<void>;
    grantPrivileges(username: string, database: string): Promise<void>;
    /**
     * Change a user's password
     */
    changePassword(username: string, password: string): Promise<void>;
    /**
     * Export a database to SQL string
     */
    exportDatabase(name: string): Promise<string>;
    /**
     * Import SQL into a database
     */
    importDatabase(name: string, sql: string): Promise<void>;
    /**
     * Get database size in bytes
     */
    getDatabaseSize(name: string): Promise<number>;
    /**
     * Repair is not applicable for PostgreSQL (VACUUM reclaims space)
     */
    repairDatabase(name: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Optimize database (VACUUM FULL to reclaim space)
     */
    optimizeDatabase(name: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Clone database using pg_dump + createdb + psql
     */
    cloneDatabase(sourceName: string, targetName: string): Promise<void>;
    /**
     * Run a read-only SQL query (SELECT, SHOW, DESCRIBE)
     * Returns proper column names by omitting -t flag and disabling footer.
     */
    runQuery(name: string, sql: string): Promise<{
        columns: string[];
        rows: Record<string, unknown>[];
        rowCount: number;
    }>;
}
export declare const postgresService: PostgresService;
//# sourceMappingURL=postgres.service.d.ts.map