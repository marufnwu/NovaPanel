export { RuntimeManager, runtimeManager } from './runtime-manager.js';
//# sourceMappingURL=index.js.map