import { run } from './executor.js';
import { logger } from '../config/logger.js';
import { env } from '../config/env.js';
import * as sudoFs from './sudo-fs.js';
export class BindService {
    name = 'bind9';
    displayName = 'BIND9';
    namedConfLocal = '/etc/bind/named.conf.local';
    async start() {
        await run('systemctl', ['start', 'named'], { sudo: true });
    }
    async stop() {
        await run('systemctl', ['stop', 'named'], { sudo: true });
    }
    async restart() {
        await run('systemctl', ['restart', 'named'], { sudo: true });
    }
    async reload() {
        await run('rndc', ['reload'], { sudo: true });
    }
    async status() {
        const result = await run('systemctl', ['is-active', 'named'], { sudo: true });
        const status = result.stdout.trim() === 'active' ? 'running' : 'stopped';
        return { name: this.name, displayName: this.displayName, status };
    }
    async isInstalled() {
        const result = await run('which', ['rndc']);
        return result.success;
    }
    /**
     * Check a zone file for syntax errors
     */
    async checkZone(zoneName, zoneFile) {
        const result = await run('named-checkzone', [zoneName, zoneFile], { sudo: true });
        return {
            valid: result.exitCode === 0,
            output: result.stdout,
        };
    }
    /**
     * Write a zone file to disk and reload BIND
     */
    async writeZoneFile(domain, content) {
        const zonesDir = env.BIND_ZONES_DIR;
        await sudoFs.mkdir(zonesDir);
        const zonePath = `${zonesDir}/db.${domain}`;
        await sudoFs.writeFile(zonePath, content);
        // Reload BIND to pick up changes
        await this.reload();
        logger.info({ domain }, 'BIND zone file written');
    }
    /**
     * Remove a zone file from disk.
     */
    async removeZoneFile(domain) {
        const zonePath = `${env.BIND_ZONES_DIR}/db.${domain}`;
        await sudoFs.unlink(zonePath).catch(() => { });
        logger.info({ domain }, 'BIND zone file removed');
    }
    /**
     * Add a zone declaration to named.conf.local so BIND serves the zone.
     * Idempotent — does nothing if the zone block already exists.
     */
    async addZoneToConfig(domain) {
        try {
            const content = await sudoFs.readFile(this.namedConfLocal);
            // Check if zone already exists in config
            const escapedDomain = domain.replace(/\./g, '\\.');
            const zoneRegex = new RegExp(`zone\\s+"${escapedDomain}\\.?"\\s*\\{`);
            if (zoneRegex.test(content)) {
                logger.debug({ domain }, 'Zone already in named.conf.local — skipping');
                return;
            }
        }
        catch {
            // named.conf.local doesn't exist yet — we'll create it below
        }
        const zoneBlock = `
zone "${domain}" {
    type master;
    file "${env.BIND_ZONES_DIR}/db.${domain}";
};
`;
        await sudoFs.appendFile(this.namedConfLocal, zoneBlock);
        logger.info({ domain }, 'Zone added to named.conf.local');
    }
    /**
     * Remove a zone declaration from named.conf.local.
     */
    async removeZoneFromConfig(domain) {
        try {
            const content = await sudoFs.readFile(this.namedConfLocal);
            const escapedDomain = domain.replace(/\./g, '\\.');
            const zoneBlockRegex = new RegExp(`\\s*zone\\s+"${escapedDomain}\\.?"\\s*\\{[^}]*\\};?\\s*`, 'g');
            const updated = content.replace(zoneBlockRegex, '\n');
            await sudoFs.writeFile(this.namedConfLocal, updated);
            logger.info({ domain }, 'Zone removed from named.conf.local');
        }
        catch {
            // named.conf.local may not exist or zone block not found
        }
    }
    /**
     * Reload BIND via systemctl (alternative to rndc reload).
     */
    async reloadBind() {
        await run('systemctl', ['reload', 'bind9'], { sudo: true }).catch(() => {
            // Fallback to restart if reload fails
            return run('systemctl', ['restart', 'bind9'], { sudo: true });
        });
        logger.info('BIND reloaded via systemctl');
    }
}
export const bindService = new BindService();
//# sourceMappingURL=bind.service.js.map