import { z } from 'zod';
export declare const createFtpAccountSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    homeDir: z.ZodString;
    readonly: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    username: string;
    password: string;
    homeDir: string;
    readonly: boolean;
}, {
    username: string;
    password: string;
    homeDir: string;
    readonly?: boolean | undefined;
}>;
export declare const updateFtpAccountSchema: z.ZodObject<{
    password: z.ZodOptional<z.ZodString>;
    homeDir: z.ZodOptional<z.ZodString>;
    readonly: z.ZodOptional<z.ZodBoolean>;
    isActive: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    isActive?: boolean | undefined;
    password?: string | undefined;
    homeDir?: string | undefined;
    readonly?: boolean | undefined;
}, {
    isActive?: boolean | undefined;
    password?: string | undefined;
    homeDir?: string | undefined;
    readonly?: boolean | undefined;
}>;
//# sourceMappingURL=ftp.schema.d.ts.map