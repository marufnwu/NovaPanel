import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
declare const loginSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    rememberMe: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    username: string;
    rememberMe: boolean;
    password: string;
}, {
    username: string;
    password: string;
    rememberMe?: boolean | undefined;
}>;
declare const generateApiTokenSchema: z.ZodObject<{
    name: z.ZodString;
    expiresAt: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    expiresAt?: string | undefined;
}, {
    name: string;
    expiresAt?: string | undefined;
}>;
export { loginSchema, generateApiTokenSchema };
export default function authRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=auth.routes.d.ts.map