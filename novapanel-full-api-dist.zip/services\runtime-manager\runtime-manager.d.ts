export declare class RuntimeManager {
    getRuntime(_siteId: string): Promise<void>;
    createRuntime(_siteId: string, _config: any): Promise<void>;
    updateRuntime(_siteId: string, _config: any): Promise<void>;
    allocatePort(_siteId: string): Promise<number>;
    ensureRuntimeInstalled(_siteId: string): Promise<boolean>;
    validateConfig(_config: any): {
        valid: boolean;
        errors: string[];
    };
    parseRuntimeConfig(_runtime: any): any;
}
export declare const runtimeManager: RuntimeManager;
//# sourceMappingURL=runtime-manager.d.ts.map