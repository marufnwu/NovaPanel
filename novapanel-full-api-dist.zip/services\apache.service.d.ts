import type { SystemService, ServiceInfo } from './types.js';
export declare class ApacheService implements SystemService {
    readonly name = "apache2";
    readonly displayName = "Apache";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    testConfig(): Promise<{
        valid: boolean;
        output: string;
    }>;
    enableSite(site: string): Promise<void>;
    disableSite(site: string): Promise<void>;
    enableModule(module: string): Promise<void>;
    disableModule(module: string): Promise<void>;
    /**
     * Remove an Apache virtual host configuration
     */
    removeVhost(domain: string): Promise<void>;
}
export declare const apacheService: ApacheService;
//# sourceMappingURL=apache.service.d.ts.map