export interface ServerFeatures {
    nginx: boolean;
    apache: boolean;
    mysql: boolean;
    postgresql: boolean;
    postfix: boolean;
    ftp: boolean;
    docker: boolean;
}
/**
 * Detect which server features are available by checking if binaries exist in PATH.
 */
export declare function detectServerFeatures(): Promise<ServerFeatures>;
//# sourceMappingURL=features.service.d.ts.map