export {};
//# sourceMappingURL=plugins.service.test.d.ts.map