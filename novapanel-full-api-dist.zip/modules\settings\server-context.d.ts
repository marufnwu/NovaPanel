import type { FastifyInstance } from 'fastify';
export interface ServerContext {
    localIps: string[];
    hasPublicIp: boolean;
    publicIp: string | null;
    primaryIp: string;
    nameservers: {
        ns1: string;
        ns2: string;
    };
    panelUrl: string;
    panelUrlIsPrivate: boolean;
    tunnelConfigured: boolean;
    tunnelActive: boolean;
    tunnelUrl: string | null;
    canIssueHttpSsl: boolean;
    canReceiveExternalMail: boolean;
    canServePublicDns: boolean;
}
export declare function getServerContext(): Promise<ServerContext>;
export default function serverContextRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=server-context.d.ts.map