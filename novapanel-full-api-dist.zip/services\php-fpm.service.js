import { run } from './executor.js';
import { env } from '../config/env.js';
export class PhpFpmService {
    version;
    constructor(version) {
        this.version = version;
        this.name = `php${version}-fpm`;
        this.displayName = `PHP ${version} FPM`;
    }
    name;
    displayName;
    async start() {
        await run('systemctl', ['start', this.name], { sudo: true });
    }
    async stop() {
        await run('systemctl', ['stop', this.name], { sudo: true });
    }
    async restart() {
        await run('systemctl', ['restart', this.name], { sudo: true });
    }
    async reload() {
        await run('systemctl', ['reload', this.name], { sudo: true });
    }
    async status() {
        const result = await run('systemctl', ['is-active', this.name], { sudo: true });
        const status = result.stdout.trim() === 'active' ? 'running' : 'stopped';
        return { name: this.name, displayName: this.displayName, status, version: this.version };
    }
    async isInstalled() {
        const result = await run('which', [this.name]);
        return result.success;
    }
    static async getInstalledVersions() {
        try {
            const result = await run('ls', ['-1', '/etc/php/'], { sudo: true });
            if (result.success && result.stdout.trim()) {
                const dirs = result.stdout.trim().split('\n').filter(Boolean);
                const versions = dirs
                    .map(d => d.trim())
                    .filter(d => /^\d+\.\d+$/.test(d))
                    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
                if (versions.length > 0)
                    return versions;
            }
        }
        catch { }
        const versions = [];
        for (const v of ['7.4', '8.0', '8.1', '8.2', '8.3', '8.4']) {
            const service = new PhpFpmService(v);
            if (await service.isInstalled())
                versions.push(v);
        }
        return versions;
    }
    static async generateWebsitePool(_siteId) {
    }
    static async removeWebsitePool(_siteId) {
    }
    static async reloadPhpFpm(_phpVersion) {
    }
    getPoolDir() {
        return env.PHP_FPM_POOL_DIR.replace('{version}', this.version);
    }
    async createPool(_domain, _systemUser, _documentRoot) {
    }
    async deletePool(_domain) {
    }
}
export const phpFpmServices = {
    '8.1': new PhpFpmService('8.1'),
    '8.2': new PhpFpmService('8.2'),
    '8.3': new PhpFpmService('8.3'),
    '8.4': new PhpFpmService('8.4'),
};
//# sourceMappingURL=php-fpm.service.js.map