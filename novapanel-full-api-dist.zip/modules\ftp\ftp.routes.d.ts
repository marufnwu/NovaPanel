import type { FastifyInstance } from 'fastify';
export default function ftpRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=ftp.routes.d.ts.map