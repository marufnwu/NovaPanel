import { db } from '../../db/index.js';
import { databases, databaseUsers } from '../../db/schema/index.js';
import { eq } from 'drizzle-orm';
import { nanoid } from 'nanoid';
import { AppError } from '../../errors.js';
export class DatabasesService {
    async list(projectId) {
        const items = await db.select().from(databases).where(projectId ? eq(databases.projectId, projectId) : undefined);
        return { items, total: items.length };
    }
    async get(id) {
        const [database] = await db.select().from(databases).where(eq(databases.id, id)).limit(1);
        if (!database)
            throw new AppError(404, 'DATABASE_NOT_FOUND', 'Database not found');
        return database;
    }
    async create(data) {
        const [database] = await db.insert(databases).values({
            id: nanoid(),
            projectId: data.projectId,
            name: data.name,
            type: data.type,
            version: data.version || null,
            host: data.host || 'localhost',
            port: data.port || null,
            databaseName: data.databaseName || null,
            username: data.username || null,
            password: data.password || null,
            backupsEnabled: data.backupsEnabled ?? true,
            backupSchedule: data.backupSchedule || '0 2 * * *',
            publicAccess: data.publicAccess ?? false,
            status: 'creating',
        }).returning();
        return database;
    }
    async update(id, data) {
        const updateData = { updatedAt: new Date() };
        if (data.name !== undefined)
            updateData.name = data.name;
        if (data.backupsEnabled !== undefined)
            updateData.backupsEnabled = data.backupsEnabled;
        if (data.backupSchedule !== undefined)
            updateData.backupSchedule = data.backupSchedule;
        if (data.publicAccess !== undefined)
            updateData.publicAccess = data.publicAccess;
        if (data.status !== undefined)
            updateData.status = data.status;
        const [updated] = await db.update(databases).set(updateData).where(eq(databases.id, id)).returning();
        return updated;
    }
    async delete(id) {
        await db.delete(databaseUsers).where(eq(databaseUsers.databaseId, id));
        await db.delete(databases).where(eq(databases.id, id));
        return { success: true };
    }
    async start(id) {
        const [updated] = await db.update(databases).set({ status: 'running', updatedAt: new Date() }).where(eq(databases.id, id)).returning();
        if (!updated)
            throw new AppError(404, 'NOT_FOUND', 'Database not found');
        return updated;
    }
    async stop(id) {
        const [updated] = await db.update(databases).set({ status: 'stopped', updatedAt: new Date() }).where(eq(databases.id, id)).returning();
        if (!updated)
            throw new AppError(404, 'NOT_FOUND', 'Database not found');
        return updated;
    }
    async restart(id) {
        const [updated] = await db.update(databases).set({ status: 'running', updatedAt: new Date() }).where(eq(databases.id, id)).returning();
        if (!updated)
            throw new AppError(404, 'NOT_FOUND', 'Database not found');
        return updated;
    }
    async listUsers(databaseId) {
        return db.select().from(databaseUsers).where(eq(databaseUsers.databaseId, databaseId));
    }
    async createUser(data) {
        const [user] = await db.insert(databaseUsers).values({
            id: nanoid(),
            databaseId: data.databaseId,
            username: data.username,
            password: data.password || null,
            privileges: JSON.stringify(data.privileges || []),
        }).returning();
        return user;
    }
    async deleteUser(id) {
        await db.delete(databaseUsers).where(eq(databaseUsers.id, id));
        return { success: true };
    }
    async updateUserPrivileges(id, privileges) {
        const [updated] = await db.update(databaseUsers).set({ privileges: JSON.stringify(privileges) }).where(eq(databaseUsers.id, id)).returning();
        return updated;
    }
}
export const databasesService = new DatabasesService();
//# sourceMappingURL=databases.service.js.map