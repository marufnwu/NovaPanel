import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';
import { sites } from './sites_v5.js';
export const deployments = sqliteTable('deployments', {
    id: text('id').primaryKey(),
    siteId: text('site_id').notNull().references(() => sites.id, { onDelete: 'cascade' }),
    sequence: integer('sequence').notNull(),
    sourceType: text('source_type', { enum: ['git', 'docker_registry', 'upload', 'rollback'] }),
    gitRef: text('git_ref'),
    commitSha: text('commit_sha'),
    commitMessage: text('commit_message'),
    status: text('status', { enum: ['pending', 'building', 'testing', 'deploying', 'success', 'failed', 'cancelled'] }).default('pending').notNull(),
    buildLogs: text('build_logs'),
    deployLogs: text('deploy_logs'),
    deployedAt: integer('deployed_at', { mode: 'timestamp' }),
    durationMs: integer('duration_ms'),
    errorMessage: text('error_message'),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull().default(sql `(unixepoch())`),
});
//# sourceMappingURL=deployments_v5.js.map