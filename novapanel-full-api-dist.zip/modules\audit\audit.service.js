import { db } from '../../db/index.js';
import { auditLogs } from '../../db/schema/audit.js';
import { eq, desc, and } from 'drizzle-orm';
import { nanoid } from 'nanoid';
export class AuditService {
    async log(data) {
        await db.insert(auditLogs).values({
            id: nanoid(),
            orgId: data.orgId || data.actorId || '',
            projectId: data.projectId || null,
            actorType: data.actorType || 'user',
            actorId: data.actorId || data.userId || '',
            action: data.action,
            resourceType: data.resourceType || data.resource || '',
            resourceId: data.resourceId || null,
            metadata: data.metadata || data.details || null,
            ipAddress: data.ipAddress || null,
            userAgent: data.userAgent || null,
        });
    }
    async list(filters) {
        const limit = filters.limit || 50;
        const offset = filters.offset || 0;
        const conditions = [];
        if (filters.orgId) {
            conditions.push(eq(auditLogs.orgId, filters.orgId));
        }
        if (filters.projectId) {
            conditions.push(eq(auditLogs.projectId, filters.projectId));
        }
        const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
        return db.select().from(auditLogs)
            .where(whereClause)
            .orderBy(desc(auditLogs.createdAt))
            .limit(limit)
            .offset(offset);
    }
}
export const auditService = new AuditService();
//# sourceMappingURL=audit.service.js.map