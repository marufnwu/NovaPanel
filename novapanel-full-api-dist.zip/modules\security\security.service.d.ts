import { type WafRule, type NewWafRule, type IpAllowlist, type NewIpAllowlist } from '../../db/schema/security.js';
export declare class SecurityService {
    listWafRules(projectId: string): Promise<WafRule[]>;
    createWafRule(projectId: string, data: Omit<NewWafRule, 'id' | 'projectId' | 'createdAt'>): Promise<WafRule>;
    updateWafRule(id: string, data: Partial<Pick<WafRule, 'name' | 'type' | 'enabled' | 'priority' | 'config'>>): Promise<WafRule>;
    deleteWafRule(id: string): Promise<void>;
    listIpAllowlists(projectId: string): Promise<IpAllowlist[]>;
    createIpAllowlist(projectId: string, data: Omit<NewIpAllowlist, 'id' | 'projectId' | 'createdAt'>): Promise<IpAllowlist>;
    updateIpAllowlist(id: string, data: Partial<Pick<IpAllowlist, 'name' | 'ips' | 'type'>>): Promise<IpAllowlist>;
    deleteIpAllowlist(id: string): Promise<void>;
}
export declare const securityService: SecurityService;
//# sourceMappingURL=security.service.d.ts.map