import { env } from '../../config/env.js';
export class DefaultNginxRenderer {
    NGINX_SITES_AVAILABLE;
    constructor() {
        this.NGINX_SITES_AVAILABLE = env.NGINX_SITES_AVAILABLE || '/etc/nginx/sites-available';
    }
    getConfigPath(siteId) {
        return `${this.NGINX_SITES_AVAILABLE}/site-${siteId}.conf`;
    }
    render(_model) {
        return '';
    }
    async validate(_config) {
        return true;
    }
}
export const nginxRenderer = new DefaultNginxRenderer();
//# sourceMappingURL=nginx.renderer.js.map