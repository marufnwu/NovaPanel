import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';
export const sslCertificates = sqliteTable('ssl_certificates', {
    id: text('id').primaryKey(),
    domainId: text('domain_id').notNull().references(() => domains_v5.id, { onDelete: 'cascade' }),
    type: text('type', { enum: ['letsencrypt', 'zerossl', 'google', 'custom', 'self_signed'] }).notNull(),
    certPem: text('cert_pem'),
    keyPem: text('key_pem'),
    chainPem: text('chain_pem'),
    issuedAt: integer('issued_at', { mode: 'timestamp' }),
    expiresAt: integer('expires_at', { mode: 'timestamp' }),
    autoRenew: integer('auto_renew', { mode: 'boolean' }).default(true).notNull(),
    renewalDaysBeforeExpiry: integer('renewal_days').default(14).notNull(),
    status: text('status', { enum: ['active', 'pending', 'expired', 'revoked', 'error'] }).default('pending').notNull(),
    lastError: text('last_error'),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull().default(sql `(unixepoch())`),
    updatedAt: integer('updated_at', { mode: 'timestamp' }),
});
//# sourceMappingURL=ssl_certificates_v5.js.map