export declare class StatsService {
    getServerStats(): Promise<ServerStats>;
    collectAndStore(stats: ServerStats): Promise<void>;
    getDiskDetails(): Promise<DiskMount[]>;
    getServiceStatuses(): Promise<ServiceStatusItem[]>;
    restartService(serviceName: string, userId?: string): Promise<{
        success: boolean;
        log?: string;
    }>;
    getDomainStats(domainId: string): Promise<DomainStats>;
    getNetworkStats(): Promise<NetworkStats>;
    getDashboardSummary(): Promise<DashboardSummary>;
    getExpiringSslCerts(_days?: number): Promise<ExpiringSslCert[]>;
    getProcessList(sortBy?: 'cpu' | 'memory', limit?: number): Promise<ProcessInfo[]>;
    getTcpConnections(): Promise<TcpConnectionStats | null>;
    getFdStats(): Promise<FdStats | null>;
    getDiskIOStats(): Promise<DiskIOStats | null>;
    getDomainBandwidth(): Promise<DomainBandwidthStats[]>;
}
export interface ServerStats {
    cpu: {
        usage: number;
        cores: number;
    };
    memory: {
        total: number;
        used: number;
        available: number;
        cached: number;
        buffered: number;
        swapTotal: number;
        swapUsed: number;
        usagePercent: number;
    };
    disk: {
        total: number;
        used: number;
        available: number;
        usagePercent: number;
        mount: string;
    };
    uptime: number;
    loadAvg: number[];
    system: {
        hostname: string;
        os: string;
        kernel: string;
        arch: string;
        ips: string[];
    };
}
export interface DiskMount {
    fs: string;
    mount: string;
    total: number;
    used: number;
    available: number;
    usagePercent: number;
}
export interface ServiceStatusItem {
    name: string;
    displayName: string;
    status: 'running' | 'stopped' | 'error';
}
export interface DomainStats {
    domainId: string;
    domainName: string;
    diskUsedMb: number;
    status: string;
    sslEnabled: boolean;
    phpVersion: string;
}
export interface NetworkStats {
    interface: string;
    rxBytes: number;
    txBytes: number;
    rxSec: number;
    txSec: number;
}
export interface DashboardSummary {
    totalDomains: number;
    activeDomains: number;
    suspendedDomains: number;
    sslEnabledDomains: number;
    totalMailboxes: number;
    totalDatabases: number;
    totalFtpAccounts: number;
    totalActiveCronJobs: number;
    expiringSslCerts: number;
}
export interface ExpiringSslCert {
    id: string;
    domainId: string;
    domainName: string;
    issuer: string;
    expiresAt: string;
    daysUntilExpiry: number;
}
export interface ProcessInfo {
    pid: number;
    name: string;
    cpu: number;
    memory: number;
    state: string;
}
export interface TcpConnectionStats {
    established: number;
    timeWait: number;
    closeWait: number;
    total: number;
}
export interface FdStats {
    openFd: number;
    maxFd: number;
    usagePercent: number;
}
export interface DiskIOStats {
    readBytesSec: number;
    writeBytesSec: number;
    readOpsSec: number;
    writeOpsSec: number;
}
export interface DomainBandwidthStats {
    domainId: string;
    domainName: string;
    incomingBytes: number;
    outgoingBytes: number;
    totalBytes: number;
}
//# sourceMappingURL=stats.service.d.ts.map