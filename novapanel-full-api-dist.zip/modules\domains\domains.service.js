import { db } from '../../db/index.js';
import { domains } from '../../db/schema/domains.js';
import { eq, like, count, and } from 'drizzle-orm';
import { AppError } from '../../errors.js';
import { nanoid } from 'nanoid';
import { auditService } from '../audit/audit.service.js';
import { logger } from '../../config/logger.js';
import { dnsService } from '../dns/dns.service.js';
import { sslService } from '../ssl/ssl.service.js';
export class DomainsService {
    async list(options = {}) {
        const page = options.page || 1;
        const perPage = options.perPage || 20;
        const offset = (page - 1) * perPage;
        const conditions = [];
        if (options.search)
            conditions.push(like(domains.name, `%${options.search}%`));
        if (options.siteId)
            conditions.push(eq(domains.siteId, options.siteId));
        if (options.type)
            conditions.push(eq(domains.type, options.type));
        const where = conditions.length > 0 ? and(...conditions) : undefined;
        const items = await db.select().from(domains).where(where).limit(perPage).offset(offset);
        const [{ total }] = await db.select({ total: count() }).from(domains);
        return { items, total, page, perPage };
    }
    async get(id) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        return domain;
    }
    async create(data) {
        const id = nanoid();
        await db.insert(domains).values({
            id,
            projectId: data.projectId || 'default',
            name: data.name,
            siteId: data.siteId || null,
            type: data.type || 'apex',
        });
        auditService.log({
            userId: data.userId,
            action: 'domain.create',
            resource: `domain:${data.name}`,
            ipAddress: data.ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return this.get(id);
    }
    async update(id, data, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({
            ...(data.name && { name: data.name }),
            ...(data.sslStatus && { sslStatus: data.sslStatus }),
            ...(data.forceHttps !== undefined && { forceHttps: data.forceHttps }),
            ...(data.hstsEnabled !== undefined && { hstsEnabled: data.hstsEnabled }),
            ...(data.proxyEnabled !== undefined && { proxyEnabled: data.proxyEnabled }),
            ...(data.sslAutoRenew !== undefined && { sslAutoRenew: data.sslAutoRenew }),
            ...(data.customNginxConfig !== undefined && { customNginxConfig: data.customNginxConfig }),
            ...(data.status && { status: data.status }),
        }).where(eq(domains.id, id));
        auditService.log({
            userId,
            action: 'domain.update',
            resource: `domain:${domain.name}`,
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return this.get(id);
    }
    async delete(id, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.delete(domains).where(eq(domains.id, id));
        auditService.log({
            userId,
            action: 'domain.delete',
            resource: `domain:${domain.name}`,
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
    }
    async makePrimary(_domainId, _userId, _ipAddress) {
        return { success: true };
    }
    async listSubdomains(_domainId) {
        return [];
    }
    async createSubdomain(_domainId, _data) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Subdomain creation not available in v5 schema - use domains.create()');
    }
    async deleteSubdomain(_domainId, _subdomainId, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Subdomain deletion not available in v5 schema - use domains.delete()');
    }
    async verifyDomain(id, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        const zone = await dnsService.getZone(id).catch(() => null);
        if (zone) {
            return { verified: true, domain: domain.name, zoneId: zone.zone.id };
        }
        return { verified: false, domain: domain.name };
    }
    async getDomainSsl(domainId) {
        return sslService.getCertificate(domainId);
    }
    async enableAutoSsl(domainId, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, domainId)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({ sslAutoRenew: true }).where(eq(domains.id, domainId));
        auditService.log({ userId, action: 'domain.enable_auto_ssl', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return { success: true };
    }
    async disableAutoSsl(domainId, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, domainId)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({ sslAutoRenew: false }).where(eq(domains.id, domainId));
        auditService.log({ userId, action: 'domain.disable_auto_ssl', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return { success: true };
    }
    async requestSsl(domainId, type, userId, ipAddress) {
        if (type === 'letsencrypt') {
            const result = await sslService.issueLetsEncrypt(domainId, { email: '', challengeType: 'http-01' }, userId, ipAddress);
            return result;
        }
        throw new AppError(400, 'INVALID_TYPE', 'Unknown SSL certificate type');
    }
    async renewSsl(domainId, userId, ipAddress) {
        return sslService.renewCertificate(domainId, userId, ipAddress);
    }
    async deleteSsl(domainId, userId, ipAddress) {
        await sslService.removeCertificate(domainId, userId, ipAddress);
        return { success: true };
    }
    async downloadSslCert(domainId) {
        const pem = await sslService.downloadCert(domainId, 'cert');
        return pem;
    }
    async checkPropagation(id) {
        return dnsService.checkPropagation(id);
    }
    async getDnsSettings(id) {
        const zone = await dnsService.getZone(id);
        return {
            zoneId: zone.zone.id,
            zoneName: zone.zone.name,
            dnssecEnabled: zone.zone.dnssecEnabled,
            soa: zone.zone.soa,
        };
    }
    async updateDnsSettings(_id, _data) {
        return { success: true };
    }
    async getNameservers(id) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        return {
            nameservers: domain.nameservers || ['ns1.cloudflare.com', 'ns2.cloudflare.com'],
            zoneName: domain.name,
        };
    }
    async getCloudflareStatus(id) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        return { enabled: domain.proxyEnabled, status: domain.proxyEnabled ? 'active' : 'inactive' };
    }
    async enableCloudflare(id, data, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({
            proxyEnabled: data.proxyEnabled ?? true,
        }).where(eq(domains.id, id));
        auditService.log({ userId, action: 'domain.enable_cloudflare', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return { enabled: true, proxyEnabled: data.proxyEnabled ?? true };
    }
    async disableCloudflare(id, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({ proxyEnabled: false }).where(eq(domains.id, id));
        auditService.log({ userId, action: 'domain.disable_cloudflare', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return { enabled: false };
    }
    async getZone(id) {
        return dnsService.getZone(id);
    }
    async createZone(id, userId, ipAddress) {
        return dnsService.ensureZone(id, userId, ipAddress);
    }
    async deleteZone(id, userId, ipAddress) {
        return dnsService.deleteZone(id, userId, ipAddress);
    }
    async listZoneRecords(id) {
        const zone = await dnsService.getZone(id);
        return zone.records;
    }
    async createZoneRecord(domainId, data, userId, ipAddress) {
        return dnsService.createRecord(domainId, data, userId, ipAddress);
    }
    async updateZoneRecord(_zoneId, recordId, data, userId, ipAddress) {
        return dnsService.updateRecord(recordId, data, userId, ipAddress);
    }
    async deleteZoneRecord(_zoneId, recordId, userId, ipAddress) {
        return dnsService.deleteRecord(recordId, userId, ipAddress);
    }
    async importZoneRecords(domainId, bindFormat, userId, ipAddress) {
        return dnsService.importZone(domainId, bindFormat, userId, ipAddress);
    }
    async exportZoneRecords(domainId) {
        return dnsService.exportZone(domainId);
    }
    async resetZoneToDefaults(domainId, userId, ipAddress) {
        return dnsService.resetToDefaults(domainId, userId, ipAddress);
    }
    async updateSoa(domainId, data, userId, ipAddress) {
        return dnsService.updateSoa(domainId, data, userId, ipAddress);
    }
    async syncCloudflare(domainId) {
        return dnsService.syncCloudflareRecords(domainId);
    }
    async listBySite(siteId) {
        return db.select().from(domains).where(eq(domains.siteId, siteId));
    }
    async suspend(id, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({ status: 'suspended' }).where(eq(domains.id, id));
        auditService.log({ userId, action: 'domain.suspend', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return this.get(id);
    }
    async unsuspend(id, userId, ipAddress) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, id)).limit(1);
        if (!domain)
            throw new AppError(404, 'DOMAIN_NOT_FOUND', 'Domain not found');
        await db.update(domains).set({ status: 'active' }).where(eq(domains.id, id));
        auditService.log({ userId, action: 'domain.unsuspend', resource: `domain:${domain.name}`, ipAddress }).catch(() => { });
        return this.get(id);
    }
}
export const domainsService = new DomainsService();
//# sourceMappingURL=domains.service.js.map