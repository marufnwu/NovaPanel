import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';
import { projects } from './projects.js';
export const domains = sqliteTable('domains', {
    id: text('id').primaryKey(),
    projectId: text('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
    siteId: text('site_id').references(() => sites_v5.id),
    name: text('name').notNull(),
    type: text('type', { enum: ['apex', 'subdomain', 'wildcard'] }).default('apex').notNull(),
    dnsZoneId: text('dns_zone_id'),
    nameservers: text('nameservers', { mode: 'json' }),
    dnssecEnabled: integer('dnssec_enabled', { mode: 'boolean' }).default(false).notNull(),
    sslStatus: text('ssl_status', { enum: ['pending', 'active', 'expired', 'error'] }).default('pending').notNull(),
    sslCertId: text('ssl_cert_id'),
    sslAutoRenew: integer('ssl_auto_renew', { mode: 'boolean' }).default(true).notNull(),
    forceHttps: integer('force_https', { mode: 'boolean' }).default(true).notNull(),
    hstsEnabled: integer('hsts_enabled', { mode: 'boolean' }).default(false).notNull(),
    proxyEnabled: integer('proxy_enabled', { mode: 'boolean' }).default(true).notNull(),
    customNginxConfig: text('custom_nginx_config'),
    status: text('status', { enum: ['active', 'suspended', 'pending'] }).default('active').notNull(),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull().default(sql `(unixepoch())`),
    updatedAt: integer('updated_at', { mode: 'timestamp' }),
});
//# sourceMappingURL=domains_v5.js.map