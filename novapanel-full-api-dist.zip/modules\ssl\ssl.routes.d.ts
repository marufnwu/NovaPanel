import type { FastifyInstance } from 'fastify';
export default function sslRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=ssl.routes.d.ts.map