import type { FastifyInstance } from 'fastify';
export default function websiteRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=websites.routes.d.ts.map