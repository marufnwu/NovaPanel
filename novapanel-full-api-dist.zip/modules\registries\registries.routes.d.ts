import type { FastifyInstance } from 'fastify';
export default function registryRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=registries.routes.d.ts.map