import type { FastifyInstance } from 'fastify';
export default function siteDomainsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=site-domains.routes.d.ts.map