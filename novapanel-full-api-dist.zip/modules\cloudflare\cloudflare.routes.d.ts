import type { FastifyInstance } from 'fastify';
export default function cloudflareRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=cloudflare.routes.d.ts.map