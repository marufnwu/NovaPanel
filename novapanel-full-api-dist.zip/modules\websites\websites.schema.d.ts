import { z } from 'zod';
export declare const createWebsiteSchema: z.ZodObject<{
    name: z.ZodString;
    phpVersion: z.ZodDefault<z.ZodString>;
    phpHandler: z.ZodDefault<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodDefault<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
}, "strip", z.ZodTypeAny, {
    name: string;
    phpVersion: string;
    phpHandler: "php-fpm" | "cgi" | "disabled";
    webServer: "nginx" | "apache" | "nginx+apache";
}, {
    name: string;
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
}>;
export declare const updateWebsiteSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
    phpHandler: z.ZodOptional<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodOptional<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
}, {
    name?: string | undefined;
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
}>;
export declare const attachDomainSchema: z.ZodObject<{
    domainId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domainId: string;
}, {
    domainId: string;
}>;
export declare const detachDomainSchema: z.ZodObject<{
    domainId: z.ZodString;
    action: z.ZodDefault<z.ZodEnum<["redirect", "parked", "delete"]>>;
}, "strip", z.ZodTypeAny, {
    domainId: string;
    action: "parked" | "redirect" | "delete";
}, {
    domainId: string;
    action?: "parked" | "redirect" | "delete" | undefined;
}>;
export type CreateWebsiteInput = z.infer<typeof createWebsiteSchema>;
export type UpdateWebsiteInput = z.infer<typeof updateWebsiteSchema>;
export type AttachDomainInput = z.infer<typeof attachDomainSchema>;
export type DetachDomainInput = z.infer<typeof detachDomainSchema>;
//# sourceMappingURL=websites.schema.d.ts.map