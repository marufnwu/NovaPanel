import type { FastifyInstance } from 'fastify';
export default function webhooksRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=webhooks.routes.d.ts.map