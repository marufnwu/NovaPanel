import type { FastifyInstance } from 'fastify';
export default function cronRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=cron.routes.d.ts.map