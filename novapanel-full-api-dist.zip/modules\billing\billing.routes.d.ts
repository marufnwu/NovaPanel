import type { FastifyInstance } from 'fastify';
export default function billingRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=billing.routes.d.ts.map