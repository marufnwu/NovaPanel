export declare class DockerService {
    buildSite(siteId: string, deploymentId: string, buildDir?: string): Promise<void>;
    deploySite(siteId: string, projectId: string, imageName: string, port?: number): Promise<void>;
    stopSite(siteId: string): Promise<void>;
    getContainerStatus(siteId: string): Promise<{
        running: boolean;
        containerId?: string;
    }>;
    getLogs(siteId: string, lines?: number): Promise<string>;
    streamLogs(siteId: string): Promise<string>;
    removeNetwork(projectId: string): Promise<void>;
    generateDockerfileForRuntime(runtime: string, version?: string, startCommand?: string, port?: number): string;
}
export declare const dockerService: DockerService;
export { gitService } from '../git/git.service.js';
export { buildService } from '../build/build.service.js';
//# sourceMappingURL=docker.service.d.ts.map