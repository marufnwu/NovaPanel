import type { FastifyInstance } from 'fastify';
export default function firewallRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=firewall.routes.d.ts.map