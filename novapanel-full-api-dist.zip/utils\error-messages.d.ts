/**
 * Error Message Transformation Utility
 *
 * Transforms raw technical errors from SSL, tunnel, and DNS operations
 * into human-readable messages with suggested next steps.
 */
import { AppError } from '../errors.js';
export type SslErrorType = 'connection' | 'dns' | 'rate_limit' | 'validation' | 'config' | 'unknown';
export type TunnelErrorType = 'auth' | 'network' | 'dns' | 'config' | 'unknown';
export type DnsErrorType = 'propagation' | 'zone' | 'record' | 'unknown';
export interface SslErrorResult {
    title: string;
    message: string;
    suggestion: string;
    errorType: SslErrorType;
}
export interface TunnelErrorResult {
    title: string;
    message: string;
    suggestion: string;
    errorType: TunnelErrorType;
}
export interface DnsErrorResult {
    title: string;
    message: string;
    suggestion: string;
    errorType: DnsErrorType;
}
/**
 * Extended error class that includes structured error information
 * for human-readable error messages and debugging details.
 */
export declare class StructuredError extends AppError {
    title: string;
    suggestion: string;
    cause?: string | undefined;
    constructor(statusCode: number, code: string, message: string, title: string, suggestion: string, cause?: string | undefined);
}
/**
 * Transform SSL/certbot errors into human-readable messages
 */
export declare function transformSslError(rawError: string): SslErrorResult;
/**
 * Transform tunnel/Cloudflare errors into human-readable messages
 */
export declare function transformTunnelError(rawError: string): TunnelErrorResult;
/**
 * Transform DNS errors into human-readable messages
 */
export declare function transformDnsError(rawError: string): DnsErrorResult;
/**
 * Create a structured error with transformed error information.
 * When the error type is specific (not 'unknown'), uses a descriptive code
 * and preserves the original error message alongside the human-readable one.
 */
export declare function createSslError(rawError: string, code?: string): StructuredError;
/**
 * Create tunnel error structure.
 * When the error type is specific (not 'unknown'), uses a descriptive code
 * and preserves the original error message alongside the human-readable one.
 */
export declare function createTunnelError(rawError: string, code?: string): StructuredError;
/**
 * Create DNS error structure.
 * When the error type is specific (not 'unknown'), uses a descriptive code
 * and preserves the original error message alongside the human-readable one.
 */
export declare function createDnsError(rawError: string, code?: string): StructuredError;
//# sourceMappingURL=error-messages.d.ts.map