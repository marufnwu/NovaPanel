export * from './types.js';
export { Pm2Manager, pm2Manager } from './pm2.manager.js';
export { SystemdManager, systemdManager } from './systemd.manager.js';
import { ProcessManager } from './types.js';
export declare function getProcessManager(): Promise<ProcessManager>;
//# sourceMappingURL=index.d.ts.map