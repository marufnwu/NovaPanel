export declare class AppError extends Error {
    statusCode: number;
    code: string;
    field?: string | undefined;
    constructor(statusCode: number, code: string, message: string, field?: string | undefined);
}
//# sourceMappingURL=errors.d.ts.map