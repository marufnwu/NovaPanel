import type { FastifyInstance } from 'fastify';
export default function databaseRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=databases.routes.d.ts.map