import type { FastifyInstance } from 'fastify';
export default function phpRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=php.routes.d.ts.map