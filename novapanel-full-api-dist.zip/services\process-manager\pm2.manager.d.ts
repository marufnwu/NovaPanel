import { ProcessManager, ProcessStatus, ProcessConfig } from './types.js';
export declare class Pm2Manager implements ProcessManager {
    private readonly name;
    isAvailable(): Promise<boolean>;
    start(config: ProcessConfig): Promise<void>;
    stop(name: string): Promise<void>;
    restart(name: string): Promise<void>;
    getStatus(name: string): Promise<ProcessStatus>;
    logs(name: string, lines?: number): Promise<string>;
    delete(name: string): Promise<void>;
}
export declare const pm2Manager: Pm2Manager;
//# sourceMappingURL=pm2.manager.d.ts.map