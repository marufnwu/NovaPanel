interface FileItem {
    name: string;
    type: string;
    size: number;
    permissions: string;
    modifiedAt: string;
    isDirectory: boolean;
    uid: number;
    gid: number;
    owner?: string;
    group?: string;
}
interface DirectoryTreeNode {
    name: string;
    path: string;
    type: string;
    isDirectory: boolean;
    isExpanded?: boolean;
    children: DirectoryTreeNode[];
}
export declare class FilesService {
    /**
     * Validate and resolve a safe path within subscription home dir
     */
    safePath(homeDir: string, requestedPath: string): string;
    /**
     * List directory contents
     */
    listDirectory(homeDir: string, relativePath?: string, options?: {
        showHidden?: boolean;
        sortBy?: 'name' | 'size' | 'modified' | 'type';
        sortOrder?: 'asc' | 'desc';
    }): Promise<FileItem[]>;
    /**
     * Get directory tree structure for left panel
     */
    getDirectoryTree(homeDir: string, relativePath?: string, options?: {
        showHidden?: boolean;
    }): Promise<DirectoryTreeNode>;
    /**
     * Upload a file
     */
    uploadFile(homeDir: string, relativePath: string, filename: string, content: Buffer, userId?: string, ipAddress?: string): Promise<{
        name: string;
        size: number;
    }>;
    /**
     * Create a directory
     */
    createDirectory(homeDir: string, relativePath: string, dirName: string, userId?: string, ipAddress?: string): Promise<{
        name: string;
        created: boolean;
    }>;
    /**
     * Delete a file or directory
     */
    deleteItem(homeDir: string, relativePath: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Rename a file or directory
     */
    renameItem(homeDir: string, oldRelativePath: string, newRelativePath: string, userId?: string, ipAddress?: string): Promise<{
        oldPath: string;
        newPath: string;
    }>;
    /**
     * Update file permissions
     */
    updatePermissions(homeDir: string, relativePath: string, mode: string, userId?: string, ipAddress?: string): Promise<{
        path: string;
        mode: string;
    }>;
    /**
     * Archive files/directories into a tar.gz
     */
    archiveItems(homeDir: string, paths: string[], archiveName: string, userId?: string, ipAddress?: string): Promise<{
        name: string;
        size: number;
    }>;
    /**
     * Extract an archive
     */
    extractArchive(homeDir: string, archiveRelativePath: string, targetDir?: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        extractedFiles: string[];
    }>;
    /**
     * Get file content for text editing
     */
    getFileContent(homeDir: string, relativePath: string): Promise<string>;
    /**
     * Save file content from text editor
     */
    saveFileContent(homeDir: string, relativePath: string, content: string, userId?: string, ipAddress?: string): Promise<{
        saved: boolean;
    }>;
    /**
     * Copy a file or directory
     */
    copyItem(homeDir: string, sourceRelativePath: string, targetRelativePath: string, userId?: string, ipAddress?: string): Promise<{
        sourcePath: string;
        targetPath: string;
    }>;
    /**
     * Move a file or directory
     */
    moveItem(homeDir: string, sourceRelativePath: string, targetRelativePath: string, userId?: string, ipAddress?: string): Promise<{
        sourcePath: string;
        targetPath: string;
    }>;
    /**
     * Get directory size
     */
    getDirectorySize(homeDir: string, relativePath: string): Promise<{
        path: string;
        size: number;
        sizeHuman: string;
    }>;
    /**
     * Get file ownership info
     */
    getFileOwnership(homeDir: string, relativePath: string): Promise<{
        path: string;
        uid: number;
        gid: number;
        user?: string;
        group?: string;
    }>;
    /**
     * Get download stream for a file
     */
    getDownloadStream(homeDir: string, relativePath: string): import("fs").ReadStream;
    private getFileType;
}
export {};
//# sourceMappingURL=files.service.d.ts.map