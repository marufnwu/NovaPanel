import type { FastifyInstance } from 'fastify';
export default function domainRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=domains.routes.d.ts.map