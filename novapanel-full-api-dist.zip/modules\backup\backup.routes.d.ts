import type { FastifyInstance } from 'fastify';
export default function backupRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=backup.routes.d.ts.map