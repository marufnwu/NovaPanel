import type { FastifyInstance } from 'fastify';
export default function pluginsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=plugins.routes.d.ts.map