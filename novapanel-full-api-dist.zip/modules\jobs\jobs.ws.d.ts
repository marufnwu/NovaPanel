import type { FastifyInstance } from 'fastify';
export declare function registerJobsWs(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=jobs.ws.d.ts.map