export { RuntimeManager, runtimeManager } from './runtime-manager.js';
//# sourceMappingURL=index.d.ts.map