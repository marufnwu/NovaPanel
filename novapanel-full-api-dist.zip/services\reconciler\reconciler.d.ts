export declare class Reconciler {
    private isRunning;
    private interval;
    start(): void;
    stop(): void;
    reconcileAll(): Promise<void>;
    reconcileSite(siteId: string): Promise<void>;
    private getDesiredState;
    private getActualState;
    private detectDrift;
    private repairDrift;
    private updateObservedState;
}
export declare const reconciler: Reconciler;
//# sourceMappingURL=reconciler.d.ts.map