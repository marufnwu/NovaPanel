import { db } from '../../db/index.js';
import { usageRecords, invoices, plans } from '../../db/schema/billing.js';
import { eq, desc } from 'drizzle-orm';
import { nanoid } from 'nanoid';
export class BillingService {
    async listUsageRecords(orgId, from, to) {
        let query = db.select().from(usageRecords).where(eq(usageRecords.orgId, orgId)).orderBy(desc(usageRecords.timestamp));
        return query;
    }
    async recordUsage(orgId, resourceType, quantity, unit, resourceId) {
        const record = {
            id: nanoid(),
            orgId,
            resourceType,
            resourceId,
            quantity,
            unit,
            timestamp: new Date(),
        };
        await db.insert(usageRecords).values(record);
        const [created] = await db.select().from(usageRecords).where(eq(usageRecords.id, record.id)).limit(1);
        return created;
    }
    async getCurrentUsage(orgId) {
        const records = await db.select().from(usageRecords).where(eq(usageRecords.orgId, orgId));
        const aggregated = {};
        for (const r of records) {
            const key = r.resourceType;
            if (!aggregated[key]) {
                aggregated[key] = { quantity: 0, unit: r.unit };
            }
            aggregated[key].quantity += r.quantity;
        }
        return aggregated;
    }
    async listInvoices(orgId) {
        return db.select().from(invoices).where(eq(invoices.orgId, orgId)).orderBy(desc(invoices.createdAt));
    }
    async createInvoice(orgId, amount, currency = 'USD', lineItems) {
        const invoice = {
            id: nanoid(),
            orgId,
            status: 'draft',
            amount,
            currency,
            lineItems: lineItems ?? [],
            createdAt: new Date(),
        };
        await db.insert(invoices).values(invoice);
        const [created] = await db.select().from(invoices).where(eq(invoices.id, invoice.id)).limit(1);
        return created;
    }
    async updateInvoiceStatus(id, status) {
        const updateData = { status };
        if (status === 'paid') {
            updateData.paidAt = new Date();
        }
        await db.update(invoices).set(updateData).where(eq(invoices.id, id));
        const [updated] = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
        if (!updated)
            throw new Error('Invoice not found');
        return updated;
    }
    async listPlans() {
        return db.select().from(plans).where(eq(plans.isActive, true)).orderBy(plans.price);
    }
    async getPlan(slug) {
        const [plan] = await db.select().from(plans).where(eq(plans.slug, slug)).limit(1);
        return plan ?? null;
    }
    async createPlan(data) {
        const plan = {
            id: nanoid(),
            ...data,
            createdAt: new Date(),
        };
        await db.insert(plans).values(plan);
        const [created] = await db.select().from(plans).where(eq(plans.id, plan.id)).limit(1);
        return created;
    }
    async updatePlan(id, data) {
        await db.update(plans).set({ ...data, updatedAt: new Date() }).where(eq(plans.id, id));
        const [updated] = await db.select().from(plans).where(eq(plans.id, id)).limit(1);
        if (!updated)
            throw new Error('Plan not found');
        return updated;
    }
    async deletePlan(id) {
        await db.update(plans).set({ isActive: false, updatedAt: new Date() }).where(eq(plans.id, id));
    }
}
export const billingService = new BillingService();
//# sourceMappingURL=billing.service.js.map