import { z } from 'zod';
export declare const mkdirSchema: z.ZodObject<{
    path: z.ZodString;
    name: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    path: string;
    name: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    path: string;
    name: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const renameSchema: z.ZodObject<{
    oldPath: z.ZodString;
    newPath: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    oldPath: string;
    newPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    oldPath: string;
    newPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const chmodSchema: z.ZodObject<{
    path: z.ZodString;
    mode: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    path: string;
    mode: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    path: string;
    mode: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const archiveSchema: z.ZodObject<{
    paths: z.ZodArray<z.ZodString, "many">;
    name: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    paths: string[];
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    name: string;
    paths: string[];
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const extractSchema: z.ZodObject<{
    archivePath: z.ZodString;
    targetDir: z.ZodOptional<z.ZodString>;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    archivePath: string;
    domainId?: string | undefined;
    targetDir?: string | undefined;
    websiteId?: string | undefined;
}, {
    archivePath: string;
    domainId?: string | undefined;
    targetDir?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const saveContentSchema: z.ZodObject<{
    path: z.ZodString;
    content: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    path: string;
    content: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    path: string;
    content: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const copySchema: z.ZodObject<{
    sourcePath: z.ZodString;
    targetPath: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    sourcePath: string;
    targetPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    sourcePath: string;
    targetPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const moveSchema: z.ZodObject<{
    sourcePath: z.ZodString;
    targetPath: z.ZodString;
    websiteId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    sourcePath: string;
    targetPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}, {
    sourcePath: string;
    targetPath: string;
    domainId?: string | undefined;
    websiteId?: string | undefined;
}>;
//# sourceMappingURL=files.schema.d.ts.map