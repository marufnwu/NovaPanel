import { db } from '../../db/index.js';
import { sites } from '../../db/schema/sites.js';
import { domains } from '../../db/schema/domains.js';
import { containers } from '../../db/schema/containers.js';
import { eq } from 'drizzle-orm';
import { logger } from '../../config/logger.js';
import { run } from '../executor.js';
const RECONCILE_INTERVAL_MS = 60000;
export class Reconciler {
    isRunning = false;
    interval = null;
    start() {
        if (this.isRunning) {
            logger.warn('Reconciler already running');
            return;
        }
        this.isRunning = true;
        logger.info('Reconciler started');
        this.interval = setInterval(() => {
            this.reconcileAll().catch(err => {
                logger.error({ err }, 'Reconciliation loop error');
            });
        }, RECONCILE_INTERVAL_MS);
        this.reconcileAll().catch(err => {
            logger.error({ err }, 'Initial reconciliation error');
        });
    }
    stop() {
        if (!this.isRunning)
            return;
        this.isRunning = false;
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
        logger.info('Reconciler stopped');
    }
    async reconcileAll() {
        const allSites = await db.select().from(sites);
        for (const site of allSites) {
            try {
                await this.reconcileSite(site.id);
            }
            catch (err) {
                logger.error({ err, siteId: site.id }, 'Site reconciliation failed');
            }
        }
    }
    async reconcileSite(siteId) {
        const site = await db.select().from(sites).where(eq(sites.id, siteId)).limit(1).then(r => r[0]);
        if (!site)
            return;
        const desired = await this.getDesiredState(siteId);
        const actual = await this.getActualState(siteId);
        const drift = this.detectDrift(desired, actual);
        if (drift.hasDrift && desired) {
            logger.info({ siteId, drift }, 'Drift detected, repairing');
            await this.repairDrift(siteId, desired, drift);
        }
        const durationMs = Date.now();
        await this.updateObservedState(siteId, actual, durationMs);
    }
    async getDesiredState(siteId) {
        const [site] = await db.select().from(sites).where(eq(sites.id, siteId)).limit(1);
        if (!site)
            return null;
        const siteContainers = await db.select().from(containers).where(eq(containers.projectId, site.projectId));
        const siteDomains = await db.select().from(domains).where(eq(domains.siteId, siteId));
        return { site, containers: siteContainers, domains: siteDomains };
    }
    async getActualState(siteId) {
        let nginxStatus = 'unknown';
        try {
            const result = await run('nginx', ['-t'], { sudo: true });
            nginxStatus = result.exitCode === 0 ? 'ok' : 'invalid';
        }
        catch {
            nginxStatus = 'missing';
        }
        const siteContainers = await db.select().from(containers).where(eq(containers.projectId, siteId));
        const containersStatus = {};
        for (const c of siteContainers) {
            if (!c.containerId) {
                containersStatus[c.id] = 'stopped';
                continue;
            }
            try {
                const { stdout } = await run('docker', ['inspect', '--format', '{{.State.Running}}', c.containerId], { sudo: true });
                containersStatus[c.id] = stdout.trim() === 'true' ? 'running' : 'stopped';
            }
            catch {
                containersStatus[c.id] = 'error';
            }
        }
        return { nginxStatus, containersStatus };
    }
    detectDrift(desired, actual) {
        if (!desired)
            return { hasDrift: false };
        const containerRestartNeeded = {};
        let hasDrift = false;
        if (actual.nginxStatus === 'reload_needed' || actual.nginxStatus === 'invalid') {
            hasDrift = true;
        }
        for (const c of desired.containers) {
            const status = actual.containersStatus[c.id];
            if (c.status === 'running' && (status === 'stopped' || status === 'error' || status === 'unknown')) {
                containerRestartNeeded[c.id] = true;
                hasDrift = true;
            }
        }
        return { hasDrift, containerRestartNeeded };
    }
    async repairDrift(siteId, desired, drift) {
        try {
            await run('nginx', ['-s', 'reload'], { sudo: true });
        }
        catch {
            await run('systemctl', ['reload', 'nginx'], { sudo: true }).catch(() => { });
        }
        if (drift.containerRestartNeeded) {
            for (const [containerId] of Object.entries(drift.containerRestartNeeded)) {
                const [container] = await db.select().from(containers).where(eq(containers.id, containerId)).limit(1);
                if (container?.containerId) {
                    try {
                        await run('docker', ['restart', container.containerId], { sudo: true });
                    }
                    catch (err) {
                        logger.warn({ err, containerId }, 'Failed to restart container during reconcile');
                    }
                }
            }
        }
        logger.info({ siteId }, 'Drift repaired');
    }
    async updateObservedState(siteId, actual, durationMs) {
        logger.debug({ siteId, actual, durationMs }, 'Observed state logged');
    }
}
export const reconciler = new Reconciler();
//# sourceMappingURL=reconciler.js.map