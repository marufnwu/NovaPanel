export type NotificationType = 'ssl_expiry' | 'backup_complete' | 'cron_failed' | 'security_alert' | 'disk_space_low' | 'service_down' | 'info';
export interface NotificationPreferences {
    emailEnabled: boolean;
    pushEnabled: boolean;
    sslExpiry: boolean;
    backupComplete: boolean;
    cronFailed: boolean;
    securityAlert: boolean;
    diskSpaceLow: boolean;
    serviceDown: boolean;
}
export declare class NotificationsService {
    getPreferences(_userId: string): Promise<{
        emailEnabled: boolean;
        pushEnabled: boolean;
        sslExpiry: boolean;
        backupComplete: boolean;
        cronFailed: boolean;
        securityAlert: boolean;
        diskSpaceLow: boolean;
        serviceDown: boolean;
    }>;
    updatePreferences(userId: string, data: Partial<NotificationPreferences>): Promise<{
        emailEnabled: boolean;
        pushEnabled: boolean;
        sslExpiry: boolean;
        backupComplete: boolean;
        cronFailed: boolean;
        securityAlert: boolean;
        diskSpaceLow: boolean;
        serviceDown: boolean;
    }>;
    listNotifications(userId: string, limit?: number, offset?: number): Promise<{
        notifications: {
            id: string;
            userId: string;
            type: string;
            title: string;
            message: string;
            read: boolean;
            createdAt: string;
        }[];
        total: number;
    }>;
    getUnreadCount(userId: string): Promise<number>;
    markAsRead(notificationId: string, userId: string): Promise<void>;
    markAllAsRead(userId: string): Promise<void>;
    createNotification(userId: string, type: NotificationType, title: string, message: string): Promise<{
        id: string;
    }>;
    deleteNotification(notificationId: string, userId: string): Promise<void>;
}
export declare const notificationsService: NotificationsService;
//# sourceMappingURL=notifications.service.d.ts.map