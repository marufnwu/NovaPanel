export interface JobPayload {
    [key: string]: unknown;
}
export interface JobResult {
    success: boolean;
    data?: unknown;
    error?: string;
}
export type JobHandler = (payload: JobPayload) => Promise<JobResult>;
export interface JobDefinition {
    type: string;
    handler: JobHandler;
    maxRetries?: number;
}
export declare const JOB_TYPES: {
    readonly NGINX_CONFIG_REGENERATE: "nginx_config_regenerate";
    readonly NGINX_RELOAD: "nginx_reload";
    readonly PM2_RESTART: "pm2_restart";
    readonly PM2_STOP: "pm2_stop";
    readonly SSL_PROVISION: "ssl_provision";
    readonly DEPLOYMENT_BUILD: "deployment_build";
    readonly DEPLOYMENT_ROLLBACK: "deployment_rollback";
    readonly METRIC_COLLECT: "metric_collect";
    readonly ALERT_EVALUATE: "alert_evaluate";
};
export type { BackgroundJob } from '../../db/schema/background_jobs.js';
//# sourceMappingURL=types.d.ts.map