import { z } from 'zod';
export declare const systemLogsSchema: z.ZodObject<{
    log: z.ZodString;
    entries: z.ZodArray<z.ZodObject<{
        timestamp: z.ZodString;
        level: z.ZodString;
        message: z.ZodString;
        source: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        message: string;
        level: string;
        timestamp: string;
        source?: string | undefined;
    }, {
        message: string;
        level: string;
        timestamp: string;
        source?: string | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    entries: {
        message: string;
        level: string;
        timestamp: string;
        source?: string | undefined;
    }[];
    log: string;
}, {
    entries: {
        message: string;
        level: string;
        timestamp: string;
        source?: string | undefined;
    }[];
    log: string;
}>;
export declare const systemLogsQuerySchema: z.ZodObject<{
    lines: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    lines: number;
}, {
    lines?: number | undefined;
}>;
export type SystemLogsResponse = z.infer<typeof systemLogsSchema>;
export type SystemLogsQuery = z.infer<typeof systemLogsQuerySchema>;
//# sourceMappingURL=logs.schema.d.ts.map