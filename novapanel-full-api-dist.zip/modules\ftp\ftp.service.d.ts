export declare class FtpService {
    listAccounts(domainId: string): Promise<{
        status: "active" | "suspended";
        id: string;
        username: string;
        lastLoginAt: Date | null;
        createdAt: Date;
        projectId: string;
        siteId: string | null;
        password: string;
        databaseId: string | null;
        homeDir: string;
        quota: number | null;
    }[]>;
    getAccount(ftpId: string): Promise<{
        status: "active" | "suspended";
        id: string;
        username: string;
        lastLoginAt: Date | null;
        createdAt: Date;
        projectId: string;
        siteId: string | null;
        password: string;
        databaseId: string | null;
        homeDir: string;
        quota: number | null;
    }>;
    createAccount(domainId: string, data: {
        username: string;
        password: string;
        homeDir: string;
        readonly?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        status: "active" | "suspended";
        id: string;
        username: string;
        lastLoginAt: Date | null;
        createdAt: Date;
        projectId: string;
        siteId: string | null;
        password: string;
        databaseId: string | null;
        homeDir: string;
        quota: number | null;
    }>;
    updateAccount(ftpId: string, data: {
        password?: string;
        homeDir?: string;
        readonly?: boolean;
        isActive?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        status: "active" | "suspended";
        id: string;
        username: string;
        lastLoginAt: Date | null;
        createdAt: Date;
        projectId: string;
        siteId: string | null;
        password: string;
        databaseId: string | null;
        homeDir: string;
        quota: number | null;
    }>;
    updatePassword(ftpId: string, newPassword: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    deleteAccount(ftpId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getSettings(): Promise<{
        port: number;
        passivePortMin: number;
        passivePortMax: number;
        maxConnectionsPerIp: number;
        anonymousEnabled: boolean;
    }>;
    updateSettings(data: {
        port?: number;
        passivePortMin?: number;
        passivePortMax?: number;
        maxConnectionsPerIp?: number;
        anonymousEnabled?: boolean;
    }): Promise<{
        port: number;
        passivePortMin: number;
        passivePortMax: number;
        maxConnectionsPerIp: number;
        anonymousEnabled: boolean;
    }>;
    listByWebsite(websiteId: string): Promise<{
        status: "active" | "suspended";
        id: string;
        username: string;
        lastLoginAt: Date | null;
        createdAt: Date;
        projectId: string;
        siteId: string | null;
        password: string;
        databaseId: string | null;
        homeDir: string;
        quota: number | null;
    }[]>;
}
export declare const ftpService: FtpService;
//# sourceMappingURL=ftp.service.d.ts.map