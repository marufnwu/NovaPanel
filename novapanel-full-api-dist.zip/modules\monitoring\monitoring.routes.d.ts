import type { FastifyInstance } from 'fastify';
export default function monitoringRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=monitoring.routes.d.ts.map