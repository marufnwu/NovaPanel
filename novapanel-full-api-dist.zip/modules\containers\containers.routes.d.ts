import type { FastifyInstance } from 'fastify';
export default function containerRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=containers.routes.d.ts.map