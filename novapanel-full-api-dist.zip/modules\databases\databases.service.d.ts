import { databases } from '../../db/schema/index.js';
export declare class DatabasesService {
    list(projectId?: string): Promise<{
        items: typeof databases.$inferSelect[];
        total: number;
    }>;
    get(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    create(data: {
        projectId: string;
        name: string;
        type: 'postgresql' | 'mysql' | 'mariadb' | 'mongodb' | 'redis' | 'sqlite';
        version?: string;
        host?: string;
        port?: number;
        databaseName?: string;
        username?: string;
        password?: string;
        backupsEnabled?: boolean;
        backupSchedule?: string;
        publicAccess?: boolean;
    }): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    update(id: string, data: Partial<{
        name: string;
        backupsEnabled: boolean;
        backupSchedule: string;
        publicAccess: boolean;
        status: 'running' | 'stopped' | 'error';
    }>): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
    start(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    stop(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    restart(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        projectId: string;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    listUsers(databaseId: string): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }[]>;
    createUser(data: {
        databaseId: string;
        username: string;
        password?: string;
        privileges?: string[];
    }): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }>;
    deleteUser(id: string): Promise<{
        success: boolean;
    }>;
    updateUserPrivileges(id: string, privileges: string[]): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }>;
}
export declare const databasesService: DatabasesService;
//# sourceMappingURL=databases.service.d.ts.map