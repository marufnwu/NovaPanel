export declare class GitService {
    cloneRepo(repo: string, branch: string, targetDir: string): Promise<void>;
    pullLatest(targetDir: string, branch: string): Promise<void>;
    getCurrentCommit(targetDir: string): Promise<string>;
    getCommitMessage(targetDir: string): Promise<string>;
    validateWebhook(secret: string, payload: string, signature: string): boolean;
    checkoutRef(targetDir: string, ref: string): Promise<void>;
}
export declare const gitService: GitService;
//# sourceMappingURL=git.service.d.ts.map