import Redis from 'ioredis';
/**
 * Singleton Redis client for NovaPanel.
 * Used for session cache, rate limit counters, password reset tokens, and job queue events.
 */
declare class RedisClient {
    private client;
    private isConnected;
    getClient(): Redis;
    connect(): Promise<void>;
    get connected(): boolean;
}
export declare const redisClient: RedisClient;
export {};
//# sourceMappingURL=redis.d.ts.map