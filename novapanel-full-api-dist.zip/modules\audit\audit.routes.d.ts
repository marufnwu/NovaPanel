import type { FastifyInstance } from 'fastify';
export default function auditRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=audit.routes.d.ts.map