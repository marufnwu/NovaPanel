import { z } from 'zod';
export declare const setupTunnelSchema: z.ZodObject<{
    name: z.ZodString;
    apiToken: z.ZodString;
    accountId: z.ZodOptional<z.ZodString>;
    zoneId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    apiToken: string;
    zoneId?: string | undefined;
    accountId?: string | undefined;
}, {
    name: string;
    apiToken: string;
    zoneId?: string | undefined;
    accountId?: string | undefined;
}>;
export declare const addRouteSchema: z.ZodObject<{
    tunnelId: z.ZodString;
    hostname: z.ZodString;
    service: z.ZodString;
    noTlsVerify: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    hostname: string;
    tunnelId: string;
    service: string;
    noTlsVerify: boolean;
    domainId?: string | undefined;
}, {
    hostname: string;
    tunnelId: string;
    service: string;
    domainId?: string | undefined;
    noTlsVerify?: boolean | undefined;
}>;
export declare const editRouteSchema: z.ZodObject<{
    hostname: z.ZodOptional<z.ZodString>;
    service: z.ZodOptional<z.ZodString>;
    noTlsVerify: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    hostname?: string | undefined;
    service?: string | undefined;
    noTlsVerify?: boolean | undefined;
}, {
    hostname?: string | undefined;
    service?: string | undefined;
    noTlsVerify?: boolean | undefined;
}>;
//# sourceMappingURL=tunnel.schema.d.ts.map