import type { FastifyInstance } from 'fastify';
export default function deploymentRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=deployments.routes.d.ts.map