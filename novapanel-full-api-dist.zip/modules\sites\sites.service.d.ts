import { sites } from '../../db/schema/index.js';
import type { CreateSiteInput } from './sites.schema.js';
export declare class SitesService {
    list(_options?: {
        includeRuntime?: boolean;
    }): Promise<typeof sites.$inferSelect[]>;
    get(id: string): Promise<{
        domains: {
            type: "apex" | "subdomain" | "wildcard";
            status: "active" | "suspended" | "pending";
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            projectId: string;
            siteId: string | null;
            dnsZoneId: string | null;
            nameservers: unknown;
            dnssecEnabled: boolean;
            sslStatus: "error" | "active" | "pending" | "expired";
            sslCertId: string | null;
            sslAutoRenew: boolean;
            forceHttps: boolean;
            hstsEnabled: boolean;
            proxyEnabled: boolean;
            customNginxConfig: string | null;
        }[];
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        description: string | null;
        projectId: string;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    } | null>;
    create(data: CreateSiteInput, _userId?: string, _ipAddress?: string): Promise<{
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        description: string | null;
        projectId: string;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    }>;
    update(id: string, data: Partial<typeof sites.$inferInsert>, _userId?: string, _ipAddress?: string): Promise<{
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        description: string | null;
        projectId: string;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    }>;
    delete(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    suspend(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    } | null>;
    activate(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    } | null>;
    attachDomain(siteId: string, domainId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    detachDomain(siteId: string, domainId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
}
export declare const sitesService: SitesService;
//# sourceMappingURL=sites.service.d.ts.map