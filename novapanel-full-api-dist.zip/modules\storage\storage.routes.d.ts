import type { FastifyInstance } from 'fastify';
export default function storageRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=storage.routes.d.ts.map