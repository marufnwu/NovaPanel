import { EventEmitter } from 'events';
export type JobStatus = 'queued' | 'running' | 'done' | 'failed' | 'cancelled';
export interface JobEvent {
    jobId: string;
    type: string;
    status: JobStatus;
    message: string;
    progress?: number;
    timestamp: string;
    userId?: string;
}
/**
 * Global singleton event emitter for background job lifecycle events.
 * Services emit events here; the WebSocket handler broadcasts to connected clients.
 */
declare class JobEventBus extends EventEmitter {
    constructor();
    /**
     * Emit a job lifecycle event.
     */
    emitJob(event: JobEvent): void;
    /**
     * Subscribe to job events. Returns an unsubscribe function.
     */
    onJob(handler: (event: JobEvent) => void): () => void;
}
export declare const jobEventBus: JobEventBus;
/**
 * Helper to create and emit a job-queued event.
 */
export declare function emitJobQueued(jobId: string, type: string, message: string, userId?: string): void;
/**
 * Helper to create and emit a job-running event.
 */
export declare function emitJobRunning(jobId: string, type: string, message: string, progress?: number, userId?: string): void;
/**
 * Helper to create and emit a job-done event.
 */
export declare function emitJobDone(jobId: string, type: string, message: string, userId?: string): void;
/**
 * Helper to create and emit a job-failed event.
 */
export declare function emitJobFailed(jobId: string, type: string, message: string, userId?: string): void;
export {};
//# sourceMappingURL=job-events.d.ts.map