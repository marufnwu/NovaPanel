import { z } from 'zod';
export declare const createRecordSchema: z.ZodIntersection<z.ZodObject<{
    type: z.ZodEnum<["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA", "PTR"]>;
    name: z.ZodString;
    value: z.ZodString;
    ttl: z.ZodDefault<z.ZodNumber>;
    priority: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
    name: string;
    ttl: number;
    priority?: number | undefined;
}, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
    name: string;
    ttl?: number | undefined;
    priority?: number | undefined;
}>, z.ZodEffects<z.ZodObject<{
    type: z.ZodEnum<["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA", "PTR"]>;
    value: z.ZodString;
}, "strip", z.ZodTypeAny, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
}, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
}>, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
}, {
    value: string;
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
}>>;
export declare const updateRecordSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    value: z.ZodOptional<z.ZodString>;
    ttl: z.ZodOptional<z.ZodNumber>;
    priority: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    value?: string | undefined;
    name?: string | undefined;
    ttl?: number | undefined;
    priority?: number | undefined;
}, {
    value?: string | undefined;
    name?: string | undefined;
    ttl?: number | undefined;
    priority?: number | undefined;
}>;
export declare const importZoneSchema: z.ZodObject<{
    bindFormat: z.ZodString;
}, "strip", z.ZodTypeAny, {
    bindFormat: string;
}, {
    bindFormat: string;
}>;
//# sourceMappingURL=dns.schema.d.ts.map