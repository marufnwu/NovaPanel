import { type UsageRecord, type Invoice, type Plan, type NewPlan } from '../../db/schema/billing.js';
export declare class BillingService {
    listUsageRecords(orgId: string, from?: Date, to?: Date): Promise<UsageRecord[]>;
    recordUsage(orgId: string, resourceType: 'cpu' | 'memory' | 'storage' | 'bandwidth' | 'requests', quantity: number, unit: string, resourceId?: string): Promise<UsageRecord>;
    getCurrentUsage(orgId: string): Promise<Record<string, {
        quantity: number;
        unit: string;
    }>>;
    listInvoices(orgId: string): Promise<Invoice[]>;
    createInvoice(orgId: string, amount: number, currency?: string, lineItems?: unknown[]): Promise<Invoice>;
    updateInvoiceStatus(id: string, status: Invoice['status']): Promise<Invoice>;
    listPlans(): Promise<Plan[]>;
    getPlan(slug: string): Promise<Plan | null>;
    createPlan(data: Omit<NewPlan, 'id' | 'createdAt'>): Promise<Plan>;
    updatePlan(id: string, data: Partial<Pick<Plan, 'name' | 'price' | 'quotas' | 'features' | 'isActive'>>): Promise<Plan>;
    deletePlan(id: string): Promise<void>;
}
export declare const billingService: BillingService;
//# sourceMappingURL=billing.service.d.ts.map