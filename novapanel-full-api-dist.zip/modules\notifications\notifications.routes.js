import { requireAuth } from '../auth/auth.middleware.js';
import { notificationsService } from './notifications.service.js';
import { updatePreferencesSchema } from './notifications.schema.js';
export default async function notificationsRoutes(fastify) {
    fastify.addHook('preHandler', requireAuth);
    // GET /notifications/preferences
    fastify.get('/notifications/preferences', async (req) => {
        const prefs = await notificationsService.getPreferences(req.user.id);
        return { success: true, data: prefs };
    });
    // PUT /notifications/preferences
    fastify.put('/notifications/preferences', async (req, reply) => {
        try {
            const data = updatePreferencesSchema.parse(req.body);
            const prefs = await notificationsService.updatePreferences(req.user.id, data);
            return { success: true, data: prefs };
        }
        catch (error) {
            if (error.name === 'ZodError') {
                return reply.status(400).send({ success: false, error: 'Invalid preferences data', details: error.errors });
            }
            return reply.status(500).send({ success: false, error: error.message || 'Failed to update preferences' });
        }
    });
    // GET /notifications
    fastify.get('/notifications', async (req, reply) => {
        try {
            const { limit = 50, offset = 0 } = req.query;
            const result = await notificationsService.listNotifications(req.user.id, Number(limit), Number(offset));
            return { success: true, data: result };
        }
        catch (error) {
            return reply.status(500).send({ success: false, error: error.message || 'Failed to list notifications' });
        }
    });
    // GET /notifications/unread-count
    fastify.get('/notifications/unread-count', async (req, reply) => {
        try {
            const count = await notificationsService.getUnreadCount(req.user.id);
            return { success: true, data: { count } };
        }
        catch (error) {
            return reply.status(500).send({ success: false, error: error.message || 'Failed to get unread count' });
        }
    });
    // POST /notifications/:id/read
    fastify.post('/notifications/:id/read', async (req, reply) => {
        try {
            const { id } = req.params;
            await notificationsService.markAsRead(id, req.user.id);
            return { success: true };
        }
        catch (error) {
            return reply.status(500).send({ success: false, error: error.message || 'Failed to mark as read' });
        }
    });
    // POST /notifications/read-all
    fastify.post('/notifications/read-all', async (req, reply) => {
        try {
            await notificationsService.markAllAsRead(req.user.id);
            return { success: true };
        }
        catch (error) {
            return reply.status(500).send({ success: false, error: error.message || 'Failed to mark all as read' });
        }
    });
    // DELETE /notifications/:id
    fastify.delete('/notifications/:id', async (req, reply) => {
        try {
            const { id } = req.params;
            await notificationsService.deleteNotification(id, req.user.id);
            return { success: true };
        }
        catch (error) {
            return reply.status(500).send({ success: false, error: error.message || 'Failed to delete notification' });
        }
    });
}
//# sourceMappingURL=notifications.routes.js.map