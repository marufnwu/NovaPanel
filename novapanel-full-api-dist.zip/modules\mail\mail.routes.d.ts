import type { FastifyInstance } from 'fastify';
export default function mailRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=mail.routes.d.ts.map