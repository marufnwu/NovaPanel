import type { FastifyInstance } from 'fastify';
export default function dockerRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=docker.routes.d.ts.map