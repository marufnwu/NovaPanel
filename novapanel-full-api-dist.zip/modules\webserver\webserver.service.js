import { db } from '../../db/index.js';
import { domains } from '../../db/schema/index.js';
import { eq } from 'drizzle-orm';
import { AppError } from '../../errors.js';
import { nginxService } from '../../services/nginx.service.js';
export class WebServerService {
    async applyWebsiteConfig(_websiteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Website-based config not available in v5 - use domain config');
    }
    async removeWebsiteConfig(_websiteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Website-based config not available in v5 - use domain config');
    }
    async getConfig(domainId) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, domainId)).limit(1);
        if (!domain)
            throw new AppError(404, 'NOT_FOUND', 'Domain not found');
        return nginxService.renderVhostConfig({
            domain: domain.name,
            documentRoot: `/var/www/${domain.projectId}/${domain.siteId || 'default'}`,
            phpVersion: '8.3',
            ssl: undefined,
            redirectHttpToHttps: domain.forceHttps,
            hsts: domain.hstsEnabled,
        });
    }
    async getConfigByName(domainName) {
        const [domain] = await db.select().from(domains).where(eq(domains.name, domainName)).limit(1);
        if (!domain)
            throw new AppError(404, 'NOT_FOUND', 'Domain not found');
        return this.getConfig(domain.id);
    }
    async updateConfig(domainId, _userId, data) {
        const [domain] = await db.select().from(domains).where(eq(domains.id, domainId)).limit(1);
        if (!domain)
            throw new AppError(404, 'NOT_FOUND', 'Domain not found');
        await db.update(domains).set({
            ...(data.forceHttps !== undefined && { forceHttps: data.forceHttps }),
            ...(data.hstsEnabled !== undefined && { hstsEnabled: data.hstsEnabled }),
            ...(data.customNginxConfig !== undefined && { customNginxConfig: data.customNginxConfig }),
        }).where(eq(domains.id, domainId));
        return this.getConfig(domainId);
    }
    async updateConfigByName(domainName, userId, data) {
        const [domain] = await db.select().from(domains).where(eq(domains.name, domainName)).limit(1);
        if (!domain)
            throw new AppError(404, 'NOT_FOUND', 'Domain not found');
        return this.updateConfig(domain.id, userId, data);
    }
    async previewConfig(domainId) {
        return this.getConfig(domainId);
    }
    async testConfig(_domainId) {
        return nginxService.testConfig();
    }
    async listDomains() {
        return db.select({ id: domains.id, name: domains.name, siteId: domains.siteId, status: domains.status }).from(domains);
    }
    async getErrorPages(_domainName) {
        return [];
    }
    async updateErrorPages(_domainName, _errorPages, _userId) {
        return { success: true };
    }
    async getRateLimitConfig(_domainName) {
        return { enabled: false, requestsPerSecond: 10, burstSize: 20, timeoutSeconds: 60 };
    }
    async updateRateLimitConfig(_domainName, _data, _userId) {
        return { success: true };
    }
}
export const webServerService = new WebServerService();
//# sourceMappingURL=webserver.service.js.map