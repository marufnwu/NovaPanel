import { AppError } from '../../errors.js';
export class InstallerService {
    async getAvailableApps() {
        return [];
    }
    async getApp(_appId) {
        return null;
    }
    async installApp(_appId, _siteId, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'App installation requires installed-apps schema - not available in v5 schema');
    }
    async uninstallApp(_installId, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'App uninstallation requires installed-apps schema - not available in v5 schema');
    }
    async getInstallLogs(_installId) {
        return [];
    }
    async updateAppConfig(_installId, _config, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'App config requires installed-apps schema - not available in v5 schema');
    }
}
export const installerService = new InstallerService();
//# sourceMappingURL=installer.service.js.map