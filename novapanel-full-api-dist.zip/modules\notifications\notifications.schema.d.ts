import { z } from 'zod';
export declare const notificationTypeSchema: z.ZodEnum<["ssl_expiry", "backup_complete", "cron_failed", "security_alert", "disk_space_low", "service_down", "info"]>;
export declare const updatePreferencesSchema: z.ZodObject<{
    emailEnabled: z.ZodOptional<z.ZodBoolean>;
    pushEnabled: z.ZodOptional<z.ZodBoolean>;
    sslExpiry: z.ZodOptional<z.ZodBoolean>;
    backupComplete: z.ZodOptional<z.ZodBoolean>;
    cronFailed: z.ZodOptional<z.ZodBoolean>;
    securityAlert: z.ZodOptional<z.ZodBoolean>;
    diskSpaceLow: z.ZodOptional<z.ZodBoolean>;
    serviceDown: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    emailEnabled?: boolean | undefined;
    pushEnabled?: boolean | undefined;
    sslExpiry?: boolean | undefined;
    backupComplete?: boolean | undefined;
    cronFailed?: boolean | undefined;
    securityAlert?: boolean | undefined;
    diskSpaceLow?: boolean | undefined;
    serviceDown?: boolean | undefined;
}, {
    emailEnabled?: boolean | undefined;
    pushEnabled?: boolean | undefined;
    sslExpiry?: boolean | undefined;
    backupComplete?: boolean | undefined;
    cronFailed?: boolean | undefined;
    securityAlert?: boolean | undefined;
    diskSpaceLow?: boolean | undefined;
    serviceDown?: boolean | undefined;
}>;
export declare const createNotificationSchema: z.ZodObject<{
    type: z.ZodEnum<["ssl_expiry", "backup_complete", "cron_failed", "security_alert", "disk_space_low", "service_down", "info"]>;
    title: z.ZodString;
    message: z.ZodString;
}, "strip", z.ZodTypeAny, {
    message: string;
    type: "info" | "ssl_expiry" | "backup_complete" | "cron_failed" | "security_alert" | "disk_space_low" | "service_down";
    title: string;
}, {
    message: string;
    type: "info" | "ssl_expiry" | "backup_complete" | "cron_failed" | "security_alert" | "disk_space_low" | "service_down";
    title: string;
}>;
//# sourceMappingURL=notifications.schema.d.ts.map