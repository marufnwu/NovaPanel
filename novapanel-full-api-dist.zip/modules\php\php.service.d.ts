export declare class PhpService {
    listVersions(): Promise<string[]>;
    getVersion(_version: string): Promise<{
        version: string;
        status: string;
    }>;
    installVersion(_version: string, _userId?: string, _ipAddress?: string): Promise<void>;
    uninstallVersion(_version: string, _userId?: string, _ipAddress?: string): Promise<void>;
    getSettings(_version: string): Promise<{
        disableFunctions: never[];
        uploadMaxFilesize: string;
        postMaxSize: string;
        maxExecutionTime: number;
        memoryLimit: string;
    }>;
    updateSettings(_version: string, _settings: Record<string, any>, _userId?: string, _ipAddress?: string): Promise<void>;
    restartFpm(version: string, userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getPoolConfig(_version: string, _domainId: string): Promise<string>;
    updatePoolConfig(_version: string, _domainId: string, _config: Record<string, any>, _userId?: string, _ipAddress?: string): Promise<void>;
    listDisabledFunctions(_version: string): Promise<never[]>;
    updateDisabledFunctions(_version: string, _functions: string[], _userId?: string, _ipAddress?: string): Promise<void>;
    getUploadLimits(_version: string): Promise<{
        uploadMaxFilesize: string;
        postMaxSize: string;
        maxExecutionTime: number;
        maxInputTime: number;
    }>;
    updateUploadLimits(_version: string, _limits: Record<string, any>, _userId?: string, _ipAddress?: string): Promise<void>;
    getOpcodeCacheSettings(_version: string): Promise<{
        enabled: boolean;
    }>;
    updateOpcodeCacheSettings(_version: string, _settings: Record<string, any>, _userId?: string, _ipAddress?: string): Promise<void>;
    getMemlimit(_version: string): Promise<string>;
    setMemlimit(_version: string, _memlimit: string, _userId?: string, _ipAddress?: string): Promise<void>;
    listDomainsWithPhpVersion(): Promise<{
        id: string;
        name: string;
        type: "apex" | "subdomain" | "wildcard";
    }[]>;
    setDomainPhpVersion(_domainId: string, _version: string, _userId?: string, _ipAddress?: string): Promise<void>;
    bulkSetPhpVersion(_domainIds: string[], _version: string, _userId?: string, _ipAddress?: string): Promise<void>;
}
export declare const phpService: PhpService;
//# sourceMappingURL=php.service.d.ts.map