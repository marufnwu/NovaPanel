interface TunnelRoute {
    id: string;
    tunnelId: string;
    hostname: string;
    service: string;
    type: string;
    createdAt: Date;
}
export declare class TunnelService {
    listTunnels(orgId?: string): Promise<{
        status: "error" | "active" | "inactive";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        tunnelToken: string | null;
    }[]>;
    getTunnel(id: string): Promise<{
        status: "error" | "active" | "inactive";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        tunnelToken: string | null;
    }>;
    createTunnel(data: {
        name: string;
        type: string;
    }, userId?: string, ipAddress?: string): Promise<{
        status: "error" | "active" | "inactive";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string;
        tunnelToken: string | null;
    }>;
    deleteTunnel(id: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getRoutes(_tunnelId: string): Promise<TunnelRoute[]>;
    createRoute(tunnelId: string, data: {
        hostname: string;
        service: string;
        domainId?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        tunnelId: string;
        hostname: string;
        service: string;
        type: string;
        createdAt: Date;
    }>;
    deleteRoute(routeId: string, userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
}
export declare const tunnelService: TunnelService;
export {};
//# sourceMappingURL=tunnel.service.d.ts.map