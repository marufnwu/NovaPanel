import type { Website } from '../../db/schema/websites.js';
import type { Domain } from '../../db/schema/domains.js';
export declare class WebsitesService {
    /**
     * List all websites
     */
    list(): Promise<Website[]>;
    /**
     * Get website by ID with attached domains
     */
    get(id: string): Promise<Website & {
        domains: Domain[];
    }>;
    /**
     * Create a new website:
     * 1. Generate websiteId (nanoid)
     * 2. Create system user: sf_{websiteId}
     * 3. Create directory structure: /var/www/sites/{websiteId}/{httpdocs,private,logs,tmp,ssl,backup}
     * 4. chown -R sf_{websiteId}:www-data
     * 5. Insert into DB
     * 6. Apply website config (nginx + PHP-FPM pool)
     */
    create(data: {
        name: string;
        phpVersion?: string;
        phpHandler?: string;
        webServer?: string;
    }, userId?: string, ipAddress?: string): Promise<Website>;
    /**
     * Update website settings (PHP version, web server, etc.)
     * If phpVersion or phpHandler changes, regenerates both nginx config and PHP-FPM pool.
     */
    update(id: string, data: {
        name?: string;
        phpVersion?: string;
        phpHandler?: string;
        webServer?: string;
    }, userId?: string, ipAddress?: string): Promise<Website>;
    /**
     * Delete website with full cascade:
     * 1. Delete all FTP accounts
     * 2. Delete all cron jobs
     * 3. Delete all backup schedules
     * 4. Remove website config (nginx + PHP-FPM pool)
     * 5. Remove legacy per-domain nginx/apache vhost configs
     * 6. Delete directory tree
     * 7. Delete system user
     * 8. Detach all domains (set websiteId = null)
     * 9. Delete website record from DB
     */
    delete(id: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Suspend website — replaces the website nginx config with a 503 page
     * for all attached domains. The original config is backed up with a `.active` suffix.
     */
    suspend(id: string, userId?: string, ipAddress?: string): Promise<Website>;
    /**
     * Activate a suspended website.
     * Restores the full nginx config by regenerating from DB fields.
     */
    activate(id: string, userId?: string, ipAddress?: string): Promise<Website>;
    /**
     * Attach a domain to this website:
     * 1. Validate domain exists and isn't attached to another website
     * 2. Update domain.websiteId in DB
     * 3. Regenerate the website's nginx config (to add the new server block)
     */
    attachDomain(websiteId: string, domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Detach a domain from this website:
     * 1. Validate domain is attached to this website
     * 2. Set domain.websiteId = null in DB
     * 3. Regenerate the website's nginx config (to remove the server block)
     * 4. Optionally set domain type to 'redirect' or 'parked'
     */
    detachDomain(websiteId: string, domainId: string, action?: 'redirect' | 'parked' | 'delete', redirectTarget?: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
}
//# sourceMappingURL=websites.service.d.ts.map