/**
 * Unified Cloudflare API Client
 *
 * Single client for all Cloudflare API interactions.
 * Handles authentication, rate limiting, error handling, and retries.
 *
 * Used by:
 * - Cloudflare module (zones, DNS, SSL, settings, rules)
 * - Tunnel module (tunnel CRUD, config, connections)
 * - SSL module (DNS-01 challenge, Origin CA)
 */
export interface CloudflareZone {
    id: string;
    name: string;
    status: 'active' | 'pending' | 'initializing' | 'moved' | 'deleted';
    paused: boolean;
    type: 'full' | 'partial';
    plan: {
        id: string;
        name: string;
        price: number;
        frequency: string;
    };
    name_servers: string[];
    original_name_servers: string[];
    created_at: string;
    activated_at: string;
}
export interface CloudflareDnsRecord {
    id: string;
    zone_id: string;
    zone_name: string;
    type: string;
    name: string;
    content: string;
    proxiable: boolean;
    proxied: boolean;
    ttl: number;
    priority?: number;
    comment?: string;
    tags: string[];
    created_at: string;
    updated_at: string;
    meta: {
        auto_added: boolean;
        source: string;
    };
}
export interface CloudflareSslSettings {
    id: string;
    value: 'off' | 'flexible' | 'full' | 'strict';
    editable: boolean;
    modified_on: string;
}
export interface CloudflareZoneSetting<T = string | boolean | number> {
    id: string;
    value: T;
    editable: boolean;
    modified_on: string;
}
export interface CloudflarePageRule {
    id: string;
    targets: Array<{
        target: 'url';
        constraint: {
            operator: 'matches';
            value: string;
        };
    }>;
    actions: Array<{
        id: string;
        value: any;
    }>;
    priority: number;
    status: 'active' | 'disabled';
    created_on: string;
    modified_on: string;
}
export interface CloudflareFirewallRule {
    id: string;
    paused: boolean;
    description: string;
    action: 'block' | 'challenge' | 'allow' | 'js_challenge' | 'log' | 'skip';
    priority: number;
    filter: {
        id: string;
        expression: string;
        paused: boolean;
        description: string;
    };
    created_on: string;
    modified_on: string;
}
export interface CloudflareAccessRule {
    id: string;
    mode: 'block' | 'challenge' | 'whitelist' | 'js_challenge';
    configuration: {
        target: 'ip' | 'ip_range' | 'country' | 'asn';
        value: string;
    };
    notes: string;
    created_on: string;
    modified_on: string;
}
export interface CloudflareRedirectRule {
    id: string;
    action: 'redirect';
    status: 'active' | 'disabled';
    expression: string;
    description: string;
    created_on: string;
    modified_on: string;
}
export interface CloudflareOriginCertificate {
    id: string;
    certificate: string;
    expires_on: string;
    request_type: 'origin-rsa' | 'origin-ecc';
    hostnames: string[];
    private_key?: string;
}
export interface CloudflareTunnelInfo {
    id: string;
    name: string;
    status: 'active' | 'inactive' | 'degraded';
    token: string;
    created_at: string;
    conns_active_at: string;
    connections: Array<{
        id: string;
        colo: string;
        ip: string;
        client_version: string;
    }>;
}
export interface CloudflareAccount {
    id: string;
    name: string;
}
export interface CreateDnsRecordInput {
    type: string;
    name: string;
    content: string;
    proxied?: boolean;
    ttl?: number;
    priority?: number;
    comment?: string;
    tags?: string[];
}
export interface UpdateDnsRecordInput {
    type?: string;
    name?: string;
    content?: string;
    proxied?: boolean;
    ttl?: number;
    priority?: number;
    comment?: string;
    tags?: string[];
}
export interface CreateFirewallRuleInput {
    action: 'block' | 'challenge' | 'allow' | 'js_challenge' | 'log' | 'skip';
    expression: string;
    description?: string;
    paused?: boolean;
    priority?: number;
}
export interface CreateAccessRuleInput {
    mode: 'block' | 'challenge' | 'whitelist' | 'js_challenge';
    target: 'ip' | 'ip_range' | 'country' | 'asn';
    value: string;
    notes?: string;
}
export interface CreatePageRuleInput {
    targets: Array<{
        target: 'url';
        constraint: {
            operator: 'matches';
            value: string;
        };
    }>;
    actions: Array<{
        id: string;
        value: any;
    }>;
    priority?: number;
    status?: 'active' | 'disabled';
}
export interface CreateOriginCertInput {
    hostnames: string[];
    request_type?: 'origin-rsa' | 'origin-ecc';
    requested_validity?: number;
    request_method?: 'http' | 'csr';
    csr?: string;
}
export declare class CloudflareClient {
    private apiToken;
    private accountId?;
    private baseUrl;
    private rateLimiter;
    private maxRetries;
    private baseDelay;
    constructor(apiToken: string, accountId?: string);
    listAccounts(): Promise<CloudflareAccount[]>;
    listZones(params?: {
        name?: string;
        status?: string;
        page?: number;
        per_page?: number;
    }): Promise<{
        zones: CloudflareZone[];
        total_count: number;
    }>;
    getZone(zoneId: string): Promise<CloudflareZone>;
    getZoneByName(name: string): Promise<CloudflareZone | null>;
    createZone(name: string, account: {
        id: string;
    }, type?: 'full' | 'partial', jumpstart?: boolean): Promise<CloudflareZone>;
    deleteZone(zoneId: string): Promise<void>;
    pauseZone(zoneId: string): Promise<void>;
    unpauseZone(zoneId: string): Promise<void>;
    listDnsRecords(zoneId: string, params?: {
        type?: string;
        name?: string;
        content?: string;
        page?: number;
        per_page?: number;
    }): Promise<{
        records: CloudflareDnsRecord[];
        total_count: number;
    }>;
    getDnsRecord(zoneId: string, recordId: string): Promise<CloudflareDnsRecord>;
    createDnsRecord(zoneId: string, input: CreateDnsRecordInput): Promise<CloudflareDnsRecord>;
    updateDnsRecord(zoneId: string, recordId: string, input: UpdateDnsRecordInput): Promise<CloudflareDnsRecord>;
    deleteDnsRecord(zoneId: string, recordId: string): Promise<void>;
    getSslSettings(zoneId: string): Promise<CloudflareSslSettings>;
    updateSslMode(zoneId: string, value: 'off' | 'flexible' | 'full' | 'strict'): Promise<CloudflareSslSettings>;
    getAlwaysUseHttps(zoneId: string): Promise<CloudflareZoneSetting>;
    setAlwaysUseHttps(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getAutomaticHttpsRewrites(zoneId: string): Promise<CloudflareZoneSetting>;
    setAutomaticHttpsRewrites(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getMinTlsVersion(zoneId: string): Promise<CloudflareZoneSetting>;
    setMinTlsVersion(zoneId: string, value: '1.0' | '1.1' | '1.2' | '1.3'): Promise<CloudflareZoneSetting>;
    getHttp2(zoneId: string): Promise<CloudflareZoneSetting>;
    setHttp2(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getHttp3(zoneId: string): Promise<CloudflareZoneSetting>;
    setHttp3(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    createOriginCertificate(input: CreateOriginCertInput): Promise<CloudflareOriginCertificate>;
    listOriginCertificates(zoneId?: string): Promise<CloudflareOriginCertificate[]>;
    revokeOriginCertificate(certId: string): Promise<void>;
    getZoneSettings(zoneId: string): Promise<CloudflareZoneSetting[]>;
    getZoneSetting(zoneId: string, settingName: string): Promise<CloudflareZoneSetting>;
    updateZoneSetting(zoneId: string, settingName: string, value: any): Promise<CloudflareZoneSetting>;
    getBrowserCacheTtl(zoneId: string): Promise<CloudflareZoneSetting>;
    setBrowserCacheTtl(zoneId: string, value: number): Promise<CloudflareZoneSetting>;
    getDevelopmentMode(zoneId: string): Promise<CloudflareZoneSetting>;
    setDevelopmentMode(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getEmailObfuscation(zoneId: string): Promise<CloudflareZoneSetting>;
    setEmailObfuscation(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getHotlinkProtection(zoneId: string): Promise<CloudflareZoneSetting>;
    setHotlinkProtection(zoneId: string, value: 'on' | 'off'): Promise<CloudflareZoneSetting>;
    getSecurityHeader(zoneId: string): Promise<CloudflareZoneSetting>;
    setSecurityHeader(zoneId: string, value: {
        strict_transport_security: {
            enabled: boolean;
            max_age: number;
            include_subdomains: boolean;
            preload: boolean;
        };
    }): Promise<CloudflareZoneSetting>;
    purgeEverything(zoneId: string): Promise<void>;
    purgeCacheByUrls(zoneId: string, urls: string[]): Promise<void>;
    purgeCacheByTags(zoneId: string, tags: string[]): Promise<void>;
    listPageRules(zoneId: string): Promise<CloudflarePageRule[]>;
    createPageRule(zoneId: string, input: CreatePageRuleInput): Promise<CloudflarePageRule>;
    updatePageRule(zoneId: string, ruleId: string, input: Partial<CreatePageRuleInput>): Promise<CloudflarePageRule>;
    deletePageRule(zoneId: string, ruleId: string): Promise<void>;
    listFirewallRules(zoneId: string): Promise<CloudflareFirewallRule[]>;
    createFirewallRule(zoneId: string, input: CreateFirewallRuleInput): Promise<CloudflareFirewallRule>;
    updateFirewallRule(zoneId: string, ruleId: string, input: Partial<CreateFirewallRuleInput> & {
        filterId?: string;
    }): Promise<CloudflareFirewallRule>;
    deleteFirewallRule(zoneId: string, ruleId: string): Promise<void>;
    listAccessRules(zoneId: string): Promise<CloudflareAccessRule[]>;
    createAccessRule(zoneId: string, input: CreateAccessRuleInput): Promise<CloudflareAccessRule>;
    deleteAccessRule(zoneId: string, ruleId: string): Promise<void>;
    listTunnels(accountId?: string): Promise<CloudflareTunnelInfo[]>;
    getTunnel(tunnelId: string, accountId?: string): Promise<CloudflareTunnelInfo>;
    createTunnel(name: string, accountId?: string, configSrc?: 'cloudflare' | 'local'): Promise<{
        id: string;
        token: string;
    }>;
    deleteTunnel(tunnelId: string, accountId?: string): Promise<void>;
    getTunnelConfig(tunnelId: string, accountId?: string): Promise<any>;
    updateTunnelConfig(tunnelId: string, config: any, accountId?: string): Promise<any>;
    verifyDns(zoneId: string): Promise<{
        nameservers: string[];
        status: string;
    }>;
    verifyToken(): Promise<{
        valid: boolean;
        status: string;
        type: 'user' | 'account';
        accounts?: any[];
    }>;
    private request;
    private requestPaginated;
    private requestRaw;
    private requestWithRetry;
}
//# sourceMappingURL=cloudflare-client.d.ts.map