import { type Webhook, type NewWebhook, type WebhookDelivery, type NewWebhookDelivery } from '../../db/schema/webhooks.js';
export declare class WebhooksService {
    list(orgId: string): Promise<Webhook[]>;
    create(orgId: string, data: Omit<NewWebhook, 'id' | 'orgId' | 'createdAt'>): Promise<Webhook>;
    get(id: string): Promise<Webhook | null>;
    update(id: string, data: Partial<Pick<Webhook, 'name' | 'url' | 'events' | 'enabled' | 'headers'>>): Promise<Webhook>;
    delete(id: string): Promise<void>;
    regenerateSecret(id: string): Promise<string>;
    listDeliveries(webhookId: string, limit?: number): Promise<WebhookDelivery[]>;
    recordDelivery(data: Omit<NewWebhookDelivery, 'id' | 'createdAt'>): Promise<WebhookDelivery>;
    triggerEvent(orgId: string, event: string, payload: Record<string, unknown>): Promise<void>;
}
export declare const webhooksService: WebhooksService;
//# sourceMappingURL=webhooks.service.d.ts.map