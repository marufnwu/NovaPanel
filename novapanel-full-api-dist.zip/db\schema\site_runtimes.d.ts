export declare const siteRuntimes: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
    name: "site_runtimes";
    schema: undefined;
    columns: {
        id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "id";
            tableName: "site_runtimes";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: true;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        siteId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "site_id";
            tableName: "site_runtimes";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        runtimeConfig: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "runtime_config";
            tableName: "site_runtimes";
            dataType: "json";
            columnType: "SQLiteTextJson";
            data: unknown;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: undefined;
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {}>;
        webServer: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "web_server";
            tableName: "site_runtimes";
            dataType: "string";
            columnType: "SQLiteText";
            data: "nginx" | "apache";
            driverParam: string;
            notNull: true;
            hasDefault: true;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: ["nginx", "apache"];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        createdAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "created_at";
            tableName: "site_runtimes";
            dataType: "date";
            columnType: "SQLiteTimestamp";
            data: Date;
            driverParam: number;
            notNull: true;
            hasDefault: true;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: undefined;
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {}>;
        updatedAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "updated_at";
            tableName: "site_runtimes";
            dataType: "date";
            columnType: "SQLiteTimestamp";
            data: Date;
            driverParam: number;
            notNull: true;
            hasDefault: true;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: undefined;
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {}>;
    };
    dialect: "sqlite";
}>;
export type SiteRuntime = typeof siteRuntimes.$inferSelect;
export type NewSiteRuntime = typeof siteRuntimes.$inferInsert;
export interface RuntimeConfig {
    schemaVersion: number;
    runtime: 'php' | 'node' | 'python' | 'static' | 'docker' | 'ruby' | 'go';
    version?: string;
    buildCommand?: string;
    startCommand?: string;
    healthCheckPath?: string;
    phpVersion?: string;
    nodeVersion?: string;
    pythonVersion?: string;
    venvPath?: string;
    dockerfile?: string;
    dockerImage?: string;
}
//# sourceMappingURL=site_runtimes.d.ts.map