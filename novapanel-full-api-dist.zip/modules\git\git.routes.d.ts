import type { FastifyInstance } from 'fastify';
export default function gitRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=git.routes.d.ts.map