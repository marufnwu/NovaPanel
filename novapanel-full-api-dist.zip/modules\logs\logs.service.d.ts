export interface SystemLogEntry {
    timestamp: string;
    level: string;
    message: string;
    source?: string;
}
/**
 * Read the last N lines from the system log file.
 * Tries /var/log/syslog first (Debian/Ubuntu), falls back to /var/log/messages (RHEL/CentOS).
 */
export declare function getSystemLogs(lines?: number): Promise<{
    log: string;
    entries: SystemLogEntry[];
}>;
//# sourceMappingURL=logs.service.d.ts.map