export declare class SchedulerService {
    private tasks;
    private getAdminUserId;
    start(): void;
    stop(): void;
}
//# sourceMappingURL=scheduler.d.ts.map