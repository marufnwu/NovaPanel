/**
 * Unified Cloudflare API Client
 *
 * Single client for all Cloudflare API interactions.
 * Handles authentication, rate limiting, error handling, and retries.
 *
 * Used by:
 * - Cloudflare module (zones, DNS, SSL, settings, rules)
 * - Tunnel module (tunnel CRUD, config, connections)
 * - SSL module (DNS-01 challenge, Origin CA)
 */
import { logger } from '../config/logger.js';
import { AppError } from '../errors.js';
// --- Rate Limiter ---
class TokenBucketRateLimiter {
    tokens;
    maxTokens;
    refillRate; // tokens per ms
    lastRefill;
    constructor(maxTokens, refillPerSecond) {
        this.maxTokens = maxTokens;
        this.tokens = maxTokens;
        this.refillRate = refillPerSecond / 1000;
        this.lastRefill = Date.now();
    }
    async acquire() {
        this.refill();
        if (this.tokens >= 1) {
            this.tokens -= 1;
            return;
        }
        // Wait for a token to become available
        const waitMs = Math.ceil((1 - this.tokens) / this.refillRate);
        await new Promise(resolve => setTimeout(resolve, waitMs));
        this.refill();
        this.tokens -= 1;
    }
    refill() {
        const now = Date.now();
        const elapsed = now - this.lastRefill;
        this.tokens = Math.min(this.maxTokens, this.tokens + elapsed * this.refillRate);
        this.lastRefill = now;
    }
}
// --- Cloudflare API Client ---
export class CloudflareClient {
    apiToken;
    accountId;
    baseUrl = 'https://api.cloudflare.com/client/v4';
    rateLimiter = new TokenBucketRateLimiter(100, 10); // 100 burst, 10/sec sustained
    maxRetries = 3;
    baseDelay = 1000; // 1s
    constructor(apiToken, accountId) {
        this.apiToken = apiToken;
        this.accountId = accountId;
    }
    // ==========================================================================
    // Account Operations
    // ==========================================================================
    async listAccounts() {
        const data = await this.request('GET', '/accounts');
        return data;
    }
    // ==========================================================================
    // Zone Operations
    // ==========================================================================
    async listZones(params) {
        const query = new URLSearchParams();
        if (params?.name)
            query.set('name', params.name);
        if (params?.status)
            query.set('status', params.status);
        if (params?.page)
            query.set('page', String(params.page));
        if (params?.per_page)
            query.set('per_page', String(params.per_page));
        const qs = query.toString();
        const path = `/zones${qs ? `?${qs}` : ''}`;
        const data = await this.requestPaginated('GET', path);
        return { zones: data.results, total_count: data.total_count };
    }
    async getZone(zoneId) {
        return this.request('GET', `/zones/${zoneId}`);
    }
    async getZoneByName(name) {
        const { zones } = await this.listZones({ name });
        return zones[0] || null;
    }
    async createZone(name, account, type = 'full', jumpstart) {
        return this.request('POST', '/zones', {
            name,
            account,
            type,
            jump_start: jumpstart,
        });
    }
    async deleteZone(zoneId) {
        await this.request('DELETE', `/zones/${zoneId}`);
    }
    async pauseZone(zoneId) {
        await this.request('PATCH', `/zones/${zoneId}`, { paused: true });
    }
    async unpauseZone(zoneId) {
        await this.request('PATCH', `/zones/${zoneId}`, { paused: false });
    }
    // ==========================================================================
    // DNS Record Operations
    // ==========================================================================
    async listDnsRecords(zoneId, params) {
        const query = new URLSearchParams();
        if (params?.type)
            query.set('type', params.type);
        if (params?.name)
            query.set('name', params.name);
        if (params?.content)
            query.set('content', params.content);
        if (params?.page)
            query.set('page', String(params.page));
        if (params?.per_page)
            query.set('per_page', String(params.per_page));
        const qs = query.toString();
        const path = `/zones/${zoneId}/dns_records${qs ? `?${qs}` : ''}`;
        const data = await this.requestPaginated('GET', path);
        return { records: data.results, total_count: data.total_count };
    }
    async getDnsRecord(zoneId, recordId) {
        return this.request('GET', `/zones/${zoneId}/dns_records/${recordId}`);
    }
    async createDnsRecord(zoneId, input) {
        return this.request('POST', `/zones/${zoneId}/dns_records`, input);
    }
    async updateDnsRecord(zoneId, recordId, input) {
        return this.request('PATCH', `/zones/${zoneId}/dns_records/${recordId}`, input);
    }
    async deleteDnsRecord(zoneId, recordId) {
        await this.request('DELETE', `/zones/${zoneId}/dns_records/${recordId}`);
    }
    // ==========================================================================
    // SSL/TLS Operations
    // ==========================================================================
    async getSslSettings(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/ssl`);
    }
    async updateSslMode(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/ssl`, { value });
    }
    async getAlwaysUseHttps(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/always_use_https`);
    }
    async setAlwaysUseHttps(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/always_use_https`, { value });
    }
    async getAutomaticHttpsRewrites(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/automatic_https_rewrites`);
    }
    async setAutomaticHttpsRewrites(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/automatic_https_rewrites`, { value });
    }
    async getMinTlsVersion(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/min_tls_version`);
    }
    async setMinTlsVersion(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/min_tls_version`, { value });
    }
    async getHttp2(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/http2`);
    }
    async setHttp2(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/http2`, { value });
    }
    async getHttp3(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings/http3`);
    }
    async setHttp3(zoneId, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/http3`, { value });
    }
    // ==========================================================================
    // Origin CA Certificates
    // ==========================================================================
    async createOriginCertificate(input) {
        return this.request('POST', '/certificates', {
            hostnames: input.hostnames,
            request_type: input.request_type || 'origin-rsa',
            requested_validity: input.requested_validity || 5475,
            request_method: input.request_method || 'http',
            csr: input.csr,
        });
    }
    async listOriginCertificates(zoneId) {
        const params = new URLSearchParams();
        if (zoneId)
            params.set('zone_id', zoneId);
        const qs = params.toString();
        const data = await this.requestPaginated('GET', `/certificates${qs ? `?${qs}` : ''}`);
        return data.results;
    }
    async revokeOriginCertificate(certId) {
        await this.request('DELETE', `/certificates/${certId}`);
    }
    // ==========================================================================
    // Zone Settings
    // ==========================================================================
    async getZoneSettings(zoneId) {
        return this.request('GET', `/zones/${zoneId}/settings`);
    }
    async getZoneSetting(zoneId, settingName) {
        return this.request('GET', `/zones/${zoneId}/settings/${settingName}`);
    }
    async updateZoneSetting(zoneId, settingName, value) {
        return this.request('PATCH', `/zones/${zoneId}/settings/${settingName}`, { value });
    }
    // Convenience methods for common settings
    async getBrowserCacheTtl(zoneId) {
        return this.getZoneSetting(zoneId, 'browser_cache_ttl');
    }
    async setBrowserCacheTtl(zoneId, value) {
        return this.updateZoneSetting(zoneId, 'browser_cache_ttl', value);
    }
    async getDevelopmentMode(zoneId) {
        return this.getZoneSetting(zoneId, 'development_mode');
    }
    async setDevelopmentMode(zoneId, value) {
        return this.updateZoneSetting(zoneId, 'development_mode', value);
    }
    async getEmailObfuscation(zoneId) {
        return this.getZoneSetting(zoneId, 'email_obfuscation');
    }
    async setEmailObfuscation(zoneId, value) {
        return this.updateZoneSetting(zoneId, 'email_obfuscation', value);
    }
    async getHotlinkProtection(zoneId) {
        return this.getZoneSetting(zoneId, 'hotlink_protection');
    }
    async setHotlinkProtection(zoneId, value) {
        return this.updateZoneSetting(zoneId, 'hotlink_protection', value);
    }
    async getSecurityHeader(zoneId) {
        return this.getZoneSetting(zoneId, 'security_header');
    }
    async setSecurityHeader(zoneId, value) {
        return this.updateZoneSetting(zoneId, 'security_header', value);
    }
    // ==========================================================================
    // Cache Operations
    // ==========================================================================
    async purgeEverything(zoneId) {
        await this.request('POST', `/zones/${zoneId}/cache/purge`, { purge_everything: true });
    }
    async purgeCacheByUrls(zoneId, urls) {
        await this.request('POST', `/zones/${zoneId}/cache/purge`, { files: urls });
    }
    async purgeCacheByTags(zoneId, tags) {
        await this.request('POST', `/zones/${zoneId}/cache/purge`, { tags });
    }
    // ==========================================================================
    // Page Rules (Legacy)
    // ==========================================================================
    async listPageRules(zoneId) {
        return this.request('GET', `/zones/${zoneId}/pagerules`);
    }
    async createPageRule(zoneId, input) {
        return this.request('POST', `/zones/${zoneId}/pagerules`, input);
    }
    async updatePageRule(zoneId, ruleId, input) {
        return this.request('PATCH', `/zones/${zoneId}/pagerules/${ruleId}`, input);
    }
    async deletePageRule(zoneId, ruleId) {
        await this.request('DELETE', `/zones/${zoneId}/pagerules/${ruleId}`);
    }
    // ==========================================================================
    // Firewall Operations
    // ==========================================================================
    async listFirewallRules(zoneId) {
        return this.request('GET', `/zones/${zoneId}/firewall/rules`);
    }
    async createFirewallRule(zoneId, input) {
        // First create the filter, then the rule
        const filter = await this.request('POST', `/zones/${zoneId}/filters`, {
            expression: input.expression,
            paused: input.paused ?? false,
            description: input.description || '',
        });
        return this.request('POST', `/zones/${zoneId}/firewall/rules`, {
            action: input.action,
            filter: { id: filter.id },
            description: input.description,
            paused: input.paused ?? false,
            priority: input.priority,
        });
    }
    async updateFirewallRule(zoneId, ruleId, input) {
        const body = {};
        if (input.action)
            body.action = input.action;
        if (input.description !== undefined)
            body.description = input.description;
        if (input.paused !== undefined)
            body.paused = input.paused;
        if (input.priority !== undefined)
            body.priority = input.priority;
        if (input.expression && input.filterId) {
            // Update the filter expression too
            await this.request('PUT', `/zones/${zoneId}/filters/${input.filterId}`, {
                expression: input.expression,
                paused: input.paused ?? false,
                description: input.description || '',
            });
        }
        return this.request('PATCH', `/zones/${zoneId}/firewall/rules/${ruleId}`, body);
    }
    async deleteFirewallRule(zoneId, ruleId) {
        await this.request('DELETE', `/zones/${zoneId}/firewall/rules/${ruleId}`);
    }
    // Access Rules (IP allowlist/blocklist)
    async listAccessRules(zoneId) {
        return this.request('GET', `/zones/${zoneId}/firewall/access_rules/rules`);
    }
    async createAccessRule(zoneId, input) {
        return this.request('POST', `/zones/${zoneId}/firewall/access_rules/rules`, {
            mode: input.mode,
            configuration: { target: input.target, value: input.value },
            notes: input.notes || '',
        });
    }
    async deleteAccessRule(zoneId, ruleId) {
        await this.request('DELETE', `/zones/${zoneId}/firewall/access_rules/rules/${ruleId}`);
    }
    // ==========================================================================
    // Tunnel Operations
    // ==========================================================================
    async listTunnels(accountId) {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        return this.request('GET', `/accounts/${acctId}/cfd_tunnel`);
    }
    async getTunnel(tunnelId, accountId) {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        return this.request('GET', `/accounts/${acctId}/cfd_tunnel/${tunnelId}`);
    }
    async createTunnel(name, accountId, configSrc = 'cloudflare') {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        return this.request('POST', `/accounts/${acctId}/cfd_tunnel`, {
            name,
            config_src: configSrc,
        });
    }
    async deleteTunnel(tunnelId, accountId) {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        await this.request('DELETE', `/accounts/${acctId}/cfd_tunnel/${tunnelId}`);
    }
    async getTunnelConfig(tunnelId, accountId) {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        return this.request('GET', `/accounts/${acctId}/cfd_tunnel/${tunnelId}/configurations`);
    }
    async updateTunnelConfig(tunnelId, config, accountId) {
        const acctId = accountId || this.accountId;
        if (!acctId)
            throw new AppError(400, 'ACCOUNT_REQUIRED', 'Account ID required for tunnel operations');
        return this.request('PUT', `/accounts/${acctId}/cfd_tunnel/${tunnelId}/configurations`, { config });
    }
    // ==========================================================================
    // DNS Verification
    // ==========================================================================
    async verifyDns(zoneId) {
        const zone = await this.getZone(zoneId);
        return {
            nameservers: zone.name_servers || [],
            status: zone.status,
        };
    }
    // ==========================================================================
    // Token Verification
    // ==========================================================================
    async verifyToken() {
        // Try user token verification first
        try {
            const data = await this.requestRaw('GET', '/user/tokens/verify');
            if (data.success) {
                return { valid: true, status: data.result?.status || 'active', type: 'user' };
            }
        }
        catch {
            // Not a user token, try account-scoped
        }
        // Try account-scoped verification
        try {
            const data = await this.requestPaginated('GET', '/accounts');
            if (data.success !== false) {
                return { valid: true, status: 'active', type: 'account', accounts: data.results };
            }
        }
        catch {
            // Invalid token
        }
        throw new AppError(400, 'INVALID_TOKEN', 'Invalid Cloudflare API token');
    }
    // ==========================================================================
    // Core HTTP Methods (private)
    // ==========================================================================
    async request(method, path, body) {
        const response = await this.requestWithRetry(method, path, body);
        if (!response.success) {
            const error = response.errors?.[0];
            throw new AppError(error?.code === 1000 ? 400 : 500, 'CF_API_ERROR', error?.message || 'Cloudflare API error');
        }
        return response.result;
    }
    async requestPaginated(method, path, body) {
        const response = await this.requestWithRetry(method, path, body);
        return {
            results: response.result || [],
            total_count: response.result_info?.total_count || 0,
            success: response.success,
        };
    }
    async requestRaw(method, path, body) {
        return this.requestWithRetry(method, path, body);
    }
    async requestWithRetry(method, path, body, attempt = 0) {
        await this.rateLimiter.acquire();
        const url = `${this.baseUrl}${path}`;
        const options = {
            method,
            headers: {
                'Authorization': `Bearer ${this.apiToken}`,
                'Content-Type': 'application/json',
            },
        };
        if (body && method !== 'GET') {
            options.body = JSON.stringify(body);
        }
        try {
            const response = await fetch(url, options);
            const data = await response.json();
            // Rate limit handling
            if (response.status === 429) {
                if (attempt < this.maxRetries) {
                    const delay = this.baseDelay * Math.pow(2, attempt);
                    logger.warn({ attempt, delay, path }, 'Cloudflare API rate limited, retrying');
                    await new Promise(resolve => setTimeout(resolve, delay));
                    return this.requestWithRetry(method, path, body, attempt + 1);
                }
                throw new AppError(429, 'CF_RATE_LIMITED', 'Cloudflare API rate limit exceeded');
            }
            // Server error - retry
            if (response.status >= 500 && attempt < this.maxRetries) {
                const delay = this.baseDelay * Math.pow(2, attempt);
                logger.warn({ attempt, delay, path, status: response.status }, 'Cloudflare API server error, retrying');
                await new Promise(resolve => setTimeout(resolve, delay));
                return this.requestWithRetry(method, path, body, attempt + 1);
            }
            // Client errors - don't retry
            if (response.status >= 400 && response.status < 500 && response.status !== 429) {
                // Return the error response so callers can handle it
                return data;
            }
            return data;
        }
        catch (error) {
            if (error instanceof AppError)
                throw error;
            if (attempt < this.maxRetries) {
                const delay = this.baseDelay * Math.pow(2, attempt);
                logger.warn({ attempt, delay, path, error: error.message }, 'Cloudflare API request failed, retrying');
                await new Promise(resolve => setTimeout(resolve, delay));
                return this.requestWithRetry(method, path, body, attempt + 1);
            }
            logger.error({ error, path, method }, 'Cloudflare API request failed after retries');
            throw new AppError(500, 'CF_API_ERROR', `Cloudflare API request failed: ${error.message}`);
        }
    }
}
//# sourceMappingURL=cloudflare-client.js.map