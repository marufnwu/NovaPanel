import type { FastifyInstance } from 'fastify';
export default function projectRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=projects.routes.d.ts.map