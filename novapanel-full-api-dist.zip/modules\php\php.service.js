import { db } from '../../db/index.js';
import { domains } from '../../db/schema/domains.js';
import { AppError } from '../../errors.js';
import { phpFpmServices, PhpFpmService } from '../../services/php-fpm.service.js';
import { auditService } from '../audit/audit.service.js';
export class PhpService {
    async listVersions() {
        return PhpFpmService.getInstalledVersions();
    }
    async getVersion(_version) {
        return { version: _version, status: 'available' };
    }
    async installVersion(_version, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP install requires OS-level package manager - use server terminal');
    }
    async uninstallVersion(_version, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP uninstall requires OS-level package manager - use server terminal');
    }
    async getSettings(_version) {
        return { disableFunctions: [], uploadMaxFilesize: '8M', postMaxSize: '8M', maxExecutionTime: 30, memoryLimit: '128M' };
    }
    async updateSettings(_version, _settings, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP settings requires php-fpm pool config files - not available in v5 schema');
    }
    async restartFpm(version, userId, _ipAddress) {
        const svc = phpFpmServices[version];
        if (!svc)
            throw new AppError(400, 'INVALID_VERSION', `PHP ${version} not available`);
        await svc.restart();
        auditService.log({ userId, action: 'php.restart', resource: `php:${version}`, ipAddress: _ipAddress }).catch(() => { });
        return { success: true };
    }
    async getPoolConfig(_version, _domainId) {
        return '';
    }
    async updatePoolConfig(_version, _domainId, _config, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP pool config update requires php-fpm pool config files - not available in v5 schema');
    }
    async listDisabledFunctions(_version) {
        return [];
    }
    async updateDisabledFunctions(_version, _functions, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP functions update requires php-fpm pool config files - not available in v5 schema');
    }
    async getUploadLimits(_version) {
        return { uploadMaxFilesize: '8M', postMaxSize: '8M', maxExecutionTime: 30, maxInputTime: 60 };
    }
    async updateUploadLimits(_version, _limits, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP limits update requires php-fpm pool config files - not available in v5 schema');
    }
    async getOpcodeCacheSettings(_version) {
        return { enabled: false };
    }
    async updateOpcodeCacheSettings(_version, _settings, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP opcode cache update requires php-fpm pool config files - not available in v5 schema');
    }
    async getMemlimit(_version) {
        return '128M';
    }
    async setMemlimit(_version, _memlimit, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP memlimit set requires php-fpm pool config files - not available in v5 schema');
    }
    async listDomainsWithPhpVersion() {
        return db.select({ id: domains.id, name: domains.name, type: domains.type }).from(domains);
    }
    async setDomainPhpVersion(_domainId, _version, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP version set requires domain-level php version tracking - not available in v5 schema');
    }
    async bulkSetPhpVersion(_domainIds, _version, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'PHP bulk version set requires domain-level php version tracking - not available in v5 schema');
    }
}
export const phpService = new PhpService();
//# sourceMappingURL=php.service.js.map