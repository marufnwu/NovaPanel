import type { FastifyInstance } from 'fastify';
export default function tunnelRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=tunnel.routes.d.ts.map