/**
 * Hash a password using Argon2id
 */
export declare function hashPassword(password: string): Promise<string>;
/**
 * Verify a password against an Argon2id hash
 */
export declare function verifyPassword(password: string, hashed: string): Promise<boolean>;
/**
 * Generate a SHA-256 hash of a string
 */
export declare function sha256(input: string): string;
/**
 * Hash a token for storage (SHA-256)
 */
export declare function hashToken(token: string): string;
/**
 * Generate a random token (hex)
 */
export declare function generateToken(prefix?: string): string;
/**
 * Generate an API token with prefix
 */
export declare function generateApiToken(): string;
/**
 * Encrypt a string using AES-256-GCM
 */
export declare function encrypt(plaintext: string): string;
/**
 * Decrypt a string using AES-256-GCM
 */
export declare function decrypt(ciphertext: string): string;
//# sourceMappingURL=crypto.d.ts.map