import { db } from '../../db/index.js';
import { plugins } from '../../db/schema/plugins.js';
import { eq, desc } from 'drizzle-orm';
import { nanoid } from 'nanoid';
export class PluginsService {
    async list() {
        return db.select().from(plugins).orderBy(desc(plugins.createdAt));
    }
    async get(id) {
        const [p] = await db.select().from(plugins).where(eq(plugins.id, id)).limit(1);
        return p ?? null;
    }
    async create(data) {
        const plugin = {
            id: nanoid(),
            name: data.name,
            version: data.version,
            description: data.description,
            author: data.author,
            manifest: data.manifest ?? {},
            enabled: data.enabled ?? false,
            config: data.config ?? {},
            createdAt: new Date(),
        };
        await db.insert(plugins).values(plugin);
        const [created] = await db.select().from(plugins).where(eq(plugins.id, plugin.id)).limit(1);
        return created;
    }
    async update(id, data) {
        await db.update(plugins).set({ ...data, updatedAt: new Date() }).where(eq(plugins.id, id));
        const [updated] = await db.select().from(plugins).where(eq(plugins.id, id)).limit(1);
        if (!updated)
            throw new Error('Plugin not found');
        return updated;
    }
    async delete(id) {
        await db.delete(plugins).where(eq(plugins.id, id));
    }
    async toggle(id) {
        const plugin = await this.get(id);
        if (!plugin)
            throw new Error('Plugin not found');
        return this.update(id, { enabled: !plugin.enabled });
    }
    async updateConfig(id, config) {
        return this.update(id, { config });
    }
}
export const pluginsService = new PluginsService();
//# sourceMappingURL=plugins.service.js.map