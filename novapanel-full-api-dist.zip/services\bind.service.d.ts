import type { SystemService, ServiceInfo } from './types.js';
export declare class BindService implements SystemService {
    readonly name = "bind9";
    readonly displayName = "BIND9";
    private readonly namedConfLocal;
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    /**
     * Check a zone file for syntax errors
     */
    checkZone(zoneName: string, zoneFile: string): Promise<{
        valid: boolean;
        output: string;
    }>;
    /**
     * Write a zone file to disk and reload BIND
     */
    writeZoneFile(domain: string, content: string): Promise<void>;
    /**
     * Remove a zone file from disk.
     */
    removeZoneFile(domain: string): Promise<void>;
    /**
     * Add a zone declaration to named.conf.local so BIND serves the zone.
     * Idempotent — does nothing if the zone block already exists.
     */
    addZoneToConfig(domain: string): Promise<void>;
    /**
     * Remove a zone declaration from named.conf.local.
     */
    removeZoneFromConfig(domain: string): Promise<void>;
    /**
     * Reload BIND via systemctl (alternative to rndc reload).
     */
    reloadBind(): Promise<void>;
}
export declare const bindService: BindService;
//# sourceMappingURL=bind.service.d.ts.map