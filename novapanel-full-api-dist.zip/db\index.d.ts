import * as schema from './schema/index.js';
export declare const db: import("drizzle-orm/libsql").LibSQLDatabase<typeof schema> & {
    $client: import("@libsql/client").Client;
};
export type Database = typeof db;
//# sourceMappingURL=index.d.ts.map