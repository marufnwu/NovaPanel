export {};
//# sourceMappingURL=security.service.test.d.ts.map