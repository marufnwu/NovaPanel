export interface CertInfo {
    id: string;
    domainId: string;
    domain: string;
    type: string;
    enabled: boolean;
    issuer: string;
    expiresAt: Date | null;
    issuedAt: Date | null;
    autoRenew: boolean;
    daysUntilExpiry: number | null;
    sanDomains: string[];
    fingerprint: string | null;
    hstsEnabled?: boolean;
    hstsMaxAge?: number;
    hstsIncludeSubdomains?: boolean;
    ocspStapling?: boolean;
}
interface IssueLEParams {
    email: string;
    enableWww?: boolean;
    sanDomains?: string[];
    wildcard?: boolean;
    challengeType?: 'http-01' | 'dns-01';
}
export declare class SslService {
    listAll(): Promise<CertInfo[]>;
    getCertificate(domainId: string): Promise<{
        enabled: boolean;
        certificate: CertInfo | null;
    }>;
    listExpiring(days: number): Promise<CertInfo[]>;
    issueLetsEncrypt(domainId: string, params: IssueLEParams, userId?: string, ipAddress?: string): Promise<CertInfo>;
    uploadCustom(domainId: string, certificate: string, privateKey: string, chain: string, userId?: string, ipAddress?: string): Promise<CertInfo>;
    generateSelfSigned(domainId: string, days: number, userId?: string, ipAddress?: string): Promise<CertInfo>;
    removeCertificate(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    renewCertificate(domainId: string, userId?: string, ipAddress?: string): Promise<CertInfo>;
    getCertDetails(domainId: string): Promise<CertInfo & {
        hasChain: boolean;
        hasPrivateKey: boolean;
    }>;
    toggleAutoRenew(domainId: string, autoRenew: boolean, userId?: string, ipAddress?: string): Promise<void>;
    downloadCert(domainId: string, file: 'cert' | 'key' | 'chain'): Promise<string>;
    validateChain(domainId: string): Promise<{
        valid: boolean;
        issues: string[];
        chainComplete: boolean;
        intermediateCount: number;
        rootTrusted: boolean;
        expiresAt: string | null;
    }>;
    checkMixedContent(domainId: string): Promise<{
        url: string;
        issues: Array<{
            resourceUrl: string;
            type: string;
            line?: number;
        }>;
        totalIssues: number;
        scannedAt: string;
    }>;
    updateHsts(domainId: string, enabled: boolean, maxAge?: number, includeSubdomains?: boolean): Promise<void>;
    updateOcspStapling(_domainId: string, _enabled: boolean): Promise<void>;
    deleteCert(id: string): Promise<void>;
    renewCert(id: string): Promise<void>;
    private buildCertInfo;
}
export declare const sslService: SslService;
export {};
//# sourceMappingURL=ssl.service.d.ts.map