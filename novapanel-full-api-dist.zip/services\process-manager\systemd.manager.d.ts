import { ProcessManager, ProcessStatus, ProcessConfig } from './types.js';
export declare class SystemdManager implements ProcessManager {
    private getServiceName;
    isAvailable(): Promise<boolean>;
    start(config: ProcessConfig): Promise<void>;
    stop(name: string): Promise<void>;
    restart(name: string): Promise<void>;
    getStatus(name: string): Promise<ProcessStatus>;
    logs(name: string, lines?: number): Promise<string>;
    delete(name: string): Promise<void>;
}
export declare const systemdManager: SystemdManager;
//# sourceMappingURL=systemd.manager.d.ts.map