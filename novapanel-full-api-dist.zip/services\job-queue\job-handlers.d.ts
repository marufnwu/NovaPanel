import { JobHandler } from './types.js';
export declare const nginxReloadHandler: JobHandler;
export declare const nginxConfigRegenerateHandler: JobHandler;
export declare const pm2RestartHandler: JobHandler;
export declare const pm2StopHandler: JobHandler;
export declare const deploymentBuildHandler: JobHandler;
export declare const deploymentRollbackHandler: JobHandler;
export declare const metricCollectHandler: JobHandler;
export declare const alertEvaluateHandler: JobHandler;
export declare const jobHandlers: Record<string, JobHandler>;
//# sourceMappingURL=job-handlers.d.ts.map