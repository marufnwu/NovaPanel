import { AppError } from '../errors.js';
export class DeploymentService {
    async getDeployments(_siteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async getDeployment(_id) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async getCurrentDeployment(_siteId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async create(_data) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async build(_data) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async deploy(_deploymentId) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async rollback(_siteId, _userId, _ipAddress) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
    async deleteDeployment(_id) {
        throw new AppError(501, 'NOT_IMPLEMENTED', 'Deployment service not yet migrated to v5 schema');
    }
}
export const deploymentService = new DeploymentService();
//# sourceMappingURL=deployment.service.js.map