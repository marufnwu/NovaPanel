import { db } from '../../db/index.js';
import { apiKeys } from '../../db/schema/index.js';
import { eq } from 'drizzle-orm';
import { hashToken } from '../../utils/crypto.js';
import { authService } from '../auth/auth.service.js';
export class TokensService {
    async createToken(userId, name, expiresAt, ipAddress) {
        return authService.generateApiKey(userId, name, expiresAt, ipAddress);
    }
    async listTokens(userId) {
        return db.select({
            id: apiKeys.id,
            name: apiKeys.name,
            keyPrefix: apiKeys.keyPrefix,
            createdAt: apiKeys.createdAt,
            expiresAt: apiKeys.expiresAt,
        }).from(apiKeys).where(eq(apiKeys.userId, userId));
    }
    async revokeToken(tokenId, userId, ipAddress) {
        return authService.revokeApiKey(tokenId, userId, ipAddress);
    }
    async validateToken(token) {
        const keyHash = hashToken(token);
        const keyPrefix = token.substring(0, 8);
        const [apiKey] = await db.select().from(apiKeys)
            .where(eq(apiKeys.keyHash, keyHash))
            .limit(1);
        if (!apiKey)
            return null;
        if (apiKey.expiresAt && apiKey.expiresAt < new Date())
            return null;
        return {
            valid: true,
            user: { id: apiKey.userId || '' },
            token: { id: apiKey.id, permissions: typeof apiKey.permissions === 'string' ? apiKey.permissions : JSON.stringify(apiKey.permissions || '[]') },
        };
    }
}
export const tokensService = new TokensService();
//# sourceMappingURL=tokens.service.js.map