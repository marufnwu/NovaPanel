-- Create addon_domains table for cPanel-style addon domain management
-- Addon domains are additional domains that point to a site but have their own document root
-- When created, they can optionally auto-create a hidden site

CREATE TABLE IF NOT EXISTS addon_domains (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES websites(id) ON DELETE CASCADE,
  name TEXT NOT NULL UNIQUE,  -- The addon domain name (e.g., otherdomain.com)
  document_root TEXT NOT NULL,  -- Path relative to site's root
  cname_alias TEXT,  -- Optional CNAME alias (e.g., www.otherdomain.com)
  auto_created_site_id TEXT REFERENCES websites(id) ON DELETE SET NULL,  -- If addon has its own site
  status TEXT DEFAULT 'active' NOT NULL CHECK(status IN ('active', 'suspended', 'pending')),
  created_at INTEGER DEFAULT (unixepoch()) NOT NULL
);

-- Index for fast lookup by site
CREATE INDEX idx_addon_domains_site ON addon_domains(site_id);

-- Index for fast lookup by name
CREATE INDEX idx_addon_domains_name ON addon_domains(name);

-- Index for auto_created_site_id to find addon by its created site
CREATE INDEX idx_addon_domains_auto_site ON addon_domains(auto_created_site_id);