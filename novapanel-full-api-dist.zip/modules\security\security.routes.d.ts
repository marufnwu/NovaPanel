import type { FastifyInstance } from 'fastify';
export default function securityRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=security.routes.d.ts.map