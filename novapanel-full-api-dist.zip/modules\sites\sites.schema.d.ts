import { z } from 'zod';
export declare const runtimeConfigSchema: z.ZodObject<{
    schemaVersion: z.ZodDefault<z.ZodNumber>;
    runtime: z.ZodEnum<["docker", "node", "python", "php", "go", "ruby", "rust", "static"]>;
    version: z.ZodOptional<z.ZodString>;
    buildCommand: z.ZodOptional<z.ZodString>;
    startCommand: z.ZodOptional<z.ZodString>;
    healthCheckPath: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    schemaVersion: number;
    runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
    version?: string | undefined;
    buildCommand?: string | undefined;
    startCommand?: string | undefined;
    healthCheckPath?: string | undefined;
}, {
    runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
    schemaVersion?: number | undefined;
    version?: string | undefined;
    buildCommand?: string | undefined;
    startCommand?: string | undefined;
    healthCheckPath?: string | undefined;
}>;
export declare const createSiteSchema: z.ZodObject<{
    name: z.ZodString;
    projectId: z.ZodOptional<z.ZodString>;
    runtime: z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodNumber>;
        runtime: z.ZodEnum<["docker", "node", "python", "php", "go", "ruby", "rust", "static"]>;
        version: z.ZodOptional<z.ZodString>;
        buildCommand: z.ZodOptional<z.ZodString>;
        startCommand: z.ZodOptional<z.ZodString>;
        healthCheckPath: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        schemaVersion: number;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        version?: string | undefined;
        buildCommand?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
    }, {
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        schemaVersion?: number | undefined;
        version?: string | undefined;
        buildCommand?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
    }>;
    primaryDomain: z.ZodOptional<z.ZodString>;
    sourceType: z.ZodDefault<z.ZodEnum<["git", "docker_registry", "upload", "empty"]>>;
    gitRepo: z.ZodOptional<z.ZodString>;
    gitBranch: z.ZodOptional<z.ZodString>;
    buildCommand: z.ZodOptional<z.ZodString>;
    startCommand: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    runtime: {
        schemaVersion: number;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        version?: string | undefined;
        buildCommand?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
    };
    sourceType: "git" | "docker_registry" | "upload" | "empty";
    projectId?: string | undefined;
    buildCommand?: string | undefined;
    startCommand?: string | undefined;
    gitRepo?: string | undefined;
    gitBranch?: string | undefined;
    primaryDomain?: string | undefined;
}, {
    name: string;
    runtime: {
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        schemaVersion?: number | undefined;
        version?: string | undefined;
        buildCommand?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
    };
    projectId?: string | undefined;
    buildCommand?: string | undefined;
    startCommand?: string | undefined;
    sourceType?: "git" | "docker_registry" | "upload" | "empty" | undefined;
    gitRepo?: string | undefined;
    gitBranch?: string | undefined;
    primaryDomain?: string | undefined;
}>;
export declare const updateSiteSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    runtime: z.ZodOptional<z.ZodEnum<["docker", "node", "python", "php", "go", "ruby", "rust", "static"]>>;
    runtimeVersion: z.ZodOptional<z.ZodString>;
    sourceType: z.ZodOptional<z.ZodEnum<["git", "docker_registry", "upload", "empty"]>>;
    gitRepo: z.ZodOptional<z.ZodString>;
    gitBranch: z.ZodOptional<z.ZodString>;
    buildCommand: z.ZodOptional<z.ZodString>;
    outputDirectory: z.ZodOptional<z.ZodString>;
    installCommand: z.ZodOptional<z.ZodString>;
    startCommand: z.ZodOptional<z.ZodString>;
    port: z.ZodOptional<z.ZodNumber>;
    replicas: z.ZodOptional<z.ZodNumber>;
    autoRestart: z.ZodOptional<z.ZodBoolean>;
    memoryLimit: z.ZodOptional<z.ZodNumber>;
    cpuLimit: z.ZodOptional<z.ZodNumber>;
    healthCheckPath: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
    description?: string | undefined;
    runtime?: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static" | undefined;
    runtimeVersion?: string | undefined;
    sourceType?: "git" | "docker_registry" | "upload" | "empty" | undefined;
    gitRepo?: string | undefined;
    gitBranch?: string | undefined;
    buildCommand?: string | undefined;
    outputDirectory?: string | undefined;
    installCommand?: string | undefined;
    startCommand?: string | undefined;
    port?: number | undefined;
    replicas?: number | undefined;
    autoRestart?: boolean | undefined;
    memoryLimit?: number | undefined;
    cpuLimit?: number | undefined;
    healthCheckPath?: string | undefined;
}, {
    name?: string | undefined;
    description?: string | undefined;
    runtime?: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static" | undefined;
    runtimeVersion?: string | undefined;
    sourceType?: "git" | "docker_registry" | "upload" | "empty" | undefined;
    gitRepo?: string | undefined;
    gitBranch?: string | undefined;
    buildCommand?: string | undefined;
    outputDirectory?: string | undefined;
    installCommand?: string | undefined;
    startCommand?: string | undefined;
    port?: number | undefined;
    replicas?: number | undefined;
    autoRestart?: boolean | undefined;
    memoryLimit?: number | undefined;
    cpuLimit?: number | undefined;
    healthCheckPath?: string | undefined;
}>;
export declare const attachDomainToSiteSchema: z.ZodObject<{
    domainId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domainId: string;
}, {
    domainId: string;
}>;
export declare const detachDomainFromSiteSchema: z.ZodObject<{
    domainId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domainId: string;
}, {
    domainId: string;
}>;
export type CreateSiteInput = z.infer<typeof createSiteSchema>;
export type UpdateSiteInput = z.infer<typeof updateSiteSchema>;
export type RuntimeConfig = z.infer<typeof runtimeConfigSchema>;
//# sourceMappingURL=sites.schema.d.ts.map