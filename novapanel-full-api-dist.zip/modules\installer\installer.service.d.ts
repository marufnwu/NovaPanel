export declare class InstallerService {
    getAvailableApps(): Promise<never[]>;
    getApp(_appId: string): Promise<null>;
    installApp(_appId: string, _siteId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    uninstallApp(_installId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    getInstallLogs(_installId: string): Promise<never[]>;
    updateAppConfig(_installId: string, _config: Record<string, any>, _userId?: string, _ipAddress?: string): Promise<void>;
}
export declare const installerService: InstallerService;
//# sourceMappingURL=installer.service.d.ts.map