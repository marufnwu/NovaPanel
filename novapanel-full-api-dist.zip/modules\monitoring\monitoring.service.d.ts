import { type Metric, type AlertRule, type NewAlertRule, type AlertHistory } from '../../db/schema/monitoring.js';
export declare class MonitoringService {
    recordMetric(name: string, value: number, labels?: Record<string, string>): Promise<void>;
    getMetrics(filters?: {
        name?: string;
        from?: Date;
        to?: Date;
        limit?: number;
    }): Promise<Metric[]>;
    collectSystemMetrics(): Promise<void>;
    listAlertRules(orgId: string): Promise<AlertRule[]>;
    createAlertRule(data: Omit<NewAlertRule, 'id' | 'createdAt'>): Promise<AlertRule>;
    updateAlertRule(id: string, data: Partial<Pick<AlertRule, 'name' | 'description' | 'metric' | 'condition' | 'threshold' | 'duration' | 'channels' | 'enabled'>>): Promise<AlertRule>;
    deleteAlertRule(id: string): Promise<void>;
    evaluateAlertRules(): Promise<void>;
    private checkCondition;
    private triggerAlert;
    getAlertHistory(ruleId: string, limit?: number): Promise<AlertHistory[]>;
    listAlertHistory(orgId: string, limit?: number): Promise<(AlertHistory & {
        ruleName: string;
    })[]>;
}
export declare const monitoringService: MonitoringService;
//# sourceMappingURL=monitoring.service.d.ts.map