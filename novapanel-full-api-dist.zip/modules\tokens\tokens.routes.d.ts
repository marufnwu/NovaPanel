import type { FastifyInstance } from 'fastify';
export default function tokensRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=tokens.routes.d.ts.map