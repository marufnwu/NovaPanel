/**
 * Write a file atomically using write-to-temp-then-rename pattern.
 * This ensures the target file is either the old version or the new version,
 * never a partial/corrupt file if the write is interrupted.
 *
 * 1. Writes content to a temp file (/tmp/novapanel-{random}.tmp)
 * 2. Uses mv (rename) to atomically replace the target file
 */
export declare function atomicWrite(path: string, content: string): Promise<void>;
/**
 * Write a file using sudo (via tee).
 * Content is piped through stdin to avoid shell injection.
 */
export declare function writeFile(path: string, content: string): Promise<void>;
/**
 * Append to a file using sudo (via tee -a).
 */
export declare function appendFile(path: string, content: string): Promise<void>;
/**
 * Read a file using sudo (via cat).
 * Returns the file content as a string.
 * Throws if the file cannot be read.
 */
export declare function readFile(path: string): Promise<string>;
/**
 * Create a directory (with -p) using sudo.
 */
export declare function mkdir(path: string): Promise<void>;
/**
 * Remove a file using sudo.
 */
export declare function unlink(path: string): Promise<void>;
/**
 * Create a symbolic link using sudo (ln -sf).
 */
export declare function symlink(target: string, linkPath: string): Promise<void>;
/**
 * Change file permissions using sudo chmod.
 */
export declare function chmod(path: string, mode: string): Promise<void>;
/**
 * Rename / move a file or directory using sudo mv.
 */
export declare function rename(oldPath: string, newPath: string): Promise<void>;
/**
 * Remove a file or directory using sudo rm.
 * Supports recursive removal for directories.
 */
export declare function remove(path: string, options?: {
    recursive?: boolean;
    force?: boolean;
}): Promise<void>;
/**
 * Copy a file or directory using sudo cp.
 * Supports recursive copying for directories.
 */
export declare function copy(source: string, destination: string, options?: {
    recursive?: boolean;
}): Promise<void>;
//# sourceMappingURL=sudo-fs.d.ts.map