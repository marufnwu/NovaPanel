export {};
//# sourceMappingURL=domains.service.test.d.ts.map