import type { FastifyInstance } from 'fastify';
export default function logsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=logs.routes.d.ts.map