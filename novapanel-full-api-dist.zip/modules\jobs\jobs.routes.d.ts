import type { FastifyInstance } from 'fastify';
export default function jobsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=jobs.routes.d.ts.map