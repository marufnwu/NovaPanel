import { type Plugin, type NewPlugin } from '../../db/schema/plugins.js';
export declare class PluginsService {
    list(): Promise<Plugin[]>;
    get(id: string): Promise<Plugin | null>;
    create(data: Omit<NewPlugin, 'id' | 'createdAt'>): Promise<Plugin>;
    update(id: string, data: Partial<Pick<Plugin, 'name' | 'version' | 'description' | 'author' | 'manifest' | 'enabled' | 'config'>>): Promise<Plugin>;
    delete(id: string): Promise<void>;
    toggle(id: string): Promise<Plugin>;
    updateConfig(id: string, config: Record<string, unknown>): Promise<Plugin>;
}
export declare const pluginsService: PluginsService;
//# sourceMappingURL=plugins.service.d.ts.map