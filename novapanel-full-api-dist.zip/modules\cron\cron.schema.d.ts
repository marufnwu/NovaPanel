import { z } from 'zod';
export declare const createCronJobSchema: z.ZodObject<{
    command: z.ZodString;
    schedule: z.ZodString;
    siteId: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    command: string;
    schedule: string;
    name?: string | undefined;
    siteId?: string | undefined;
}, {
    command: string;
    schedule: string;
    name?: string | undefined;
    siteId?: string | undefined;
}>;
//# sourceMappingURL=cron.schema.d.ts.map