import type { FastifyInstance } from 'fastify';
export default function organizationRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=organizations.routes.d.ts.map