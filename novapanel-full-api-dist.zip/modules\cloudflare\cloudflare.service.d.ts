export declare class CloudflareService {
    private getClient;
    listZones(_apiToken: string, page?: number, perPage?: number): Promise<{
        zones: import("../../services/cloudflare-client.js").CloudflareZone[];
        total: number;
    }>;
    linkZone(data: {
        zoneId?: string;
        zoneName?: string;
        apiToken: string;
        accountId?: string;
        domainId?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareZone>;
    unlinkZone(zoneDbId: string, userId?: string, ipAddress?: string): Promise<void>;
    getZoneOverview(_zoneDbId: string): Promise<{
        status: string;
        name_servers: string[];
    }>;
    listLinkedZones(): Promise<{
        type: string;
        id: string;
        name: string;
        createdAt: Date;
        orgId: string;
        zoneId: string;
        proxied: boolean;
        recordId: string | null;
        content: string;
        autoSync: boolean;
    }[]>;
    listDnsRecords(_zoneDbId: string, _params?: {
        type?: string;
        name?: string;
        page?: number;
        perPage?: number;
    }): Promise<never[]>;
    createDnsRecord(zoneDbId: string, data: {
        type: string;
        name: string;
        content: string;
        proxied?: boolean;
        ttl?: number;
        priority?: number;
        comment?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareDnsRecord>;
    updateDnsRecord(zoneDbId: string, recordId: string, data: {
        type?: string;
        name?: string;
        content?: string;
        proxied?: boolean;
        ttl?: number;
        priority?: number;
        comment?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareDnsRecord>;
    deleteDnsRecord(zoneDbId: string, recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    getSslSettings(zoneId: string): Promise<import("../../services/cloudflare-client.js").CloudflareSslSettings>;
    updateSslSettings(zoneId: string, settings: {
        sslMode?: 'off' | 'flexible' | 'full' | 'strict';
        alwaysUseHttps?: boolean;
        automaticHttpsRewrites?: boolean;
        minTlsVersion?: '1.0' | '1.1' | '1.2' | '1.3';
        http2?: boolean;
        http3?: boolean;
        browserCacheTtl?: number;
        developmentMode?: boolean;
        emailObfuscation?: boolean;
        hotlinkProtection?: boolean;
    }, userId?: string, ipAddress?: string): Promise<Record<string, unknown>>;
    createOriginCertificate(_zoneDbId: string, _hostnames: string[], _validityDays?: number, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareOriginCertificate>;
    purgeCache(zoneId: string, data: {
        purgeEverything?: boolean;
        files?: string[];
        tags?: string[];
    }, userId?: string, ipAddress?: string): Promise<void>;
    listFirewallRules(zoneId: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule[]>;
    createFirewallRule(zoneId: string, data: {
        action: string;
        expression: string;
        description?: string;
        paused?: boolean;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule>;
    deleteFirewallRule(zoneId: string, ruleId: string, userId?: string, ipAddress?: string): Promise<void>;
    listAccessRules(_zoneId: string): Promise<never[]>;
    createAccessRule(_zoneId: string, _data: {
        mode: string;
        target: string;
        value: string;
        notes?: string;
    }, _userId?: string, _ipAddress?: string): Promise<{
        id: string;
        mode: string;
        configuration: {
            target: string;
            value: string;
        };
        notes: string;
    }>;
    deleteAccessRule(_zoneId: string, _ruleId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    listRedirectRules(_zoneDbId: string): Promise<never[]>;
    createRedirectRule(_zoneDbId: string, _data: {
        sourcePattern: string;
        destinationUrl: string;
        redirectType: string;
    }, _userId?: string, _ipAddress?: string): Promise<{
        id: string;
        action: string;
        status: string;
        expression: string;
        description: string;
    }>;
    deleteRedirectRule(_zoneDbId: string, _ruleDbId: string, _userId?: string, _ipAddress?: string): Promise<void>;
    applyMailPreset(zoneId: string, provider: string, _customRecords?: Array<{
        type: string;
        name: string;
        content: string;
        priority?: number;
    }>, userId?: string, ipAddress?: string): Promise<{
        applied: number;
    }>;
    verifyDns(zoneId: string): Promise<{
        nameservers: string[];
        status: string;
    }>;
    togglePause(zoneId: string, pause: boolean, userId?: string, ipAddress?: string): Promise<void>;
    getZoneSettings(zoneId: string): Promise<import("../../services/cloudflare-client.js").CloudflareZoneSetting<string | number | boolean>[]>;
    enableWildcard(_zoneDbId: string, _domainId: string, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
    }>;
    disableWildcard(_zoneDbId: string, userId?: string, ipAddress?: string): Promise<void>;
    getWildcardStatus(_zoneDbId: string): Promise<{
        enabled: boolean;
    }>;
    verifyDomainSetup(_zoneDbId: string): Promise<{
        verified: boolean;
        checks: never[];
    }>;
    getDomainCloudflareStatus(domainId: string): Promise<{
        integrated: boolean;
        zoneId: string | null;
        proxyEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
    }>;
    getAllDomainCloudflareStatus(): Promise<{
        domainId: string;
        domain: string;
        integrated: boolean;
        proxyEnabled: boolean;
        sslStatus: "error" | "active" | "pending" | "expired";
    }[]>;
}
export declare const cloudflareService: CloudflareService;
//# sourceMappingURL=cloudflare.service.d.ts.map