import type { SystemService, ServiceInfo } from './types.js';
export declare class MariaDbService implements SystemService {
    readonly name = "mariadb";
    readonly displayName = "MariaDB";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    /**
     * Create a database
     */
    createDatabase(name: string): Promise<void>;
    /**
     * Drop a database
     */
    dropDatabase(name: string): Promise<void>;
    /**
     * Create a database user
     */
    createUser(username: string, password: string, host?: string): Promise<void>;
    /**
     * Grant privileges to a user on a database
     */
    grantPrivileges(username: string, database: string, host?: string): Promise<void>;
    /**
     * Drop a user
     */
    dropUser(username: string, host?: string): Promise<void>;
    /**
     * Dump a database to SQL
     */
    dumpDatabase(name: string, outputPath: string): Promise<void>;
    /**
     * Change a user's password
     */
    changePassword(username: string, password: string, host?: string): Promise<void>;
    /**
     * Export a database to SQL string
     */
    exportDatabase(name: string): Promise<string>;
    /**
     * Import SQL into a database
     */
    importDatabase(name: string, sql: string): Promise<void>;
    /**
     * Get database size in bytes
     */
    getDatabaseSize(name: string): Promise<number>;
    /**
     * Repair database tables
     */
    repairDatabase(name: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Optimize database tables
     */
    optimizeDatabase(name: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Clone database to a new name
     */
    cloneDatabase(sourceName: string, targetName: string): Promise<void>;
    /**
     * Run a read-only SQL query.
     * Omits -N so the first row of output contains column headers.
     */
    runQuery(name: string, sql: string): Promise<{
        columns: string[];
        rows: Record<string, unknown>[];
        rowCount: number;
    }>;
}
export declare const mariadbService: MariaDbService;
//# sourceMappingURL=mariadb.service.d.ts.map