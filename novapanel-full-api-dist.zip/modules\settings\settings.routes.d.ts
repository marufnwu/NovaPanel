import type { FastifyInstance } from 'fastify';
export default function settingsRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=settings.routes.d.ts.map