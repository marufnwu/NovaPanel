import type { SystemService, ServiceInfo } from './types.js';
export interface VhostContext {
    domain: string;
    documentRoot: string;
    phpVersion?: string;
    ssl?: {
        certPath: string;
        keyPath: string;
    };
    aliases?: string[];
    redirectHttpToHttps?: boolean;
    hsts?: boolean;
    upstreamPort?: number;
}
export declare class NginxService implements SystemService {
    readonly name = "nginx";
    readonly displayName = "Nginx";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    /**
     * Test Nginx configuration syntax without applying
     */
    testConfig(): Promise<{
        valid: boolean;
        output: string;
    }>;
    /**
     * Generate a single nginx config file for a website containing one server
     * block per attached domain. The config is written to
     * `/etc/nginx/sites-available/website-{websiteId}.conf` and symlinked into
     * sites-enabled. After writing, nginx -t is run and nginx is reloaded.
     */
    generateWebsiteConfig(websiteId: string): Promise<void>;
    /**
     * Generate a "suspended" nginx config for a website — all domains return 503.
     * The original config is backed up with a `.active` suffix before overwriting.
     */
    generateSuspendedConfig(websiteId: string): Promise<void>;
    /**
     * Remove the nginx config file for a website and reload nginx.
     */
    removeWebsiteConfig(websiteId: string): Promise<void>;
    /**
     * Test nginx config and reload if valid.
     * Throws if nginx -t fails.
     */
    reloadNginx(): Promise<void>;
    /**
     * @deprecated Use generateWebsiteConfig() instead.
     * Add a virtual host configuration (per-domain).
     */
    addVhost(context: VhostContext): Promise<void>;
    /**
     * @deprecated Use removeWebsiteConfig() instead.
     * Remove a virtual host configuration (per-domain).
     */
    removeVhost(domain: string): Promise<void>;
    /**
     * Render Nginx vhost config from template
     */
    private renderVhost;
    private renderPhpLocation;
}
export declare const nginxService: NginxService;
//# sourceMappingURL=nginx.service.d.ts.map