import { z } from 'zod';
export declare const createDomainSchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["primary", "subdomain", "alias", "redirect"]>>;
    parentDomainId: z.ZodOptional<z.ZodString>;
    redirectTarget: z.ZodOptional<z.ZodString>;
    websiteMode: z.ZodDefault<z.ZodEnum<["none", "create", "existing"]>>;
    websiteId: z.ZodOptional<z.ZodString>;
    websiteName: z.ZodOptional<z.ZodString>;
    documentRoot: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
    phpHandler: z.ZodDefault<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodDefault<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
    createDnsZone: z.ZodDefault<z.ZodBoolean>;
    enableMail: z.ZodDefault<z.ZodBoolean>;
    makePublic: z.ZodDefault<z.ZodBoolean>;
    tunnelId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    type: "primary" | "subdomain" | "alias" | "redirect";
    name: string;
    phpHandler: "php-fpm" | "cgi" | "disabled";
    webServer: "nginx" | "apache" | "nginx+apache";
    websiteMode: "create" | "none" | "existing";
    createDnsZone: boolean;
    enableMail: boolean;
    makePublic: boolean;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
    websiteId?: string | undefined;
    redirectTarget?: string | undefined;
    parentDomainId?: string | undefined;
    tunnelId?: string | undefined;
    websiteName?: string | undefined;
}, {
    name: string;
    type?: "primary" | "subdomain" | "alias" | "redirect" | undefined;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    websiteId?: string | undefined;
    redirectTarget?: string | undefined;
    parentDomainId?: string | undefined;
    tunnelId?: string | undefined;
    websiteMode?: "create" | "none" | "existing" | undefined;
    createDnsZone?: boolean | undefined;
    enableMail?: boolean | undefined;
    makePublic?: boolean | undefined;
    websiteName?: string | undefined;
}>;
export declare const updateDomainSchema: z.ZodObject<{
    phpVersion: z.ZodOptional<z.ZodString>;
    phpHandler: z.ZodOptional<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodOptional<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
    redirectHttpToHttps: z.ZodOptional<z.ZodBoolean>;
    hsts: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
}, {
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
}>;
export declare const deleteDomainSchema: z.ZodObject<{
    deleteWebsite: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    deleteWebsite: boolean;
}, {
    deleteWebsite?: boolean | undefined;
}>;
export declare const createSubdomainSchema: z.ZodObject<{
    name: z.ZodString;
    documentRoot: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
}, {
    name: string;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
}>;
export declare const createAliasSchema: z.ZodObject<{
    alias: z.ZodString;
}, "strip", z.ZodTypeAny, {
    alias: string;
}, {
    alias: string;
}>;
export declare const createRedirectSchema: z.ZodObject<{
    sourcePath: z.ZodString;
    targetUrl: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["301", "302"]>>;
}, "strip", z.ZodTypeAny, {
    type: "301" | "302";
    sourcePath: string;
    targetUrl: string;
}, {
    sourcePath: string;
    targetUrl: string;
    type?: "301" | "302" | undefined;
}>;
export type CreateDomainInput = z.infer<typeof createDomainSchema>;
export type UpdateDomainInput = z.infer<typeof updateDomainSchema>;
export type DeleteDomainInput = z.infer<typeof deleteDomainSchema>;
//# sourceMappingURL=domains.schema.d.ts.map