export declare class DatabasesService {
    /**
     * List all databases (optionally filtered by domainId)
     */
    list(domainId?: string, page?: number, perPage?: number): Promise<{
        items: {
            id: string;
            name: string;
            createdAt: Date;
            websiteId: string | null;
            domainId: string | null;
            engine: "mariadb" | "postgresql";
            charset: string | null;
            collation: string | null;
        }[];
        meta: {
            page: number;
            perPage: number;
            total: number;
        };
    }>;
    /**
     * Get a single database by ID
     */
    getDatabase(databaseId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        websiteId: string | null;
        domainId: string | null;
        engine: "mariadb" | "postgresql";
        charset: string | null;
        collation: string | null;
    }>;
    /**
     * Create a database, optionally creating a user with access
     */
    create(data: {
        domainId?: string;
        name: string;
        engine: 'mariadb' | 'postgresql';
        charset?: string;
        createUser?: boolean;
        username?: string;
        password?: string;
        host?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        engine: "mariadb" | "postgresql";
        user: {
            id: string;
            username: string;
            host: string;
        } | null;
    }>;
    /**
     * Delete a database
     */
    delete(databaseId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Create a database user
     */
    createUser(databaseId: string, username: string, password: string, host?: string, auditUserId?: string, ipAddress?: string): Promise<{
        id: string;
        username: string;
        host: string;
    }>;
    /**
     * Delete a database user
     */
    deleteUser(dbUserId: string, auditUserId?: string, ipAddress?: string): Promise<void>;
    /**
     * Change database user password
     */
    changeUserPassword(dbUserId: string, newPassword: string, auditUserId?: string, ipAddress?: string): Promise<void>;
    /**
     * Export database
     */
    exportDatabase(databaseId: string, userId?: string, ipAddress?: string): Promise<string>;
    /**
     * Import database
     */
    importDatabase(databaseId: string, sql: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get full database info including users and size
     */
    getDatabaseInfo(databaseId: string): Promise<{
        sizeBytes: number;
        sizeMb: number;
        users: {
            id: string;
            username: string;
            host: string | null;
        }[];
        id: string;
        name: string;
        createdAt: Date;
        websiteId: string | null;
        domainId: string | null;
        engine: "mariadb" | "postgresql";
        charset: string | null;
        collation: string | null;
    }>;
    /**
     * Repair MariaDB database tables
     */
    repairDatabase(databaseId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Optimize MariaDB database tables
     */
    optimizeDatabase(databaseId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Clone database to a new database
     */
    cloneDatabase(databaseId: string, newName: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        engine: "mariadb" | "postgresql";
    }>;
    /**
     * Run an arbitrary SQL query (SELECT only for safety)
     */
    runQuery(databaseId: string, sql: string): Promise<{
        columns: string[];
        rows: Record<string, unknown>[];
        rowCount: number;
    }>;
    /**
     * List databases by websiteId
     */
    listByWebsite(websiteId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        websiteId: string | null;
        domainId: string | null;
        engine: "mariadb" | "postgresql";
        charset: string | null;
        collation: string | null;
    }[]>;
}
//# sourceMappingURL=databases.service.d.ts.map