export declare class WebServerService {
    /**
     * Apply the full web server configuration for a website:
     * 1. Generate nginx config (one server block per attached domain)
     * 2. Generate PHP-FPM pool for the website
     * 3. Both are tested before reload — if nginx -t fails nothing is reloaded
     */
    applyWebsiteConfig(websiteId: string): Promise<void>;
    /**
     * Remove the full web server configuration for a website:
     * 1. Remove nginx config file
     * 2. Remove PHP-FPM pool file
     * 3. Reload both services
     */
    removeWebsiteConfig(websiteId: string): Promise<void>;
    /**
     * Get current web server config for a domain (by ID)
     */
    getConfig(domainId: string): Promise<{
        domainId: string;
        domain: string;
        webServer: "nginx" | "apache" | "nginx+apache";
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        ssl: boolean;
        documentRoot: string;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        gzipEnabled: boolean;
        browserCachingEnabled: boolean;
        staticFileExpiryDays: number;
        hotlinkProtection: boolean;
        hotlinkAllowedDomains: string;
        directoryBrowsing: boolean;
        ipRestrictionMode: "allow_all";
        ipList: string;
        reverseProxyEnabled: boolean;
        reverseProxyTarget: string;
        maxUploadSizeMb: number;
        customNginxDirectives: string;
        customApacheDirectives: string;
    }>;
    /**
     * Get current web server config for a domain (by name)
     */
    getConfigByName(domainName: string): Promise<{
        domainId: string;
        domain: string;
        webServer: "nginx" | "apache" | "nginx+apache";
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        ssl: boolean;
        documentRoot: string;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        gzipEnabled: boolean;
        browserCachingEnabled: boolean;
        staticFileExpiryDays: number;
        hotlinkProtection: boolean;
        hotlinkAllowedDomains: string;
        directoryBrowsing: boolean;
        ipRestrictionMode: "allow_all";
        ipList: string;
        reverseProxyEnabled: boolean;
        reverseProxyTarget: string;
        maxUploadSizeMb: number;
        customNginxDirectives: string;
        customApacheDirectives: string;
    }>;
    /**
     * Update web server configuration for a domain (by ID)
     */
    updateConfig(domainId: string, userId: string | undefined, data: {
        webServer?: string;
        gzipEnabled?: boolean;
        browserCachingEnabled?: boolean;
        staticFileExpiryDays?: number;
        hotlinkProtection?: boolean;
        hotlinkAllowedDomains?: string;
        directoryBrowsing?: boolean;
        ipRestrictionMode?: string;
        ipList?: string;
        reverseProxyEnabled?: boolean;
        reverseProxyTarget?: string;
        maxUploadSizeMb?: number;
        customNginxDirectives?: string;
        customApacheDirectives?: string;
    }): Promise<{
        domainId: string;
        domain: string;
        webServer: "nginx" | "apache" | "nginx+apache";
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        ssl: boolean;
        documentRoot: string;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        gzipEnabled: boolean;
        browserCachingEnabled: boolean;
        staticFileExpiryDays: number;
        hotlinkProtection: boolean;
        hotlinkAllowedDomains: string;
        directoryBrowsing: boolean;
        ipRestrictionMode: "allow_all";
        ipList: string;
        reverseProxyEnabled: boolean;
        reverseProxyTarget: string;
        maxUploadSizeMb: number;
        customNginxDirectives: string;
        customApacheDirectives: string;
    }>;
    /**
     * Update web server configuration for a domain (by name)
     */
    updateConfigByName(domainName: string, userId: string | undefined, data: any): Promise<{
        domainId: string;
        domain: string;
        webServer: "nginx" | "apache" | "nginx+apache";
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        ssl: boolean;
        documentRoot: string;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        gzipEnabled: boolean;
        browserCachingEnabled: boolean;
        staticFileExpiryDays: number;
        hotlinkProtection: boolean;
        hotlinkAllowedDomains: string;
        directoryBrowsing: boolean;
        ipRestrictionMode: "allow_all";
        ipList: string;
        reverseProxyEnabled: boolean;
        reverseProxyTarget: string;
        maxUploadSizeMb: number;
        customNginxDirectives: string;
        customApacheDirectives: string;
    }>;
    /**
     * Get the rendered Nginx config for preview
     */
    previewConfig(domainId: string): Promise<{
        domain: string;
        server: string;
        config: string;
    }>;
    /**
     * Test config validity
     */
    testConfig(_domainId: string): Promise<{
        nginx: {
            valid: boolean;
            output: string;
        };
    }>;
    /**
     * Get list of all domains for the domain selector
     */
    listDomains(): Promise<{
        id: string;
        name: string;
        webServer: "nginx" | "apache" | "nginx+apache";
        status: "active" | "suspended" | "pending";
    }[]>;
    /**
     * Get custom error pages for a domain
     */
    getErrorPages(domainName: string): Promise<{
        code: number;
        enabled: boolean;
        content: string;
        contentType: "text/html";
    }[]>;
    /**
     * Update custom error pages for a domain
     */
    updateErrorPages(domainName: string, errorPages: Array<{
        code: number;
        enabled: boolean;
        content: string;
        contentType: string;
    }>, userId?: string): Promise<{
        success: boolean;
        errorPages: {
            code: number;
            enabled: boolean;
            content: string;
            contentType: string;
        }[];
    }>;
    /**
     * Get rate limiting configuration for a domain
     */
    getRateLimitConfig(domainName: string): Promise<{
        enabled: boolean;
        requestsPerSecond: number;
        burstSize: number;
        timeoutSeconds: number;
    }>;
    /**
     * Update rate limiting configuration for a domain
     */
    updateRateLimitConfig(domainName: string, data: {
        enabled?: boolean;
        requestsPerSecond?: number;
        burstSize?: number;
        timeoutSeconds?: number;
    }, userId?: string): Promise<{
        enabled: boolean;
        requestsPerSecond: number;
        burstSize: number;
        timeoutSeconds: number;
    }>;
}
//# sourceMappingURL=webserver.service.d.ts.map