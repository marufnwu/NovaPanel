declare const DANGEROUS_FUNCTIONS: string[];
export declare class PhpService {
    /**
     * List installed PHP versions with FPM status for each.
     * Scans /etc/php/ for version directories, then checks FPM service status.
     */
    listVersions(): Promise<{
        versions: {
            version: string;
            fpm: {
                active: boolean;
                port: number | null;
            };
        }[];
    }>;
    /**
     * Get PHP config for a domain (full settings)
     */
    getConfig(domainId: string): Promise<{
        domainId: string;
        domain: string;
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        customIni: string;
        poolConfig: string;
        poolSettings: {
            pm: string;
            maxChildren: number;
            startServers: number;
            minSpareServers: number;
            maxSpareServers: number;
            requestTerminateTimeout: number;
        };
        limits: {
            memoryLimit: string;
            maxExecutionTime: number;
            maxInputTime: number;
            uploadMaxFilesize: string;
            postMaxSize: string;
            maxFileUploads: number;
        };
        security: {
            openBasedir: boolean;
            disabledFunctions: string[];
        };
    }>;
    /**
     * Get PHP config by domain name
     */
    getConfigByName(domainName: string): Promise<{
        domainId: string;
        domain: string;
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        customIni: string;
        poolConfig: string;
        poolSettings: {
            pm: string;
            maxChildren: number;
            startServers: number;
            minSpareServers: number;
            maxSpareServers: number;
            requestTerminateTimeout: number;
        };
        limits: {
            memoryLimit: string;
            maxExecutionTime: number;
            maxInputTime: number;
            uploadMaxFilesize: string;
            postMaxSize: string;
            maxFileUploads: number;
        };
        security: {
            openBasedir: boolean;
            disabledFunctions: string[];
        };
    }>;
    /**
     * Set PHP version for a domain
     */
    setVersion(domainId: string, phpVersion: string, userId?: string): Promise<{
        phpVersion: string;
    }>;
    /**
     * Update PHP-FPM pool settings for a domain
     */
    updatePoolSettings(domainId: string, settings: {
        pm?: string;
        maxChildren?: number;
        startServers?: number;
        minSpareServers?: number;
        maxSpareServers?: number;
        requestTerminateTimeout?: number;
    }, userId?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Update PHP limits for a domain
     */
    updateLimits(domainId: string, limits: {
        memoryLimit?: string;
        maxExecutionTime?: number;
        maxInputTime?: number;
        uploadMaxFilesize?: string;
        postMaxSize?: string;
        maxFileUploads?: number;
    }, userId?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Update security settings (open_basedir, disabled functions)
     */
    updateSecurity(domainId: string, security: {
        openBasedir?: boolean;
        disabledFunctions?: string[];
    }, userId?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get per-domain php.ini overrides
     */
    getIni(domainId: string): Promise<{
        content: string;
    }>;
    /**
     * Update per-domain php.ini overrides
     */
    updateIni(domainId: string, content: string): Promise<{
        success: boolean;
    }>;
    /**
     * Restart PHP-FPM for a domain
     */
    restartFpm(domainId: string, userId?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get list of all domains for the selector
     */
    listDomains(): Promise<{
        id: string;
        name: string;
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
    }[]>;
    /**
     * Get PHP-FPM pool status for a domain
     */
    getFpmStatus(domainId: string): Promise<{
        pool: string;
        processManager: string;
        startTime: string;
        startSince: number;
        acceptedConn: number;
        listenQueue: number;
        maxListenQueue: number;
        listenQueueLen: number;
        idleProcesses: number;
        activeProcesses: number;
        totalProcesses: number;
        maxActiveProcesses: number;
        maxChildrenReached: number;
        slowRequests: number;
    }>;
    private parseFpmStatus;
    /**
     * Get PHP info for a domain
     */
    getPhpInfo(domainId: string): Promise<{
        html: string;
    }>;
    /**
     * Install a PHP version
     */
    installPhp(version: string, userId?: string): Promise<{
        success: boolean;
        version: string;
    }>;
    /**
     * Render PHP-FPM pool config
     */
    private renderPoolConfig;
}
export { DANGEROUS_FUNCTIONS };
//# sourceMappingURL=php.service.d.ts.map