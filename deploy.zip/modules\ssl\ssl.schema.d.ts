import { z } from 'zod';
/** SSL certificate type enum — must match DB enum values */
export declare const sslTypeEnum: z.ZodEnum<["letsencrypt", "custom", "self-signed"]>;
export declare const issueLetsEncryptSchema: z.ZodObject<{
    email: z.ZodString;
    enableWww: z.ZodDefault<z.ZodBoolean>;
    /** Subject Alternative Names — additional domains to include on the certificate */
    sanDomains: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    /** Whether to issue a wildcard certificate (*.domain) via DNS-01 challenge */
    wildcard: z.ZodDefault<z.ZodBoolean>;
    /** Challenge type: 'http-01' (port 80 required) or 'dns-01' (Cloudflare DNS) */
    challengeType: z.ZodDefault<z.ZodEnum<["http-01", "dns-01"]>>;
}, "strip", z.ZodTypeAny, {
    email: string;
    wildcard: boolean;
    challengeType: "http-01" | "dns-01";
    enableWww: boolean;
    sanDomains?: string[] | undefined;
}, {
    email: string;
    sanDomains?: string[] | undefined;
    wildcard?: boolean | undefined;
    challengeType?: "http-01" | "dns-01" | undefined;
    enableWww?: boolean | undefined;
}>;
export declare const uploadCustomSchema: z.ZodObject<{
    certificate: z.ZodString;
    privateKey: z.ZodString;
    chain: z.ZodOptional<z.ZodString>;
    /** Subject Alternative Names associated with this custom certificate */
    sanDomains: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    certificate: string;
    privateKey: string;
    chain?: string | undefined;
    sanDomains?: string[] | undefined;
}, {
    certificate: string;
    privateKey: string;
    chain?: string | undefined;
    sanDomains?: string[] | undefined;
}>;
export declare const generateSelfSignedSchema: z.ZodObject<{
    days: z.ZodDefault<z.ZodNumber>;
    /** Subject Alternative Names — additional domains/IPs to include */
    sanDomains: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    /** Whether to include a wildcard SAN (*.domain) */
    wildcard: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    wildcard: boolean;
    days: number;
    sanDomains?: string[] | undefined;
}, {
    sanDomains?: string[] | undefined;
    wildcard?: boolean | undefined;
    days?: number | undefined;
}>;
export declare const updateSslSettingsSchema: z.ZodObject<{
    autoRenew: z.ZodOptional<z.ZodBoolean>;
    redirectHttpToHttps: z.ZodOptional<z.ZodBoolean>;
    hsts: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
    autoRenew?: boolean | undefined;
}, {
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
    autoRenew?: boolean | undefined;
}>;
export declare const toggleAutoRenewSchema: z.ZodObject<{
    autoRenew: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    autoRenew: boolean;
}, {
    autoRenew: boolean;
}>;
export declare const updateHstsSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
    maxAge: z.ZodNumber;
    includeSubdomains: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    maxAge: number;
    enabled: boolean;
    includeSubdomains: boolean;
}, {
    maxAge: number;
    enabled: boolean;
    includeSubdomains: boolean;
}>;
export declare const updateOcspStaplingSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    enabled: boolean;
}, {
    enabled: boolean;
}>;
//# sourceMappingURL=ssl.schema.d.ts.map