export declare class DnsService {
    /**
     * Get DNS zone and all records for a domain
     */
    getZone(domainId: string): Promise<{
        zone: {
            id: string;
            isActive: boolean | null;
            createdAt: Date;
            domainId: string;
            serial: number;
            ttl: number | null;
            primaryNs: string;
            adminEmail: string;
            refresh: number | null;
            retry: number | null;
            expire: number | null;
            minimumTtl: number | null;
        };
        records: {
            value: string;
            type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "NS" | "SRV" | "CAA" | "PTR";
            id: string;
            name: string;
            createdAt: Date;
            ttl: number | null;
            zoneId: string;
            priority: number | null;
            isSystem: boolean | null;
        }[];
    }>;
    /**
     * Ensure a DNS zone exists for a domain, creating one with defaults if missing
     */
    ensureZone(domainId: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        domainId: string;
        serial: number;
        ttl: number | null;
        primaryNs: string;
        adminEmail: string;
        refresh: number | null;
        retry: number | null;
        expire: number | null;
        minimumTtl: number | null;
    }>;
    /**
     * Create a DNS record
     */
    createRecord(domainId: string, data: {
        type: string;
        name: string;
        value: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        type: string;
        name: string;
        value: string;
        ttl?: number;
        priority?: number;
        id: string;
    }>;
    /**
     * Update a DNS record
     */
    updateRecord(recordId: string, data: {
        name?: string;
        value?: string;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        name?: string;
        value?: string;
        ttl?: number;
        priority?: number;
        id: string;
    }>;
    /**
     * Delete a DNS record
     */
    deleteRecord(recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Import DNS zone from BIND format text
     */
    importZone(domainId: string, bindFormat: string, userId?: string, ipAddress?: string): Promise<{
        imported: number;
    }>;
    /**
     * Export DNS zone as BIND format text
     */
    exportZone(domainId: string): Promise<string>;
    /**
     * Reset DNS to default records (A, www, mail, MX, SPF)
     */
    resetToDefaults(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get the raw zone file content
     */
    getRawZone(domainId: string): Promise<string>;
    /**
     * Check DNS propagation against public resolvers
     */
    checkPropagation(domainId: string): Promise<any[]>;
    /**
     * Update SOA record for a domain's DNS zone
     */
    updateSoa(domainId: string, data: {
        primaryNs?: string;
        adminEmail?: string;
        refresh?: number;
        retry?: number;
        expire?: number;
        minimumTtl?: number;
    }): Promise<{
        success: boolean;
    }>;
    /**
     * Get Cloudflare DNS configuration for a domain
     */
    getCloudflareConfig(domainId: string): Promise<{
        enabled: boolean;
        apiToken: string;
        zoneId: string;
        zoneName: string;
        lastSyncAt: null;
    }>;
    /**
     * Update Cloudflare DNS configuration for a domain
     */
    updateCloudflareConfig(domainId: string, data: {
        enabled?: boolean;
        apiToken?: string;
        zoneId?: string;
        zoneName?: string;
    }): Promise<{
        enabled: boolean;
        apiToken: string;
        zoneId: string;
        zoneName: string;
        lastSyncAt: null;
    }>;
    /**
     * Sync DNS records with Cloudflare
     */
    syncCloudflareRecords(domainId: string): Promise<{
        synced: boolean;
        recordsProcessed: number;
        message: string;
    }>;
    /**
     * Delete a DNS zone and all its records for a domain
     */
    deleteZone(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Regenerate the BIND zone file from DB records and reload BIND.
     * Can be called from other services (e.g. mail) after inserting DNS records.
     */
    syncZoneToDisk(zoneId: string): Promise<void>;
    private rewriteZoneFile;
    private parseBindFormat;
}
//# sourceMappingURL=dns.service.d.ts.map