export declare class BackupService {
    /**
     * List all backups
     */
    listBackups(): Promise<{
        error: string | null;
        type: "full" | "files" | "database" | "dns" | "mail" | "config";
        status: "pending" | "failed" | "running" | "completed" | "restoring";
        id: string;
        createdAt: Date;
        websiteId: string | null;
        filename: string;
        sizeBytes: number;
        storageType: "local" | "s3" | "sftp" | "b2";
        storagePath: string | null;
        checksum: string | null;
        encrypted: boolean;
        encryptionAlgorithm: "aes-256-cbc" | "aes-256-gcm" | null;
        startedAt: Date | null;
        completedAt: Date | null;
    }[]>;
    /**
     * Get a single backup record by ID
     */
    getBackup(backupId: string): Promise<{
        error: string | null;
        type: "full" | "files" | "database" | "dns" | "mail" | "config";
        status: "pending" | "failed" | "running" | "completed" | "restoring";
        id: string;
        createdAt: Date;
        websiteId: string | null;
        filename: string;
        sizeBytes: number;
        storageType: "local" | "s3" | "sftp" | "b2";
        storagePath: string | null;
        checksum: string | null;
        encrypted: boolean;
        encryptionAlgorithm: "aes-256-cbc" | "aes-256-gcm" | null;
        startedAt: Date | null;
        completedAt: Date | null;
    }>;
    /**
     * Create a backup
     */
    createBackup(data: {
        type: 'full' | 'files' | 'database' | 'dns' | 'mail' | 'config';
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        filename: string;
        sizeBytes: number;
    }>;
    /**
     * Restore a backup
     */
    restoreBackup(backupId: string, options?: {
        files?: boolean;
        databases?: boolean;
        dns?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        restored: boolean;
    }>;
    /**
     * Delete a backup
     */
    deleteBackup(backupId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List backup schedules
     */
    listSchedules(): Promise<{
        storageConfig: Record<string, string> | null;
        id: string;
        isActive: boolean;
        createdAt: Date;
        domainId: string | null;
        storageType: "local" | "s3" | "sftp" | "b2";
        cronExpression: string;
        scope: string;
        retentionCount: number;
        lastRunAt: Date | null;
        nextRunAt: Date | null;
    }[]>;
    /**
     * Create a backup schedule
     */
    createSchedule(data: {
        cronExpression: string;
        scope: string;
        retentionCount: number;
        storageType: string;
        storageConfig?: Record<string, string>;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        cronExpression: string;
        nextRunAt: Date;
    }>;
    /**
     * Toggle a backup schedule
     */
    toggleSchedule(scheduleId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        isActive: boolean;
    }>;
    /**
     * Delete a backup schedule
     */
    deleteSchedule(scheduleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Prepare a backup file for download.
     * Copies the file to a temp location with world-readable permissions
     * so it can be streamed by the Node.js process.
     */
    prepareDownload(backupId: string): Promise<{
        tmpPath: string;
        filename: string;
        sizeBytes: number;
    }>;
    /**
     * Get download URL/path for a backup
     */
    getDownloadUrl(backupId: string): Promise<string>;
    /**
     * Verify a backup's integrity
     */
    verifyBackup(backupId: string): Promise<{
        valid: boolean;
        checksum: string;
        sizeBytes: number;
        checkedAt: string;
        errors?: string[];
    }>;
    /**
     * Get remote storage configuration
     */
    getStorageConfig(): Promise<{
        type: string;
        s3?: Record<string, string>;
        sftp?: Record<string, string>;
    }>;
    /**
     * Update remote storage configuration
     */
    updateStorageConfig(config: {
        type: string;
        s3?: Record<string, string>;
        sftp?: Record<string, string>;
    }, userId?: string, ipAddress?: string): Promise<{
        type: string;
        s3?: Record<string, string>;
        sftp?: Record<string, string>;
    }>;
    /**
     * Execute all backup schedules that are due
     */
    executeDueBackups(): Promise<void>;
    /**
     * Calculate the next run time from a cron expression
     */
    private calculateNextRun;
    /**
     * Enforce retention policy for a backup schedule
     * Deletes oldest backups beyond the retention count
     */
    private enforceRetention;
    /**
     * List backups by websiteId
     */
    listByWebsite(websiteId: string): Promise<{
        error: string | null;
        type: "full" | "files" | "database" | "dns" | "mail" | "config";
        status: "pending" | "failed" | "running" | "completed" | "restoring";
        id: string;
        createdAt: Date;
        websiteId: string | null;
        filename: string;
        sizeBytes: number;
        storageType: "local" | "s3" | "sftp" | "b2";
        storagePath: string | null;
        checksum: string | null;
        encrypted: boolean;
        encryptionAlgorithm: "aes-256-cbc" | "aes-256-gcm" | null;
        startedAt: Date | null;
        completedAt: Date | null;
    }[]>;
}
//# sourceMappingURL=backup.service.d.ts.map