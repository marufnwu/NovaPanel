import { z } from 'zod';
export declare const addFirewallRuleSchema: z.ZodObject<{
    action: z.ZodEnum<["allow", "deny"]>;
    port: z.ZodOptional<z.ZodString>;
    protocol: z.ZodOptional<z.ZodEnum<["tcp", "udp"]>>;
    from: z.ZodOptional<z.ZodString>;
    to: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    action: "allow" | "deny";
    protocol?: "tcp" | "udp" | undefined;
    from?: string | undefined;
    port?: string | undefined;
    to?: string | undefined;
}, {
    action: "allow" | "deny";
    protocol?: "tcp" | "udp" | undefined;
    from?: string | undefined;
    port?: string | undefined;
    to?: string | undefined;
}>;
//# sourceMappingURL=firewall.schema.d.ts.map