export declare class CloudflareService {
    /**
     * Get the CloudflareClient for a stored zone
     */
    private getClientForZone;
    /**
     * Get a CloudflareClient using the stored tunnel API token
     */
    private getClientFromTunnel;
    /**
     * List all Cloudflare zones (from Cloudflare API)
     */
    listZones(apiToken: string, page?: number, perPage?: number): Promise<{
        zones: import("../../services/cloudflare-client.js").CloudflareZone[];
        total_count: number;
    }>;
    /**
     * Link a Cloudflare zone to NovaPanel (store credentials)
     */
    linkZone(data: {
        zoneId?: string;
        zoneName?: string;
        apiToken: string;
        accountId?: string;
        domainId?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        zoneId: string;
        zoneName: string;
        plan: string;
        status: "active" | "pending" | "initializing" | "moved" | "deleted";
        sslMode: string;
        nameservers: string[];
    }>;
    /**
     * Unlink a Cloudflare zone from NovaPanel
     */
    unlinkZone(zoneDbId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get zone overview (live data from Cloudflare API)
     */
    getZoneOverview(zoneDbId: string): Promise<{
        id: string;
        zoneId: string;
        zoneName: string;
        status: "active" | "pending" | "initializing" | "moved" | "deleted";
        paused: boolean;
        plan: string;
        nameservers: string[];
        originalNameservers: string[];
        sslMode: string | null;
        dnsRecordCount: number;
        pageRuleCount: number;
        createdAt: string;
        activatedAt: string;
    }>;
    /**
     * List all linked zones from database
     */
    listLinkedZones(): Promise<{
        status: string | null;
        id: string;
        createdAt: Date;
        domainId: string | null;
        zoneId: string | null;
        accountId: string | null;
        apiToken: string | null;
        zoneName: string;
        plan: string | null;
        sslMode: string | null;
        isPaused: boolean | null;
        nameservers: string | null;
        lastSyncAt: Date | null;
    }[]>;
    /**
     * List DNS records (live from Cloudflare API)
     */
    listDnsRecords(zoneDbId: string, params?: {
        type?: string;
        name?: string;
        page?: number;
        perPage?: number;
    }): Promise<{
        records: import("../../services/cloudflare-client.js").CloudflareDnsRecord[];
        total_count: number;
    }>;
    /**
     * Create a DNS record via Cloudflare API
     */
    createDnsRecord(zoneDbId: string, data: {
        type: string;
        name: string;
        content: string;
        proxied?: boolean;
        ttl?: number;
        priority?: number;
        comment?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareDnsRecord>;
    /**
     * Update a DNS record via Cloudflare API
     */
    updateDnsRecord(zoneDbId: string, recordId: string, data: {
        type?: string;
        name?: string;
        content?: string;
        proxied?: boolean;
        ttl?: number;
        priority?: number;
        comment?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareDnsRecord>;
    /**
     * Delete a DNS record via Cloudflare API
     */
    deleteDnsRecord(zoneDbId: string, recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get SSL settings for a zone
     */
    getSslSettings(zoneDbId: string): Promise<{
        sslMode: string | null;
        alwaysUseHttps: boolean;
        automaticHttpsRewrites: boolean;
        minTlsVersion: string | number | true;
        http2: boolean;
        http3: boolean;
        hsts: any;
    }>;
    /**
     * Update SSL/TLS settings for a zone
     */
    updateSslSettings(zoneDbId: string, settings: {
        sslMode?: 'off' | 'flexible' | 'full' | 'strict';
        alwaysUseHttps?: boolean;
        automaticHttpsRewrites?: boolean;
        minTlsVersion?: '1.0' | '1.1' | '1.2' | '1.3';
        http2?: boolean;
        http3?: boolean;
        browserCacheTtl?: number;
        developmentMode?: boolean;
        emailObfuscation?: boolean;
        hotlinkProtection?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        updated: boolean;
    }>;
    /**
     * Create a Cloudflare Origin CA certificate
     */
    createOriginCertificate(zoneDbId: string, hostnames: string[], validityDays?: number, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareOriginCertificate>;
    /**
     * Purge cache
     */
    purgeCache(zoneDbId: string, data: {
        purgeEverything?: boolean;
        files?: string[];
        tags?: string[];
    }, userId?: string, ipAddress?: string): Promise<{
        purged: boolean;
    }>;
    /**
     * List firewall rules
     */
    listFirewallRules(zoneDbId: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule[]>;
    /**
     * Create a firewall rule
     */
    createFirewallRule(zoneDbId: string, data: {
        action: string;
        expression: string;
        description?: string;
        paused?: boolean;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule>;
    /**
     * Delete a firewall rule
     */
    deleteFirewallRule(zoneDbId: string, ruleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List access rules (IP allowlist/blocklist)
     */
    listAccessRules(zoneDbId: string): Promise<import("../../services/cloudflare-client.js").CloudflareAccessRule[]>;
    /**
     * Create an access rule
     */
    createAccessRule(zoneDbId: string, data: {
        mode: string;
        target: string;
        value: string;
        notes?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareAccessRule>;
    /**
     * Delete an access rule
     */
    deleteAccessRule(zoneDbId: string, ruleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List redirect rules (from database + Cloudflare API)
     */
    listRedirectRules(zoneDbId: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        zoneId: string;
        ruleId: string | null;
        sourcePattern: string;
        destinationUrl: string;
        redirectType: "301" | "302" | null;
    }[]>;
    /**
     * Create a redirect rule via Cloudflare Page Rules API
     */
    createRedirectRule(zoneDbId: string, data: {
        sourcePattern: string;
        destinationUrl: string;
        redirectType: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        ruleId: string;
        sourcePattern: string;
        destinationUrl: string;
        redirectType: string;
    }>;
    /**
     * Delete a redirect rule
     */
    deleteRedirectRule(zoneDbId: string, ruleDbId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Apply mail provider preset DNS records
     */
    applyMailPreset(zoneDbId: string, provider: string, customRecords?: Array<{
        type: string;
        name: string;
        content: string;
        priority?: number;
    }>, userId?: string, ipAddress?: string): Promise<{
        applied: number;
        results: (import("../../services/cloudflare-client.js").CloudflareDnsRecord | {
            error: any;
            type: string;
            name: string;
        })[];
    }>;
    /**
     * Verify DNS setup for a domain
     */
    verifyDns(zoneDbId: string): Promise<{
        zone: string;
        zoneId: string | null;
        status: string | null;
        sslMode: string | null;
        totalRecords: number;
        tunnelCnameFound: boolean;
        tunnelCnameCorrect: boolean;
        records: {
            id: string;
            type: string;
            name: string;
            content: string;
            proxied: boolean;
            ttl: number;
        }[];
    }>;
    /**
     * Pause/unpause Cloudflare proxy for a zone
     */
    togglePause(zoneDbId: string, pause: boolean, userId?: string, ipAddress?: string): Promise<{
        paused: boolean;
    }>;
    /**
     * Get all zone settings as a structured object
     */
    getZoneSettings(zoneDbId: string): Promise<{
        sslMode: "full" | "flexible" | "strict" | "off" | undefined;
        alwaysUseHttps: boolean;
        automaticHttpsRewrites: boolean;
        minTlsVersion: string | number | boolean | undefined;
        http2: boolean;
        http3: boolean;
        browserCacheTtl: number | undefined;
        developmentMode: boolean;
        emailObfuscation: boolean;
        hotlinkProtection: boolean;
        hsts: any;
    }>;
    /**
     * Enable wildcard subdomain for a zone.
     * Creates *.domain CNAME in Cloudflare + wildcard tunnel route + nginx catch-all.
     * Requires paid Cloudflare plan (Pro+) for proxied wildcard DNS.
     */
    enableWildcard(zoneDbId: string, domainId: string, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
        pattern: string;
    }>;
    /**
     * Disable wildcard subdomain for a zone.
     * Removes *.domain CNAME from Cloudflare + wildcard tunnel route.
     */
    disableWildcard(zoneDbId: string, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
    }>;
    /**
     * Get wildcard status for a zone
     */
    getWildcardStatus(zoneDbId: string): Promise<{
        enabled: boolean;
        dnsRecord: boolean;
        tunnelRoute: boolean;
        planName: any;
        canEnable: boolean;
        pattern: string;
    }>;
    /**
     * Comprehensive end-to-end verification for a domain's Cloudflare setup.
     * Checks: DNS CNAME, tunnel route, SSL mode, zone status, HTTP reachability.
     */
    verifyDomainSetup(zoneDbId: string): Promise<{
        domain: string;
        healthy: boolean;
        checks: {
            dns: {
                ok: boolean;
                details: string;
                records: any[];
            };
            tunnel: {
                ok: boolean;
                details: string;
                route?: any;
            };
            ssl: {
                ok: boolean;
                details: string;
                mode?: string;
            };
            zone: {
                ok: boolean;
                details: string;
                status?: string;
                paused?: boolean;
            };
            http: {
                ok: boolean;
                details: string;
                statusCode?: number;
                latencyMs?: number;
            };
        };
        summary: string;
        timestamp: string;
    }>;
    /**
     * Get Cloudflare integration status for a specific domain.
     * Used by domain list/detail pages to show CF integration status.
     */
    getDomainCloudflareStatus(domainId: string): Promise<{
        integrated: boolean;
        reason: string;
        zoneId?: undefined;
        zoneName?: undefined;
        zoneStatus?: undefined;
        sslMode?: undefined;
        isPaused?: undefined;
        plan?: undefined;
        hasTunnelRoute?: undefined;
        tunnelRoutes?: undefined;
        subdomainRoutes?: undefined;
        lastSyncAt?: undefined;
    } | {
        integrated: boolean;
        zoneId: string;
        zoneName: string;
        zoneStatus: string | null;
        sslMode: string | null;
        isPaused: boolean | null;
        plan: string | null;
        hasTunnelRoute: boolean;
        tunnelRoutes: {
            hostname: string;
            service: string;
        }[];
        subdomainRoutes: {
            subdomain: string;
            hasRoute: boolean;
            active: boolean | null;
        }[];
        lastSyncAt: Date | null;
        reason?: undefined;
    }>;
    /**
     * Get Cloudflare status summary for all domains.
     * Used by domain list page to show CF badges.
     */
    getAllDomainCloudflareStatus(): Promise<Record<string, {
        hasZone: boolean;
        zoneName?: string;
        sslMode?: string;
        hasTunnelRoute: boolean;
        routeCount: number;
    }>>;
}
//# sourceMappingURL=cloudflare.service.d.ts.map