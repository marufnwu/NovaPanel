import { z } from 'zod';
export declare const createDbSchema: z.ZodEffects<z.ZodEffects<z.ZodObject<{
    domainId: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    engine: z.ZodDefault<z.ZodEnum<["mariadb", "postgresql"]>>;
    charset: z.ZodOptional<z.ZodString>;
    /** When true, also create a database user with access to this database */
    createUser: z.ZodDefault<z.ZodBoolean>;
    /** Username for the auto-created user (required if createUser is true) */
    username: z.ZodOptional<z.ZodString>;
    /** Password for the auto-created user (required if createUser is true) */
    password: z.ZodOptional<z.ZodString>;
    /** Host for the auto-created user */
    host: z.ZodDefault<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    engine: "mariadb" | "postgresql";
    host: string;
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    charset?: string | undefined;
    password?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    engine?: "mariadb" | "postgresql" | undefined;
    charset?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    createUser?: boolean | undefined;
}>, {
    name: string;
    engine: "mariadb" | "postgresql";
    host: string;
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    charset?: string | undefined;
    password?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    engine?: "mariadb" | "postgresql" | undefined;
    charset?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    createUser?: boolean | undefined;
}>, {
    name: string;
    engine: "mariadb" | "postgresql";
    host: string;
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    charset?: string | undefined;
    password?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    engine?: "mariadb" | "postgresql" | undefined;
    charset?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    createUser?: boolean | undefined;
}>;
export declare const createUserSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    host: z.ZodDefault<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    username: string;
    host: string;
    password: string;
}, {
    username: string;
    password: string;
    host?: string | undefined;
}>;
export declare const changePasswordSchema: z.ZodObject<{
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    password: string;
}, {
    password: string;
}>;
export declare const importDbSchema: z.ZodObject<{
    sql: z.ZodString;
}, "strip", z.ZodTypeAny, {
    sql: string;
}, {
    sql: string;
}>;
//# sourceMappingURL=databases.schema.d.ts.map