/**
 * Network detection result
 */
export interface NetworkInfo {
    localIps: string[];
    hasPublicIp: boolean;
    publicIp: string | null;
    primaryIp: string;
}
/**
 * Detect network information for this server
 * Results are cached for 5 minutes to avoid excessive external calls
 */
export declare function detectNetworkInfo(): Promise<NetworkInfo>;
/**
 * Check if a URL contains a private IP address
 */
export declare function isPrivateUrl(urlString: string): boolean;
/**
 * Parse PANEL_URL and determine if it's private
 */
export declare function getPanelUrlInfo(): {
    panelUrl: string;
    panelUrlIsPrivate: boolean;
};
//# sourceMappingURL=network.d.ts.map