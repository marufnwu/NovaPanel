export interface ExecResult {
    stdout: string;
    stderr: string;
    exitCode: number;
    success: boolean;
}
export interface ExecOptions {
    cwd?: string;
    env?: Record<string, string>;
    timeout?: number;
    sudo?: boolean;
    /** When sudo is true, run the command as this user (e.g. 'postgres') via sudo -u */
    sudoUser?: string;
    input?: string;
}
/**
 * Execute a system command safely via execa.
 * All commands are validated against an allowlist.
 * No shell interpolation is used.
 */
export declare function run(command: string, args?: string[], options?: ExecOptions): Promise<ExecResult>;
/**
 * Run a command that is not in the allowlist.
 * ONLY for internal trusted operations. Always logged at WARN.
 */
export declare function runTrusted(command: string, args?: string[], options?: ExecOptions): Promise<ExecResult>;
//# sourceMappingURL=executor.d.ts.map