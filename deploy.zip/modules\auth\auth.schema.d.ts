import { z } from 'zod';
export declare const loginSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    rememberMe: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    username: string;
    rememberMe: boolean;
    password: string;
}, {
    username: string;
    password: string;
    rememberMe?: boolean | undefined;
}>;
export declare const verify2faSchema: z.ZodObject<{
    tempToken: z.ZodString;
    code: z.ZodString;
    rememberMe: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    code: string;
    rememberMe: boolean;
    tempToken: string;
}, {
    code: string;
    tempToken: string;
    rememberMe?: boolean | undefined;
}>;
export declare const enable2faResponseSchema: z.ZodObject<{
    secret: z.ZodString;
    qrCodeUri: z.ZodString;
    manualEntryKey: z.ZodString;
}, "strip", z.ZodTypeAny, {
    secret: string;
    qrCodeUri: string;
    manualEntryKey: string;
}, {
    secret: string;
    qrCodeUri: string;
    manualEntryKey: string;
}>;
export declare const verify2faAndEnableSchema: z.ZodObject<{
    code: z.ZodString;
    secret: z.ZodString;
}, "strip", z.ZodTypeAny, {
    code: string;
    secret: string;
}, {
    code: string;
    secret: string;
}>;
export declare const disable2faSchema: z.ZodObject<{
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    password: string;
}, {
    password: string;
}>;
export declare const forgotPasswordSchema: z.ZodObject<{
    email: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
}, {
    email: string;
}>;
export declare const verifyResetTokenSchema: z.ZodObject<{
    token: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
}, {
    token: string;
}>;
export declare const resetPasswordSchema: z.ZodObject<{
    token: z.ZodString;
    newPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    token: string;
    newPassword: string;
}, {
    token: string;
    newPassword: string;
}>;
export declare const regenerateBackupCodesSchema: z.ZodObject<{
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    password: string;
}, {
    password: string;
}>;
export declare const generateApiTokenSchema: z.ZodObject<{
    name: z.ZodString;
    expiresAt: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    expiresAt?: string | undefined;
}, {
    name: string;
    expiresAt?: string | undefined;
}>;
export declare const changePasswordSchema: z.ZodObject<{
    currentPassword: z.ZodString;
    newPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    currentPassword: string;
    newPassword: string;
}, {
    currentPassword: string;
    newPassword: string;
}>;
export declare const changeEmailSchema: z.ZodObject<{
    newEmail: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    newEmail: string;
    password: string;
}, {
    newEmail: string;
    password: string;
}>;
export declare const updateProfileSchema: z.ZodObject<{
    displayName: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    displayName?: string | undefined;
}, {
    displayName?: string | undefined;
}>;
export type LoginInput = z.infer<typeof loginSchema>;
export type Verify2faInput = z.infer<typeof verify2faSchema>;
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;
export type VerifyResetTokenInput = z.infer<typeof verifyResetTokenSchema>;
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;
export type RegenerateBackupCodesInput = z.infer<typeof regenerateBackupCodesSchema>;
export type GenerateApiTokenInput = z.infer<typeof generateApiTokenSchema>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;
export type ChangeEmailInput = z.infer<typeof changeEmailSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
//# sourceMappingURL=auth.schema.d.ts.map