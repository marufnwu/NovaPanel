import { z } from 'zod';
export declare const createCronJobSchema: z.ZodObject<{
    command: z.ZodString;
    schedule: z.ZodString;
}, "strip", z.ZodTypeAny, {
    command: string;
    schedule: string;
}, {
    command: string;
    schedule: string;
}>;
//# sourceMappingURL=cron.schema.d.ts.map