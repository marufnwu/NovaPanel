import type { FastifyInstance } from 'fastify';
export declare function registerTunnelLogsWs(fastify: FastifyInstance): Promise<void>;
export declare function cleanupStaleLogSessions(): void;
//# sourceMappingURL=tunnel.ws.d.ts.map