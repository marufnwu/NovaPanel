import { DatabasesService } from './databases.service.js';
import { createDbSchema, createUserSchema, changePasswordSchema, importDbSchema } from './databases.schema.js';
import { requireAuth } from '../auth/auth.middleware.js';
export default async function databaseRoutes(fastify) {
    const service = new DatabasesService();
    fastify.addHook('preHandler', requireAuth);
    // GET /databases — List databases
    fastify.get('/databases', async (req) => {
        const { domainId, page, perPage } = req.query;
        return {
            success: true,
            data: await service.list(domainId, parseInt(page || '1'), parseInt(perPage || '20')),
        };
    });
    // POST /databases — Create database
    fastify.post('/databases', async (req, reply) => {
        const data = createDbSchema.parse(req.body);
        const result = await service.create(data, req.user.id, req.ip);
        return reply.status(201).send({ success: true, data: result });
    });
    // GET /databases/:id — Get single database
    fastify.get('/databases/:id', async (req) => {
        const { id } = req.params;
        return { success: true, data: await service.getDatabase(id) };
    });
    // DELETE /databases/:id — Delete database
    fastify.delete('/databases/:id', async (req) => {
        const { id } = req.params;
        await service.delete(id, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // POST /databases/:id/users — Create database user
    fastify.post('/databases/:id/users', async (req) => {
        const { id } = req.params;
        const { username, password, host } = createUserSchema.parse(req.body);
        return { success: true, data: await service.createUser(id, username, password, host, req.user.id, req.ip) };
    });
    // DELETE /databases/:id/users/:userId — Delete database user
    fastify.delete('/databases/:id/users/:userId', async (req) => {
        const { userId } = req.params;
        await service.deleteUser(userId, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // PUT /databases/:id/users/:userId/password — Change user password
    fastify.put('/databases/:id/users/:userId/password', async (req) => {
        const { userId } = req.params;
        const { password } = changePasswordSchema.parse(req.body);
        await service.changeUserPassword(userId, password, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // GET /databases/:id/export — Export database
    fastify.get('/databases/:id/export', async (req) => {
        const { id } = req.params;
        const sql = await service.exportDatabase(id, req.user.id, req.ip);
        return { success: true, data: { sql } };
    });
    // POST /databases/:id/import — Import database
    fastify.post('/databases/:id/import', async (req) => {
        const { id } = req.params;
        const { sql } = importDbSchema.parse(req.body);
        await service.importDatabase(id, sql, req.user.id, req.ip);
        return { success: true, data: null };
    });
    // GET /databases/:id/info — Get database info (users, size)
    fastify.get('/databases/:id/info', async (req) => {
        const { id } = req.params;
        return { success: true, data: await service.getDatabaseInfo(id) };
    });
    // POST /databases/:id/repair — Repair MariaDB tables
    fastify.post('/databases/:id/repair', async (req) => {
        const { id } = req.params;
        return { success: true, data: await service.repairDatabase(id, req.user.id, req.ip) };
    });
    // POST /databases/:id/optimize — Optimize MariaDB tables
    fastify.post('/databases/:id/optimize', async (req) => {
        const { id } = req.params;
        return { success: true, data: await service.optimizeDatabase(id, req.user.id, req.ip) };
    });
    // POST /databases/:id/clone — Clone database
    fastify.post('/databases/:id/clone', async (req) => {
        const { id } = req.params;
        const { newName } = req.body;
        return { success: true, data: await service.cloneDatabase(id, newName, req.user.id, req.ip) };
    });
    // POST /databases/:id/query — Execute SQL query
    fastify.post('/databases/:id/query', async (req) => {
        const { id } = req.params;
        const { sql } = req.body;
        return { success: true, data: await service.runQuery(id, sql) };
    });
}
//# sourceMappingURL=databases.routes.js.map