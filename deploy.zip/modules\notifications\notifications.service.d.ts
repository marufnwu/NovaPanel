export type NotificationType = 'ssl_expiry' | 'backup_complete' | 'cron_failed' | 'security_alert' | 'disk_space_low' | 'service_down' | 'info';
export interface NotificationPreferences {
    emailEnabled: boolean;
    pushEnabled: boolean;
    sslExpiry: boolean;
    backupComplete: boolean;
    cronFailed: boolean;
    securityAlert: boolean;
    diskSpaceLow: boolean;
    serviceDown: boolean;
}
export declare class NotificationsService {
    /**
     * Get notification preferences for a user
     */
    getPreferences(userId: string): Promise<{
        emailEnabled: boolean;
        pushEnabled: boolean;
        sslExpiry: boolean;
        backupComplete: boolean;
        cronFailed: boolean;
        securityAlert: boolean;
        diskSpaceLow: boolean;
        serviceDown: boolean;
    }>;
    /**
     * Update notification preferences
     */
    updatePreferences(userId: string, data: Partial<NotificationPreferences>): Promise<{
        emailEnabled: boolean;
        pushEnabled: boolean;
        sslExpiry: boolean;
        backupComplete: boolean;
        cronFailed: boolean;
        securityAlert: boolean;
        diskSpaceLow: boolean;
        serviceDown: boolean;
    }>;
    /**
     * List notifications for a user.
     * Maps DB rows to a consistent shape with serialisable date strings.
     */
    listNotifications(userId: string, limit?: number, offset?: number): Promise<{
        notifications: {
            id: string;
            userId: string;
            type: "info" | "ssl_expiry" | "backup_complete" | "cron_failed" | "security_alert" | "disk_space_low" | "service_down";
            title: string;
            message: string;
            isRead: boolean;
            readAt: string | null;
            createdAt: string;
        }[];
        total: number;
    }>;
    /**
     * Get unread notification count
     */
    getUnreadCount(userId: string): Promise<number>;
    /**
     * Mark notification as read
     */
    markAsRead(notificationId: string, userId: string): Promise<void>;
    /**
     * Mark all notifications as read
     */
    markAllAsRead(userId: string): Promise<void>;
    /**
     * Create a notification
     */
    createNotification(userId: string, type: NotificationType, title: string, message: string): Promise<{
        id: string;
    }>;
    /**
     * Delete a notification
     */
    deleteNotification(notificationId: string, userId: string): Promise<void>;
}
export declare const notificationsService: NotificationsService;
//# sourceMappingURL=notifications.service.d.ts.map