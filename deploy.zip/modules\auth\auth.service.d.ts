export declare class AuthService {
    login(username: string, password: string, rememberMe?: boolean, ipAddress?: string): Promise<{
        sessionId: string;
        sessionHash: string;
        user: {
            id: any;
            username: any;
            email: any;
            displayName: any;
            role: any;
            twoFactorEnabled: any;
            mustChangePassword: any;
        };
    } | {
        requiresTwoFactor: boolean;
        tempToken: string;
    }>;
    private issueTempToken;
    verify2FA(tempToken: string, code: string, rememberMe?: boolean, ipAddress?: string): Promise<{
        sessionId: string;
        sessionHash: string;
        user: {
            id: any;
            username: any;
            email: any;
            displayName: any;
            role: any;
            twoFactorEnabled: any;
            mustChangePassword: any;
        };
    }>;
    private createSession;
    logout(sessionId: string, userId?: string, ipAddress?: string): Promise<void>;
    validateSession(sessionId: string): Promise<{
        session: {
            id: string;
            createdAt: Date;
            userId: string;
            sessionHash: string;
            expiresAt: Date;
            lastActivityAt: Date;
            userAgent: string | null;
            ipAddress: string | null;
            rememberMe: boolean;
        };
        user: {
            id: string;
            username: string;
            email: string;
            displayName: string | null;
            passwordHash: string;
            role: "admin";
            isActive: boolean;
            twoFactorSecret: string | null;
            twoFactorEnabled: boolean;
            apiTokenHash: string | null;
            failedLoginAttempts: number;
            lockedUntil: Date | null;
            passwordChangedAt: Date | null;
            mustChangePassword: boolean;
            lastLoginAt: Date | null;
            passwordResetToken: string | null;
            passwordResetExpiresAt: Date | null;
            createdAt: Date;
            updatedAt: Date | null;
        };
    } | null>;
    validateSessionByHash(sessionHash: string): Promise<{
        session: {
            id: string;
            createdAt: Date;
            userId: string;
            sessionHash: string;
            expiresAt: Date;
            lastActivityAt: Date;
            userAgent: string | null;
            ipAddress: string | null;
            rememberMe: boolean;
        };
        user: {
            id: string;
            username: string;
            email: string;
            displayName: string | null;
            passwordHash: string;
            role: "admin";
            isActive: boolean;
            twoFactorSecret: string | null;
            twoFactorEnabled: boolean;
            apiTokenHash: string | null;
            failedLoginAttempts: number;
            lockedUntil: Date | null;
            passwordChangedAt: Date | null;
            mustChangePassword: boolean;
            lastLoginAt: Date | null;
            passwordResetToken: string | null;
            passwordResetExpiresAt: Date | null;
            createdAt: Date;
            updatedAt: Date | null;
        };
    } | null>;
    updateSessionActivity(sessionId: string): Promise<void>;
    cleanupExpiredSessions(): Promise<import("@libsql/client").ResultSet>;
    enable2FA(userId: string): Promise<{
        secret: string;
        qrCodeUri: string;
        manualEntryKey: string;
    }>;
    verifyAndEnable2FA(userId: string, encryptedSecret: string, code: string, ipAddress?: string): Promise<{
        enabled: boolean;
        backupCodes: string[];
    }>;
    disable2FA(userId: string, password: string, ipAddress?: string): Promise<{
        enabled: boolean;
    }>;
    /**
     * Generate a password reset token for a user and return the raw token.
     * The token is stored as a SHA-256 hash in the users table.
     */
    forgotPassword(email: string, ipAddress?: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Verify that a password reset token is valid without consuming it.
     */
    verifyResetToken(token: string): Promise<{
        valid: boolean;
        email?: string;
    }>;
    /**
     * Reset a user's password using a valid reset token.
     * Consumes the token (single-use).
     */
    resetPassword(token: string, newPassword: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Generate a set of random backup codes (10 codes, 10 hex chars each).
     */
    private generateBackupCodes;
    /**
     * Hash and store backup codes for a user.
     * Deletes any existing unused codes first.
     */
    private storeBackupCodes;
    /**
     * Verify a backup code for a user. Marks the code as used on success.
     */
    verifyBackupCode(userId: string, code: string): Promise<boolean>;
    /**
     * Regenerate backup codes for a user. Requires password verification.
     * Returns the new plain-text codes (only shown once).
     */
    regenerateBackupCodes(userId: string, password: string, ipAddress?: string): Promise<string[]>;
    /**
     * Get remaining backup codes for a user, masked for display.
     * Returns codes like "A1B2C*****" — only first 3 chars visible.
     */
    getBackupCodes(userId: string): Promise<Array<{
        id: string;
        masked: string;
        usedAt: Date | null;
    }>>;
    generateApiToken(userId: string, name: string, expiresAt?: Date, ipAddress?: string): Promise<{
        token: string;
        name: string;
        expiresAt: Date | undefined;
    }>;
    validateApiToken(token: string): Promise<{
        id: string;
        username: string;
        email: string;
        displayName: string | null;
        passwordHash: string;
        role: "admin";
        isActive: boolean;
        twoFactorSecret: string | null;
        twoFactorEnabled: boolean;
        apiTokenHash: string | null;
        failedLoginAttempts: number;
        lockedUntil: Date | null;
        passwordChangedAt: Date | null;
        mustChangePassword: boolean;
        lastLoginAt: Date | null;
        passwordResetToken: string | null;
        passwordResetExpiresAt: Date | null;
        createdAt: Date;
        updatedAt: Date | null;
    } | null>;
    getMe(userId: string): Promise<{
        id: string;
        username: string;
        email: string;
        displayName: string | null;
        role: "admin";
        twoFactorEnabled: boolean;
        mustChangePassword: boolean;
        lastLoginAt: Date | null;
        createdAt: Date;
    }>;
    changePassword(userId: string, currentPassword: string, newPassword: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    changeEmail(userId: string, newEmail: string, password: string): Promise<{
        success: boolean;
    }>;
    updateProfile(userId: string, data: {
        displayName?: string;
    }): Promise<{
        id: string;
        username: string;
        email: string;
        displayName: string | null;
        role: "admin";
        twoFactorEnabled: boolean;
        mustChangePassword: boolean;
        lastLoginAt: Date | null;
        createdAt: Date;
    }>;
    listSessions(userId: string): Promise<{
        id: string;
        userAgent: string | null;
        ipAddress: string | null;
        rememberMe: boolean;
        createdAt: Date;
        expiresAt: Date;
        browser: string;
        os: string;
    }[]>;
    revokeSession(userId: string, sessionId: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    revokeAllOtherSessions(userId: string, currentSessionId: string): Promise<{
        revoked: number;
    }>;
    private parseBrowser;
    private parseOS;
}
export declare const authService: AuthService;
//# sourceMappingURL=auth.service.d.ts.map