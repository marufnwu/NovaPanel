export declare class AuditService {
    /**
     * Log an audit event
     */
    log(data: {
        userId?: string;
        action: string;
        resource?: string;
        details?: string;
        ipAddress?: string;
        userAgent?: string;
    }): Promise<void>;
    /**
     * List audit logs with optional filtering
     */
    list(filters: {
        userId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        id: string;
        createdAt: Date;
        userId: string | null;
        userAgent: string | null;
        ipAddress: string | null;
        action: string;
        resource: string | null;
        details: string | null;
    }[]>;
}
export declare const auditService: AuditService;
//# sourceMappingURL=audit.service.d.ts.map