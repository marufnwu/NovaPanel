import type { FastifyRequest, FastifyReply } from 'fastify';
import type { User } from '../../db/schema/users.js';
declare module 'fastify' {
    interface FastifyRequest {
        user: User;
        sessionId: string;
        authMethod?: 'session' | 'token';
        tokenPermissions?: string[];
    }
}
export declare function requireAuth(req: FastifyRequest, _reply: FastifyReply): Promise<void>;
/**
 * Require a specific role. In single-admin mode, the only role is 'admin'.
 * Kept for backward compatibility with existing route definitions.
 */
export declare function requireRole(..._roles: string[]): (_req: FastifyRequest) => Promise<void>;
export declare function optionalAuth(req: FastifyRequest, _reply: FastifyReply): Promise<void>;
//# sourceMappingURL=auth.middleware.d.ts.map