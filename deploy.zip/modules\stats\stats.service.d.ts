export declare class StatsService {
    /**
     * Get real-time server stats: CPU, RAM, Disk, Uptime, Load, OS info
     */
    getServerStats(): Promise<ServerStats>;
    /**
     * Collect server stats and store them in the server_stats table
     */
    collectAndStore(stats: ServerStats): Promise<void>;
    /**
     * Get all disk mount points
     */
    getDiskDetails(): Promise<DiskMount[]>;
    /**
     * Get status of all managed services
     */
    getServiceStatuses(): Promise<ServiceStatusItem[]>;
    /**
     * Restart a service by name
     */
    restartService(serviceName: string, userId?: string): Promise<{
        success: boolean;
        log?: string;
    }>;
    /**
     * Get per-domain stats (disk usage)
     */
    getDomainStats(domainId: string): Promise<DomainStats>;
    /**
     * Get network I/O stats
     */
    getNetworkStats(): Promise<NetworkStats>;
    /**
     * Get summary counts for dashboard (single-admin: no subscriptions)
     */
    getDashboardSummary(): Promise<DashboardSummary>;
    /**
     * Get expiring SSL certificates with details
     */
    getExpiringSslCerts(days?: number): Promise<ExpiringSslCert[]>;
    /**
     * Get top processes by CPU or memory usage
     */
    getProcessList(sortBy?: 'cpu' | 'memory', limit?: number): Promise<ProcessInfo[]>;
    /**
     * Get TCP connection statistics
     */
    getTcpConnections(): Promise<TcpConnectionStats>;
    /**
     * Get file descriptor statistics
     */
    getFdStats(): Promise<FdStats>;
    /**
     * Get disk I/O statistics
     */
    getDiskIOStats(): Promise<DiskIOStats>;
    /**
     * Get per-domain bandwidth statistics
     */
    getDomainBandwidth(): Promise<DomainBandwidthStats[]>;
}
export interface ServerStats {
    cpu: {
        usage: number;
        cores: number;
    };
    memory: {
        total: number;
        used: number;
        available: number;
        cached: number;
        buffered: number;
        swapTotal: number;
        swapUsed: number;
        usagePercent: number;
    };
    disk: {
        total: number;
        used: number;
        available: number;
        usagePercent: number;
        mount: string;
    };
    uptime: number;
    loadAvg: number[];
    system: {
        hostname: string;
        os: string;
        kernel: string;
        arch: string;
        ips: string[];
    };
}
export interface DiskMount {
    fs: string;
    mount: string;
    total: number;
    used: number;
    available: number;
    usagePercent: number;
}
export interface ServiceStatusItem {
    name: string;
    displayName: string;
    status: 'running' | 'stopped' | 'error';
}
export interface DomainStats {
    domainId: string;
    domainName: string;
    diskUsedMb: number;
    status: string;
    sslEnabled: boolean;
    phpVersion: string;
}
export interface NetworkStats {
    interface: string;
    rxBytes: number;
    txBytes: number;
    rxSec: number;
    txSec: number;
}
export interface DashboardSummary {
    totalDomains: number;
    activeDomains: number;
    suspendedDomains: number;
    sslEnabledDomains: number;
    totalMailboxes: number;
    totalDatabases: number;
    totalFtpAccounts: number;
    totalActiveCronJobs: number;
    expiringSslCerts: number;
}
export interface ExpiringSslCert {
    id: string;
    domainId: string;
    domainName: string;
    issuer: string;
    expiresAt: string;
    daysUntilExpiry: number;
}
export interface ProcessInfo {
    pid: number;
    name: string;
    cpu: number;
    memory: number;
    state: string;
}
export interface TcpConnectionStats {
    established: number;
    timeWait: number;
    closeWait: number;
    total: number;
}
export interface FdStats {
    openFd: number;
    maxFd: number;
    usagePercent: number;
}
export interface DiskIOStats {
    readBytesSec: number;
    writeBytesSec: number;
    readOpsSec: number;
    writeOpsSec: number;
}
export interface DomainBandwidthStats {
    domainId: string;
    domainName: string;
    incomingBytes: number;
    outgoingBytes: number;
    totalBytes: number;
}
//# sourceMappingURL=stats.service.d.ts.map