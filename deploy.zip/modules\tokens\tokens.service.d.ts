export interface ApiToken {
    id: string;
    userId: string;
    name: string;
    tokenHash: string;
    permissions: string[];
    expiresAt: Date | null;
    createdAt: Date;
    lastUsedAt: Date | null;
}
export interface TokenUsageEntry {
    id: string;
    tokenId: string;
    method: string;
    path: string;
    statusCode: number;
    ipAddress: string;
    userAgent: string;
    timestamp: Date;
}
interface CreateTokenOptions {
    userId: string;
    name: string;
    expiresIn: string;
    permissions: string[];
}
export declare class TokensService {
    /**
     * List all tokens for a user (excludes the actual token hash).
     * Reads from the database so tokens survive restarts.
     */
    listTokens(userId: string): Promise<{
        permissions: any;
        id: string;
        userId: string;
        name: string;
        expiresAt: Date | null;
        createdAt: Date;
        lastUsedAt: Date | null;
    }[]>;
    /**
     * Generate a new API token.
     * Stores the SHA-256 hash in the database; returns the plain token only once.
     */
    generateToken(options: CreateTokenOptions, ipAddress?: string): Promise<{
        id: string;
        token: string;
        name: string;
        permissions: string[];
        expiresAt: Date | null;
        createdAt: Date;
    }>;
    /**
     * Revoke/delete a token.
     */
    revokeToken(userId: string, tokenId: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get usage history for a token (in-memory, recent only).
     */
    getTokenUsage(userId: string, tokenId: string): Promise<TokenUsageEntry[]>;
    /**
     * Record token usage (called from auth middleware when a Bearer token is used).
     */
    recordUsage(tokenId: string, method: string, path: string, statusCode: number, ipAddress: string, userAgent: string): void;
    /**
     * Validate an API token (used by auth middleware).
     * Hashes the provided token, looks it up in the DB, updates lastUsedAt,
     * and returns the token record together with the user info.
     */
    validateToken(rawToken: string): Promise<{
        valid: boolean;
        token?: ApiToken;
        user?: {
            id: string;
            username: string;
            email: string;
            displayName: string | null;
            role: string;
            isActive: boolean;
        };
    }>;
}
export declare const tokensService: TokensService;
export {};
//# sourceMappingURL=tokens.service.d.ts.map