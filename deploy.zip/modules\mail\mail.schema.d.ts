import { z } from 'zod';
export declare const createMailboxSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    quotaMb: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    username: string;
    quotaMb: number;
    password: string;
}, {
    username: string;
    password: string;
    quotaMb?: number | undefined;
}>;
export declare const updateMailboxSchema: z.ZodObject<{
    password: z.ZodOptional<z.ZodString>;
    quotaMb: z.ZodOptional<z.ZodNumber>;
    isActive: z.ZodOptional<z.ZodBoolean>;
    autoresponder: z.ZodOptional<z.ZodBoolean>;
    autoresponderMessage: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    isActive?: boolean | undefined;
    quotaMb?: number | undefined;
    autoresponder?: boolean | undefined;
    autoresponderMessage?: string | undefined;
    password?: string | undefined;
}, {
    isActive?: boolean | undefined;
    quotaMb?: number | undefined;
    autoresponder?: boolean | undefined;
    autoresponderMessage?: string | undefined;
    password?: string | undefined;
}>;
export declare const createAliasSchema: z.ZodObject<{
    alias: z.ZodString;
    destination: z.ZodString;
}, "strip", z.ZodTypeAny, {
    alias: string;
    destination: string;
}, {
    alias: string;
    destination: string;
}>;
export declare const createForwardSchema: z.ZodObject<{
    forwardTo: z.ZodString;
    keepCopy: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    forwardTo: string;
    keepCopy: boolean;
}, {
    forwardTo: string;
    keepCopy?: boolean | undefined;
}>;
//# sourceMappingURL=mail.schema.d.ts.map