import { installedApps } from '../../db/schema/installed-apps.js';
type InstalledApp = typeof installedApps.$inferSelect;
export declare class InstallerService {
    /**
     * Get list of available applications
     */
    getAvailableApps(): Promise<InstalledApp[]>;
    /**
     * Get app by ID
     */
    getApp(appId: string): Promise<InstalledApp | undefined>;
    /**
     * Install an application
     */
    installApp(data: {
        appId: string;
        domain: string;
        path: string;
        adminEmail: string;
        adminPassword: string;
    }): Promise<{
        success: boolean;
        message: string;
        installedId?: string;
    }>;
    /**
     * Check installation status
     */
    getInstallStatus(installedId: string): Promise<{
        status: 'installing' | 'ready' | 'error';
        progress?: number;
        message?: string;
    }>;
    /**
     * Uninstall an app
     */
    uninstallApp(installedId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Update an app
     */
    updateApp(installedId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Get installation logs for an app
     */
    getInstallLogs(appId: string, limit?: number): Promise<any[]>;
    /**
     * Get all installed apps
     */
    getInstalledApps(): Promise<InstalledApp[]>;
    /**
     * Set app configuration
     */
    setAppConfig(installedId: string, configKey: string, configValue: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Get app configuration
     */
    getAppConfig(installedId: string): Promise<any[]>;
    /**
     * Delete app configuration
     */
    deleteAppConfig(installedId: string, configKey: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Generate a random password
     */
    private generatePassword;
    /**
     * List installed apps by websiteId
     */
    listByWebsite(websiteId: string): Promise<InstalledApp[]>;
}
export declare const installerService: InstallerService;
export {};
//# sourceMappingURL=installer.service.d.ts.map