import { z } from 'zod';
export declare const installAppSchema: z.ZodObject<{
    appId: z.ZodString;
    domain: z.ZodString;
    path: z.ZodString;
    adminEmail: z.ZodString;
    adminPassword: z.ZodString;
}, "strip", z.ZodTypeAny, {
    path: string;
    adminEmail: string;
    domain: string;
    appId: string;
    adminPassword: string;
}, {
    path: string;
    adminEmail: string;
    domain: string;
    appId: string;
    adminPassword: string;
}>;
export declare const uninstallAppSchema: z.ZodObject<{
    appId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    appId: string;
}, {
    appId: string;
}>;
export declare const updateAppSchema: z.ZodObject<{
    appId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    appId: string;
}, {
    appId: string;
}>;
export declare const setAppConfigSchema: z.ZodObject<{
    appId: z.ZodString;
    configKey: z.ZodString;
    configValue: z.ZodString;
}, "strip", z.ZodTypeAny, {
    appId: string;
    configKey: string;
    configValue: string;
}, {
    appId: string;
    configKey: string;
    configValue: string;
}>;
export declare const deleteAppConfigSchema: z.ZodObject<{
    appId: z.ZodString;
    configKey: z.ZodString;
}, "strip", z.ZodTypeAny, {
    appId: string;
    configKey: string;
}, {
    appId: string;
    configKey: string;
}>;
export declare const checkPathSchema: z.ZodObject<{
    path: z.ZodString;
}, "strip", z.ZodTypeAny, {
    path: string;
}, {
    path: string;
}>;
//# sourceMappingURL=installer.schema.d.ts.map