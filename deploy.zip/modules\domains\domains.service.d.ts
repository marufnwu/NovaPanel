import { cloudflareZones } from '../../db/schema/index.js';
interface ListOptions {
    page?: number;
    perPage?: number;
    search?: string;
    status?: string;
}
interface ListResult {
    items: any[];
    total: number;
    page: number;
    perPage: number;
}
export declare class DomainsService {
    /**
     * List domains with pagination and filtering
     */
    list(options?: ListOptions): Promise<ListResult>;
    /**
     * Get a single domain by ID
     */
    get(id: string): Promise<{
        type: "primary" | "subdomain" | "alias" | "redirect" | "parked" | "mail-only";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        sslEnabled: boolean;
        systemUser: string | null;
        diskUsedMb: number;
        bandwidthUsedMb: number;
        documentRoot: string;
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        webServer: "nginx" | "apache" | "nginx+apache";
        sslCertId: string | null;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        websiteId: string | null;
        redirectTarget: string | null;
        parentDomainId: string | null;
    }>;
    /**
     * Find an active Cloudflare Tunnel that can serve the given domain.
     * Looks for a tunnel with an API token (can manage DNS) and active status.
     */
    private findActiveTunnel;
    /**
     * Find a linked Cloudflare zone for the given domain name.
     * Matches by zoneName (exact) or by checking if the domain ends with a zone name.
     */
    private findLinkedZoneForDomain;
    /**
     * Auto-create a tunnel route + Cloudflare CNAME for a domain/subdomain.
     * This is called after domain creation to automatically wire up Cloudflare Tunnel.
     * Best-effort: logs warnings on failure but doesn't block domain creation.
     */
    private autoCreateTunnelRoute;
    /**
     * Auto-remove tunnel routes + Cloudflare CNAMEs for a domain.
     * Called during domain/subdomain deletion to clean up Cloudflare resources.
     * Best-effort: logs warnings on failure but doesn't block deletion.
     */
    private autoRemoveTunnelRoutes;
    /**
     * Create a new domain with support for the domain/website separation architecture.
     *
     * websiteMode controls whether a website is automatically created or linked:
     * - 'none'    → domain-only (DNS/SSL/Mail), no website, no nginx, no PHP-FPM
     * - 'create'  → auto-create a website for this domain (default, backward compatible)
     * - 'existing'→ attach to an existing website
     */
    create(data: {
        name: string;
        type?: 'primary' | 'subdomain' | 'alias' | 'redirect';
        parentDomainId?: string;
        redirectTarget?: string;
        websiteMode?: 'none' | 'create' | 'existing';
        websiteId?: string;
        websiteName?: string;
        documentRoot?: string;
        phpVersion?: string;
        phpHandler?: string;
        webServer?: string;
        createDnsZone?: boolean;
        enableMail?: boolean;
        makePublic?: boolean;
        tunnelId?: string;
        userId?: string;
        ipAddress?: string;
    }): Promise<{
        id: string;
        name: string;
        documentRoot: string;
        type: "primary" | "subdomain" | "alias" | "redirect";
        websiteId: string | null;
        status: string;
    }>;
    /**
     * Update domain settings
     */
    update(id: string, data: {
        phpVersion?: string;
        phpHandler?: string;
        webServer?: string;
        redirectHttpToHttps?: boolean;
        hsts?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        type: "primary" | "subdomain" | "alias" | "redirect" | "parked" | "mail-only";
        status: "active" | "suspended" | "pending";
        id: string;
        name: string;
        createdAt: Date;
        sslEnabled: boolean;
        systemUser: string | null;
        diskUsedMb: number;
        bandwidthUsedMb: number;
        documentRoot: string;
        phpVersion: string;
        phpHandler: "php-fpm" | "cgi" | "disabled";
        webServer: "nginx" | "apache" | "nginx+apache";
        sslCertId: string | null;
        redirectHttpToHttps: boolean;
        hsts: boolean;
        websiteId: string | null;
        redirectTarget: string | null;
        parentDomainId: string | null;
    }>;
    /**
     * Delete a domain with full cascade cleanup.
     *
     * When the domain is attached to a website:
     * - Cleans up domain-specific services (mail, databases, FTP, SSL, DNS)
     * - If type is 'primary' and this is the last primary domain on the website:
     *   - If deleteWebsite=true → cascade deletes the entire website
     *   - Otherwise → just detaches the domain from the website
     * - For non-primary domains or when not deleting website → detaches and regenerates nginx
     *
     * When the domain has no website (domain-only):
     * - Uses the legacy full cleanup (PHP-FPM, Apache, Nginx, files, system user)
     */
    delete(id: string, deleteWebsite?: boolean, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Suspend a domain (return 503).
     * Backs up the original nginx config before overwriting.
     */
    suspend(id: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Activate a suspended domain.
     * Restores the original nginx config from backup if available,
     * otherwise regenerates from DB fields.
     */
    activate(id: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Regenerate nginx vhost config from DB domain fields (fallback for activate)
     */
    private regenerateVhost;
    listSubdomains(domainId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        documentRoot: string;
        phpVersion: string | null;
        domainId: string;
    }[]>;
    createSubdomain(domainId: string, data: {
        name: string;
        documentRoot?: string;
        phpVersion?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        documentRoot: string;
    }>;
    deleteSubdomain(domainId: string, subdomainId: string, userId?: string, ipAddress?: string): Promise<void>;
    listAliases(domainId: string): Promise<{
        id: string;
        createdAt: Date;
        alias: string;
        domainId: string;
    }[]>;
    createAlias(domainId: string, alias: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        alias: string;
    }>;
    deleteAlias(domainId: string, aliasId: string, userId?: string, ipAddress?: string): Promise<void>;
    listRedirects(domainId: string): Promise<{
        type: "301" | "302";
        id: string;
        createdAt: Date;
        domainId: string;
        sourcePath: string;
        targetUrl: string;
    }[]>;
    createRedirect(domainId: string, data: {
        sourcePath: string;
        targetUrl: string;
        type: '301' | '302';
    }, userId?: string, ipAddress?: string): Promise<{
        sourcePath: string;
        targetUrl: string;
        type: "301" | "302";
        id: string;
    }>;
    deleteRedirect(domainId: string, redirectId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get log stats for a domain
     */
    getLogStats(domainId: string): Promise<{
        totalRequests: number;
        errorCount: number;
        errorRate: number;
        topUrls: never[];
    }>;
    /**
     * Get access log for a domain
     */
    getAccessLog(domainId: string, lines?: number): Promise<string>;
    /**
     * Get Cloudflare status for a domain.
     * Determines the overall connectivity status based on tunnel route, SSL, and redirect rules.
     */
    getCloudflareStatus(domainId: string): Promise<{
        hasTunnelRoute: boolean;
        tunnelStatus: string | null;
        hasSsl: boolean;
        hasRedirects: boolean;
        overall: "suspended" | "redirect" | "local" | "live";
    }>;
    /**
     * Get error log for a domain
     */
    getErrorLog(domainId: string, lines?: number): Promise<string>;
    /**
     * Get the linked Cloudflare zone for a domain by domainId.
     * Returns the zone if found, null otherwise.
     */
    getCloudflareZoneForDomain(domainId: string): Promise<typeof cloudflareZones.$inferSelect | null>;
    /**
     * Get DNS records for a domain's linked Cloudflare zone.
     */
    getCloudflareDnsForDomain(domainId: string, options?: {
        type?: string;
        name?: string;
        page?: number;
        perPage?: number;
    }): Promise<{
        records: import("../../services/cloudflare-client.js").CloudflareDnsRecord[];
        total_count: number;
    }>;
    /**
     * Create a DNS record for a domain's linked Cloudflare zone.
     */
    createCloudflareDnsRecord(domainId: string, data: {
        type: string;
        name: string;
        content: string;
        proxied?: boolean;
        ttl?: number;
        priority?: number;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareDnsRecord>;
    /**
     * Delete a DNS record from a domain's linked Cloudflare zone.
     */
    deleteCloudflareDnsRecord(domainId: string, recordId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get SSL settings for a domain's linked Cloudflare zone.
     */
    getCloudflareSslForDomain(domainId: string): Promise<{
        sslMode: string | null;
        alwaysUseHttps: boolean;
        automaticHttpsRewrites: boolean;
        minTlsVersion: string | number | true;
        http2: boolean;
        http3: boolean;
        hsts: any;
    }>;
    /**
     * Update SSL settings for a domain's linked Cloudflare zone.
     */
    updateCloudflareSslForDomain(domainId: string, data: any, userId?: string, ipAddress?: string): Promise<{
        updated: boolean;
    }>;
    /**
     * Get firewall rules for a domain's linked Cloudflare zone.
     */
    getCloudflareFirewallForDomain(domainId: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule[]>;
    /**
     * Create a firewall rule for a domain's linked Cloudflare zone.
     */
    createCloudflareFirewallRule(domainId: string, data: {
        action: string;
        expression: string;
        description?: string;
    }, userId?: string, ipAddress?: string): Promise<import("../../services/cloudflare-client.js").CloudflareFirewallRule>;
    /**
     * Delete a firewall rule from a domain's linked Cloudflare zone.
     */
    deleteCloudflareFirewallRule(domainId: string, ruleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Get redirect rules for a domain's linked Cloudflare zone.
     */
    getCloudflareRedirectsForDomain(domainId: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        zoneId: string;
        ruleId: string | null;
        sourcePattern: string;
        destinationUrl: string;
        redirectType: "301" | "302" | null;
    }[]>;
    /**
     * Create a redirect rule for a domain's linked Cloudflare zone.
     */
    createCloudflareRedirectRule(domainId: string, data: {
        sourcePattern: string;
        destinationUrl: string;
        redirectType: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        ruleId: string;
        sourcePattern: string;
        destinationUrl: string;
        redirectType: string;
    }>;
    /**
     * Delete a redirect rule from a domain's linked Cloudflare zone.
     */
    deleteCloudflareRedirectRule(domainId: string, ruleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Create a tunnel route for a domain (Make Public action).
     * Uses the existing autoCreateTunnelRoute logic.
     */
    createCloudflareTunnelRoute(domainId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        domainId: string | null;
        tunnelId: string;
        hostname: string;
        service: string;
        noTlsVerify: boolean | null;
    }>;
    /**
     * Make a domain public — auto-creates tunnel route + CNAME + SSL.
     * This is the manual equivalent of the auto-magic that happens during domain creation
     * when makePublic=true.
     */
    makeDomainPublic(domainId: string, preferredTunnelId?: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        domainId: string | null;
        tunnelId: string;
        hostname: string;
        service: string;
        noTlsVerify: boolean | null;
    }>;
    /**
     * Delete the tunnel route for a domain (Make Private action).
     */
    deleteCloudflareTunnelRoute(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
}
export {};
//# sourceMappingURL=domains.service.d.ts.map