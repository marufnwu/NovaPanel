export declare class SchedulerService {
    private statsService;
    private sslService;
    private backupService;
    private tasks;
    /**
     * Get the single admin user ID for system notifications
     */
    private getAdminUserId;
    start(): void;
    stop(): void;
}
//# sourceMappingURL=scheduler.d.ts.map