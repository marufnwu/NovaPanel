interface CloudflareZone {
    id: string;
    name: string;
    status: string;
}
/**
 * Enhanced tunnel status with connectivity information
 */
export interface TunnelStatus {
    status: 'active' | 'inactive' | 'degraded' | 'down';
    processRunning: boolean;
    connectedToEdge: boolean;
    connectionCount: number;
    lastConnectedAt: string | null;
    message?: string;
    tunnels: Array<{
        id: string;
        tunnelId: string;
        name: string;
        status: 'active' | 'inactive' | 'degraded' | 'down';
        accountId?: string;
        zoneId?: string;
    }>;
}
export declare class TunnelService {
    /**
     * Full tunnel setup using Cloudflare API-based (remote config) approach.
     *
     * This replaces the old CLI-based approach with:
     * 1. POST /accounts/{id}/cfd_tunnel to create tunnel via API
     * 2. Store tunnelToken (not credentials file) for service installation
     * 3. cloudflared service install with tunnel token (no config file needed)
     *
     * Route configuration is stored remotely on Cloudflare's side and updated via API.
     */
    setup(name: string, apiToken: string, accountId?: string, zoneId?: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        tunnelId: any;
        accountId: string;
        zoneId: string | null;
        status: string;
    }>;
    /**
     * Get list of Cloudflare accounts for a token
     */
    private getAccounts;
    /**
     * Validate Cloudflare API Token
     *
     * Handles both token types:
     * - User tokens (cfut_ prefix): Use /user/tokens/verify endpoint
     * - Account tokens (cfat_ prefix): Verify via account-scoped API call
     */
    validateToken(apiToken: string): Promise<{
        valid: boolean;
        status: any;
        type: string;
    }>;
    private validateUserToken;
    private validateAccountToken;
    /**
     * Fetch Cloudflare zones for an account
     */
    fetchZones(apiToken: string, accountId?: string): Promise<CloudflareZone[]>;
    /**
     * Get detailed tunnel information via Cloudflare API
     */
    getTunnelInfo(tunnelDbId: string): Promise<{
        id: string;
        name: string;
        status: "error" | "active" | "inactive" | null;
        connections: never[];
        createdAt?: undefined;
    } | {
        id: any;
        name: any;
        status: "active" | "inactive" | "degraded" | "down";
        connections: any;
        createdAt: any;
    }>;
    /**
     * Delete a tunnel using Cloudflare API
     */
    deleteTunnel(tunnelDbId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get tunnel configuration as JSON (for display/debugging)
     * With remote config, there's no local config.yml - we return the remote config
     */
    getTunnelConfig(tunnelDbId: string): Promise<{
        tunnel: string | null;
        accountId: string | null;
        ingress: {
            hostname: string;
            service: string;
            originRequest: {
                noTLSVerify: boolean;
            } | undefined;
        }[];
        catchAll: {
            service: string;
        };
        source?: undefined;
    } | {
        tunnel: string | null;
        accountId: string | null;
        ingress: any;
        catchAll: any;
        source: string;
    }>;
    /**
     * Get tunnel status with enhanced connectivity information
     * Uses Cloudflare API for health information
     */
    getStatus(): Promise<TunnelStatus>;
    /**
     * Start tunnel
     */
    start(userId?: string, ipAddress?: string): Promise<{
        status: string;
    }>;
    /**
     * Stop tunnel
     */
    stop(userId?: string, ipAddress?: string): Promise<{
        status: string;
    }>;
    /**
     * List tunnel routes
     * Auto-syncs from Cloudflare remote config if no local routes exist
     */
    listRoutes(tunnelDbId?: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        domainId: string | null;
        tunnelId: string;
        hostname: string;
        service: string;
        noTlsVerify: boolean | null;
    }[]>;
    /**
     * Sync remote tunnel routes from Cloudflare API into local DB.
     * Fetches the current ingress rules from Cloudflare and creates
     * local DB records for any routes that don't already exist locally.
     */
    syncRemoteRoutes(tunnelDbId: string, userId?: string, ipAddress?: string): Promise<{
        synced: number;
        stale: number;
        totalRemote: number;
        totalLocal: number;
        newRoutes: never[];
        staleRoutes: never[];
        source: string;
        message: string;
    } | {
        synced: number;
        stale: number;
        totalRemote: number;
        totalLocal: number;
        newRoutes: {
            id: string;
            hostname: string;
            service: string;
        }[];
        staleRoutes: {
            id: string;
            hostname: string;
            service: string;
        }[];
        source?: undefined;
        message?: undefined;
    }>;
    /**
     * Add a tunnel route
     * Uses remote config API - no service reload needed!
     */
    addRoute(data: {
        tunnelId: string;
        hostname: string;
        service: string;
        noTlsVerify?: boolean;
        domainId?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        hostname: string;
        service: string;
        noTlsVerify: boolean;
    }>;
    /**
     * Edit a tunnel route
     */
    editRoute(routeId: string, data: {
        hostname?: string;
        service?: string;
        noTlsVerify?: boolean;
    }, userId?: string, ipAddress?: string): Promise<any>;
    /**
     * Delete a tunnel route
     */
    deleteRoute(routeId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Toggle a route active/inactive
     */
    toggleRoute(routeId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        isActive: boolean;
    }>;
    /**
     * Update tunnel ingress configuration via Cloudflare API (remote config)
     * This replaces the old writeConfigFile + reloadDaemon approach
     *
     * Key benefit: NO service reload needed! cloudflared picks up config automatically
     */
    private updateRemoteConfig;
    private createDnsCname;
    /**
     * Validate that a hostname's root domain is an active Cloudflare zone.
     */
    private validateHostnameZone;
    /**
     * Delete a DNS CNAME record for a tunnel route via Cloudflare API.
     */
    private deleteDnsCname;
    /**
     * Update PANEL_URL in .env file if the current URL is a private IP
     * and a tunnel route is being added for the panel domain.
     */
    private updatePanelUrlIfNeeded;
    /**
     * Create a DNS CNAME record via Cloudflare API (public endpoint)
     */
    createPublicDnsCname(zoneId: string, hostname: string, target: string): Promise<{
        success: boolean;
        record: any;
    }>;
}
export {};
//# sourceMappingURL=tunnel.service.d.ts.map