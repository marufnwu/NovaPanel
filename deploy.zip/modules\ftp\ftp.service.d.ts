export declare class FtpService {
    listAccounts(domainId: string): Promise<{
        id: string;
        username: string;
        passwordHash: string;
        isActive: boolean | null;
        lastLoginAt: Date | null;
        createdAt: Date;
        homeDir: string;
        websiteId: string | null;
        domainId: string;
        readonly: boolean | null;
        lastLoginIp: string | null;
    }[]>;
    getAccount(ftpId: string): Promise<{
        id: string;
        username: string;
        passwordHash: string;
        isActive: boolean | null;
        lastLoginAt: Date | null;
        createdAt: Date;
        homeDir: string;
        websiteId: string | null;
        domainId: string;
        readonly: boolean | null;
        lastLoginIp: string | null;
    }>;
    createAccount(domainId: string, data: {
        username: string;
        password: string;
        homeDir: string;
        readonly?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        username: string;
        homeDir: string;
        readonly: boolean;
    }>;
    updateAccount(ftpId: string, data: {
        password?: string;
        homeDir?: string;
        readonly?: boolean;
        isActive?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
    }>;
    updatePassword(ftpId: string, newPassword: string, userId?: string, ipAddress?: string): Promise<void>;
    deleteAccount(ftpId: string, userId?: string, ipAddress?: string): Promise<void>;
    getSettings(): Promise<{
        port: number;
        passivePortMin: number;
        passivePortMax: number;
        maxConnectionsPerIp: number;
        anonymousEnabled: boolean;
    }>;
    updateSettings(data: {
        port?: number;
        passivePortMin?: number;
        passivePortMax?: number;
        maxConnectionsPerIp?: number;
        anonymousEnabled?: boolean;
    }): Promise<{
        port: number;
        passivePortMin: number;
        passivePortMax: number;
        maxConnectionsPerIp: number;
        anonymousEnabled: boolean;
    }>;
    /**
     * List FTP accounts by websiteId
     */
    listByWebsite(websiteId: string): Promise<{
        id: string;
        username: string;
        passwordHash: string;
        isActive: boolean | null;
        lastLoginAt: Date | null;
        createdAt: Date;
        homeDir: string;
        websiteId: string | null;
        domainId: string;
        readonly: boolean | null;
        lastLoginIp: string | null;
    }[]>;
}
//# sourceMappingURL=ftp.service.d.ts.map