import type { SystemService, ServiceInfo } from './types.js';
export declare class PhpFpmService implements SystemService {
    private version;
    constructor(version: string);
    readonly name: string;
    readonly displayName: string;
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    /**
     * Get all installed PHP-FPM versions by scanning /etc/php/ directory.
     * Falls back to checking known versions via `which` if directory scan fails.
     */
    static getInstalledVersions(): Promise<string[]>;
    /**
     * Generate a PHP-FPM pool configuration for an entire website.
     * Pool name: `website-{websiteId}`
     * Config path: `/etc/php/{version}/fpm/pool.d/website-{websiteId}.conf`
     */
    static generateWebsitePool(websiteId: string): Promise<void>;
    /**
     * Remove the PHP-FPM pool configuration for a website.
     * If the website still exists in DB, uses its phpVersion to locate the file.
     * Otherwise, attempts removal across all known PHP versions.
     */
    static removeWebsitePool(websiteId: string): Promise<void>;
    /**
     * Reload a specific PHP-FPM version via systemctl.
     */
    static reloadPhpFpm(phpVersion: string): Promise<void>;
    /**
     * Get the pool config directory for this PHP version
     */
    private getPoolDir;
    /**
     * @deprecated Use PhpFpmService.generateWebsitePool() instead.
     * Create a per-domain PHP-FPM pool configuration
     */
    createPool(domain: string, systemUser: string, documentRoot: string): Promise<void>;
    /**
     * @deprecated Use PhpFpmService.removeWebsitePool() instead.
     * Delete a per-domain PHP-FPM pool configuration
     */
    deletePool(domain: string): Promise<void>;
}
export declare const phpFpmServices: {
    '8.1': PhpFpmService;
    '8.2': PhpFpmService;
    '8.3': PhpFpmService;
    '8.4': PhpFpmService;
};
//# sourceMappingURL=php-fpm.service.d.ts.map