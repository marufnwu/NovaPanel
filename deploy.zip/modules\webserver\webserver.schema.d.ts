import { z } from 'zod';
export declare const updateWebServerSchema: z.ZodObject<{
    webServer: z.ZodOptional<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
    gzipEnabled: z.ZodOptional<z.ZodBoolean>;
    browserCachingEnabled: z.ZodOptional<z.ZodBoolean>;
    staticFileExpiryDays: z.ZodOptional<z.ZodNumber>;
    hotlinkProtection: z.ZodOptional<z.ZodBoolean>;
    hotlinkAllowedDomains: z.ZodOptional<z.ZodString>;
    directoryBrowsing: z.ZodOptional<z.ZodBoolean>;
    ipRestrictionMode: z.ZodOptional<z.ZodEnum<["allow_all", "whitelist", "blacklist"]>>;
    ipList: z.ZodOptional<z.ZodString>;
    reverseProxyEnabled: z.ZodOptional<z.ZodBoolean>;
    reverseProxyTarget: z.ZodOptional<z.ZodString>;
    maxUploadSizeMb: z.ZodOptional<z.ZodNumber>;
    customNginxDirectives: z.ZodOptional<z.ZodString>;
    customApacheDirectives: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    hotlinkProtection?: boolean | undefined;
    gzipEnabled?: boolean | undefined;
    browserCachingEnabled?: boolean | undefined;
    staticFileExpiryDays?: number | undefined;
    hotlinkAllowedDomains?: string | undefined;
    directoryBrowsing?: boolean | undefined;
    ipRestrictionMode?: "whitelist" | "allow_all" | "blacklist" | undefined;
    ipList?: string | undefined;
    reverseProxyEnabled?: boolean | undefined;
    reverseProxyTarget?: string | undefined;
    maxUploadSizeMb?: number | undefined;
    customNginxDirectives?: string | undefined;
    customApacheDirectives?: string | undefined;
}, {
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    hotlinkProtection?: boolean | undefined;
    gzipEnabled?: boolean | undefined;
    browserCachingEnabled?: boolean | undefined;
    staticFileExpiryDays?: number | undefined;
    hotlinkAllowedDomains?: string | undefined;
    directoryBrowsing?: boolean | undefined;
    ipRestrictionMode?: "whitelist" | "allow_all" | "blacklist" | undefined;
    ipList?: string | undefined;
    reverseProxyEnabled?: boolean | undefined;
    reverseProxyTarget?: string | undefined;
    maxUploadSizeMb?: number | undefined;
    customNginxDirectives?: string | undefined;
    customApacheDirectives?: string | undefined;
}>;
export declare const updateErrorPagesSchema: z.ZodObject<{
    errorPages: z.ZodArray<z.ZodObject<{
        code: z.ZodNumber;
        enabled: z.ZodDefault<z.ZodBoolean>;
        content: z.ZodString;
        contentType: z.ZodDefault<z.ZodEnum<["text/html", "text/plain", "application/json"]>>;
    }, "strip", z.ZodTypeAny, {
        code: number;
        content: string;
        enabled: boolean;
        contentType: "text/html" | "application/json" | "text/plain";
    }, {
        code: number;
        content: string;
        enabled?: boolean | undefined;
        contentType?: "text/html" | "application/json" | "text/plain" | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    errorPages: {
        code: number;
        content: string;
        enabled: boolean;
        contentType: "text/html" | "application/json" | "text/plain";
    }[];
}, {
    errorPages: {
        code: number;
        content: string;
        enabled?: boolean | undefined;
        contentType?: "text/html" | "application/json" | "text/plain" | undefined;
    }[];
}>;
export declare const updateRateLimitSchema: z.ZodObject<{
    enabled: z.ZodOptional<z.ZodBoolean>;
    requestsPerSecond: z.ZodOptional<z.ZodNumber>;
    burstSize: z.ZodOptional<z.ZodNumber>;
    timeoutSeconds: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    enabled?: boolean | undefined;
    requestsPerSecond?: number | undefined;
    burstSize?: number | undefined;
    timeoutSeconds?: number | undefined;
}, {
    enabled?: boolean | undefined;
    requestsPerSecond?: number | undefined;
    burstSize?: number | undefined;
    timeoutSeconds?: number | undefined;
}>;
//# sourceMappingURL=webserver.schema.d.ts.map