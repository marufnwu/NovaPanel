import { z } from 'zod';
export declare const createFtpAccountSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    homeDir: z.ZodString;
    readonly: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    username: string;
    homeDir: string;
    readonly: boolean;
    password: string;
}, {
    username: string;
    homeDir: string;
    password: string;
    readonly?: boolean | undefined;
}>;
export declare const updateFtpAccountSchema: z.ZodObject<{
    password: z.ZodOptional<z.ZodString>;
    homeDir: z.ZodOptional<z.ZodString>;
    readonly: z.ZodOptional<z.ZodBoolean>;
    isActive: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    isActive?: boolean | undefined;
    homeDir?: string | undefined;
    readonly?: boolean | undefined;
    password?: string | undefined;
}, {
    isActive?: boolean | undefined;
    homeDir?: string | undefined;
    readonly?: boolean | undefined;
    password?: string | undefined;
}>;
//# sourceMappingURL=ftp.schema.d.ts.map