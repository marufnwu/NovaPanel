import { db } from '../../db/index.js';
import { metrics, alertRules, alertHistory } from '../../db/schema/monitoring.js';
import { eq, and, desc } from 'drizzle-orm';
import { nanoid } from 'nanoid';
import * as si from 'systeminformation';
import { hostname as getHostname } from 'node:os';
import { logger } from '../../config/logger.js';
export class MonitoringService {
    async recordMetric(name, value, labels) {
        const metric = {
            id: nanoid(),
            name,
            value,
            labels: labels ?? {},
            timestamp: new Date(),
        };
        await db.insert(metrics).values(metric);
    }
    async getMetrics(filters = {}) {
        const conditions = [];
        if (filters.name)
            conditions.push(eq(metrics.name, filters.name));
        if (filters.from || filters.to) {
            conditions.push(and(filters.from ? eq(metrics.timestamp, filters.from) : undefined, filters.to ? eq(metrics.timestamp, filters.to) : undefined));
        }
        const where = conditions.length > 0 ? and(...conditions) : undefined;
        const items = await db.select().from(metrics).where(where).orderBy(desc(metrics.timestamp)).limit(filters.limit ?? 100);
        return items;
    }
    async collectSystemMetrics() {
        try {
            const [cpu, mem, disk, network] = await Promise.all([
                si.currentLoad(),
                si.mem(),
                si.fsSize(),
                si.networkStats(),
            ]);
            const rootDisk = disk.find((d) => d.mount === '/') || disk[0];
            const defaultNet = network.find((n) => n.iface !== 'lo') || network[0];
            await this.recordMetric('cpu_usage_percent', Math.round(cpu.currentLoad), { host: getHostname() });
            await this.recordMetric('memory_usage_percent', Math.round((mem.used / mem.total) * 100), { host: getHostname() });
            await this.recordMetric('disk_usage_percent', Math.round(rootDisk?.use || 0), { mount: rootDisk?.mount || '/' });
            await this.recordMetric('network_rx_sec', Math.round(defaultNet?.rx_sec || 0), { iface: defaultNet?.iface || 'unknown' });
            await this.recordMetric('network_tx_sec', Math.round(defaultNet?.tx_sec || 0), { iface: defaultNet?.iface || 'unknown' });
        }
        catch (err) {
            logger.error({ err }, 'Failed to collect system metrics');
        }
    }
    async listAlertRules(orgId) {
        return db.select().from(alertRules).where(eq(alertRules.orgId, orgId)).orderBy(desc(alertRules.createdAt));
    }
    async createAlertRule(data) {
        const rule = {
            id: nanoid(),
            ...data,
            createdAt: new Date(),
        };
        await db.insert(alertRules).values(rule);
        const [created] = await db.select().from(alertRules).where(eq(alertRules.id, rule.id)).limit(1);
        return created;
    }
    async updateAlertRule(id, data) {
        await db.update(alertRules).set({ ...data, updatedAt: new Date() }).where(eq(alertRules.id, id));
        const [updated] = await db.select().from(alertRules).where(eq(alertRules.id, id)).limit(1);
        if (!updated)
            throw new Error('Alert rule not found');
        return updated;
    }
    async deleteAlertRule(id) {
        await db.delete(alertRules).where(eq(alertRules.id, id));
    }
    async evaluateAlertRules() {
        const rules = await db.select().from(alertRules).where(eq(alertRules.enabled, true));
        const recentMetrics = await db.select().from(metrics).orderBy(desc(metrics.timestamp)).limit(100);
        for (const rule of rules) {
            const metricData = recentMetrics.filter(m => m.name === rule.metric);
            if (metricData.length === 0)
                continue;
            const latest = metricData[0];
            const triggered = this.checkCondition(latest.value, rule.condition, rule.threshold);
            if (triggered) {
                await this.triggerAlert(rule, latest.value);
            }
        }
    }
    checkCondition(value, condition, threshold) {
        switch (condition) {
            case 'gt': return value > threshold;
            case 'lt': return value < threshold;
            case 'gte': return value >= threshold;
            case 'lte': return value <= threshold;
            case 'eq': return value === threshold;
            default: return false;
        }
    }
    async triggerAlert(rule, value) {
        const history = {
            id: nanoid(),
            ruleId: rule.id,
            triggeredAt: new Date(),
            value,
            message: `Alert "${rule.name}" triggered: ${rule.metric} ${rule.condition} ${rule.threshold} (current: ${value})`,
        };
        await db.insert(alertHistory).values(history);
        logger.info({ ruleId: rule.id, value }, 'Alert triggered');
    }
    async getAlertHistory(ruleId, limit = 50) {
        return db.select().from(alertHistory).where(eq(alertHistory.ruleId, ruleId)).orderBy(desc(alertHistory.triggeredAt)).limit(limit);
    }
    async listAlertHistory(orgId, limit = 100) {
        const rules = await db.select().from(alertRules).where(eq(alertRules.orgId, orgId));
        const ruleIds = rules.map(r => r.id);
        const history = await db.select().from(alertHistory).orderBy(desc(alertHistory.triggeredAt)).limit(limit);
        return history.map(h => ({
            ...h,
            ruleName: rules.find(r => r.id === h.ruleId)?.name || 'Unknown',
        }));
    }
}
export const monitoringService = new MonitoringService();
//# sourceMappingURL=monitoring.service.js.map