import { db } from '../../db/index.js';
import { wafRules, ipAllowlists } from '../../db/schema/security.js';
import { eq } from 'drizzle-orm';
import { nanoid } from 'nanoid';
export class SecurityService {
    async listWafRules(projectId) {
        return db.select().from(wafRules).where(eq(wafRules.projectId, projectId)).orderBy(wafRules.priority);
    }
    async createWafRule(projectId, data) {
        const rule = {
            id: nanoid(),
            projectId,
            name: data.name,
            type: data.type,
            enabled: data.enabled ?? true,
            priority: data.priority ?? 100,
            config: data.config ?? {},
            createdAt: new Date(),
        };
        await db.insert(wafRules).values(rule);
        const [created] = await db.select().from(wafRules).where(eq(wafRules.id, rule.id)).limit(1);
        return created;
    }
    async updateWafRule(id, data) {
        await db.update(wafRules).set({ ...data, updatedAt: new Date() }).where(eq(wafRules.id, id));
        const [updated] = await db.select().from(wafRules).where(eq(wafRules.id, id)).limit(1);
        if (!updated)
            throw new Error('WAF rule not found');
        return updated;
    }
    async deleteWafRule(id) {
        await db.delete(wafRules).where(eq(wafRules.id, id));
    }
    async listIpAllowlists(projectId) {
        return db.select().from(ipAllowlists).where(eq(ipAllowlists.projectId, projectId)).orderBy(ipAllowlists.createdAt);
    }
    async createIpAllowlist(projectId, data) {
        const allowlist = {
            id: nanoid(),
            projectId,
            name: data.name,
            ips: data.ips ?? [],
            type: data.type,
            createdAt: new Date(),
        };
        await db.insert(ipAllowlists).values(allowlist);
        const [created] = await db.select().from(ipAllowlists).where(eq(ipAllowlists.id, allowlist.id)).limit(1);
        return created;
    }
    async updateIpAllowlist(id, data) {
        await db.update(ipAllowlists).set({ ...data, updatedAt: new Date() }).where(eq(ipAllowlists.id, id));
        const [updated] = await db.select().from(ipAllowlists).where(eq(ipAllowlists.id, id)).limit(1);
        if (!updated)
            throw new Error('IP allowlist not found');
        return updated;
    }
    async deleteIpAllowlist(id) {
        await db.delete(ipAllowlists).where(eq(ipAllowlists.id, id));
    }
}
export const securityService = new SecurityService();
//# sourceMappingURL=security.service.js.map