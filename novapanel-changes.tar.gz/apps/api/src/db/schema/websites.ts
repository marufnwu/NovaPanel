import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';

/**
 * @deprecated Use `sites` table instead (v4 architecture).
 *
 * This table is kept for backward compatibility during migration.
 * All new code should use `sites` from sites.ts.
 *
 * When migration is complete:
 * 1. Ensure all data has been migrated to `sites`
 * 2. Drop this `websites` table via migration
 * 3. Delete this file
 */
export const websites = sqliteTable('websites', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  systemUser: text('system_user').notNull().unique(),
  homeDir: text('home_dir').notNull(),
  documentRoot: text('document_root').notNull(),
  phpVersion: text('php_version').default('8.2').notNull(),
  phpHandler: text('php_handler', { enum: ['php-fpm', 'cgi', 'disabled'] }).default('php-fpm').notNull(),
  webServer: text('web_server', { enum: ['nginx', 'apache', 'nginx+apache'] }).default('nginx+apache').notNull(),
  status: text('status', { enum: ['active', 'suspended'] }).default('active').notNull(),
  diskUsedMb: integer('disk_used_mb').default(0).notNull(),
  bandwidthUsedMb: integer('bandwidth_used_mb').default(0).notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().default(sql`(unixepoch())`),
});

/** @deprecated Use Site from sites.ts */
export type Website = typeof websites.$inferSelect;
