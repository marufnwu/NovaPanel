export interface UfwRule {
    number: number;
    rule: string;
    action: string;
    direction: string;
    from: string;
}
export interface F2BJail {
    name: string;
    bannedCount: number;
    bannedIps: string[];
}
export interface FirewallStatus {
    enabled: boolean;
    defaultInput: string;
    defaultOutput: string;
    defaultForward: string;
}
export declare class FirewallService {
    getStatus(retries?: number): Promise<FirewallStatus>;
    enable(userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    disable(userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    listRules(): Promise<UfwRule[]>;
    addRule(rule: {
        action: 'allow' | 'deny';
        port?: string;
        protocol?: string;
        from?: string;
        to?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        output: string;
    }>;
    deleteRule(ruleNumber: number, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    applyPreset(preset: 'ssh' | 'http' | 'https' | 'ftp' | 'smtp' | 'imap', userId?: string, ipAddress?: string): Promise<{
        preset: "ftp" | "http" | "https" | "ssh" | "smtp" | "imap";
        results: {
            port: string;
            success: boolean;
        }[];
    }>;
    listJails(): Promise<F2BJail[]>;
    unbanIp(jail: string, ip: string, userId?: string, userIpAddress?: string): Promise<{
        success: boolean;
    }>;
    banIp(jail: string, ip: string, userId?: string, userIpAddress?: string): Promise<{
        success: boolean;
    }>;
    resetRules(): Promise<{
        success: boolean;
    }>;
    toggleRule(ruleNumber: number, enabled: boolean): Promise<{
        success: boolean;
    }>;
    /**
     * Extract default policy from UFW verbose output.
     * Handles both formats:
     *   New: "Default: deny (incoming), allow (outgoing), disabled (routed)"
     *   Old: "Default input policy: deny"
     */
    private extractDefaultPolicy;
    private parseUfwStatus;
}
//# sourceMappingURL=firewall.service.d.ts.map