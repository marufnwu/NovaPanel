import { db } from '../../db/index.js';
import { cronJobs, cronJobHistory } from '../../db/schema/cron.js';
import { eq, desc } from 'drizzle-orm';
import { nanoid } from 'nanoid';
import { run } from '../../services/executor.js';
import { AppError } from '../../errors.js';
import { logger } from '../../config/logger.js';
import { auditService } from '../audit/audit.service.js';
export class CronService {
    /**
     * List all cron jobs
     */
    async listJobs(_domainId) {
        // For single-admin mode, list all cron jobs
        // In original multi-tenant mode, this would filter by subscription
        return db.select().from(cronJobs);
    }
    /**
     * Get a single cron job by ID
     */
    async getJob(jobId) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        return job;
    }
    /**
     * Create a cron job
     */
    async createJob(data, userId, ipAddress) {
        const parts = data.schedule.trim().split(/\s+/);
        if (parts.length !== 5) {
            throw new AppError(400, 'INVALID_CRON', 'Cron expression must have 5 fields: min hour day month weekday');
        }
        // In single-admin mode, use provided systemUser or default to root
        const sysUser = data.systemUser || 'root';
        const jobId = nanoid();
        const cronLine = `${data.schedule} ${data.command} # serverforge:${jobId}\n`;
        const result = await run('crontab', ['-u', sysUser, '-l'], { sudo: true });
        const existing = result.success ? result.stdout : '';
        await run('crontab', ['-u', sysUser, '-'], {
            sudo: true,
            input: existing + cronLine,
        });
        await db.insert(cronJobs).values({
            id: jobId,
            domainId: data.domainId || null,
            websiteId: data.websiteId || null,
            command: data.command,
            schedule: data.schedule,
            systemUser: sysUser,
            isActive: true,
        });
        logger.info({ jobId, command: data.command, schedule: data.schedule }, 'Cron job created');
        auditService.log({
            userId,
            action: 'cron.job.create',
            resource: `cron:${jobId}`,
            details: JSON.stringify({ command: data.command, schedule: data.schedule }),
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return { id: jobId, command: data.command, schedule: data.schedule, systemUser: sysUser };
    }
    /**
     * Update a cron job
     */
    async updateJob(jobId, data, userId, ipAddress) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        // Remove old entry
        const result = await run('crontab', ['-u', job.systemUser, '-l'], { sudo: true });
        if (result.success) {
            const updated = result.stdout
                .split('\n')
                .filter(line => !line.includes(`serverforge:${jobId}`))
                .join('\n');
            await run('crontab', ['-u', job.systemUser, '-'], { sudo: true, input: updated });
        }
        const newSchedule = data.schedule || job.schedule;
        const newCommand = data.command || job.command;
        const newUser = data.systemUser || job.systemUser;
        // Add new entry
        const cronLine = `${newSchedule} ${newCommand} # serverforge:${jobId}\n`;
        const result2 = await run('crontab', ['-u', newUser, '-l'], { sudo: true });
        const existing = result2.success ? result2.stdout : '';
        await run('crontab', ['-u', newUser, '-'], {
            sudo: true,
            input: existing + cronLine,
        });
        await db.update(cronJobs).set({
            schedule: newSchedule,
            command: newCommand,
            systemUser: newUser,
        }).where(eq(cronJobs.id, jobId));
        logger.info({ jobId }, 'Cron job updated');
        auditService.log({
            userId,
            action: 'cron.job.update',
            resource: `cron:${jobId}`,
            details: JSON.stringify({ schedule: newSchedule, command: newCommand }),
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return { id: jobId, schedule: newSchedule, command: newCommand, systemUser: newUser };
    }
    /**
     * Delete a cron job
     */
    async deleteJob(jobId, userId, ipAddress) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        const result = await run('crontab', ['-u', job.systemUser, '-l'], { sudo: true });
        if (result.success) {
            const updated = result.stdout
                .split('\n')
                .filter(line => !line.includes(`serverforge:${jobId}`))
                .join('\n');
            await run('crontab', ['-u', job.systemUser, '-'], { sudo: true, input: updated });
        }
        await db.delete(cronJobs).where(eq(cronJobs.id, jobId));
        logger.info({ jobId }, 'Cron job deleted');
        auditService.log({
            userId,
            action: 'cron.job.delete',
            resource: `cron:${jobId}`,
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
    }
    /**
     * Toggle a cron job on/off
     */
    async toggleJob(jobId, userId, ipAddress) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        const newActive = !job.isActive;
        if (newActive) {
            const cronLine = `${job.schedule} ${job.command} # serverforge:${jobId}\n`;
            const result = await run('crontab', ['-u', job.systemUser, '-l'], { sudo: true });
            const existing = result.success ? result.stdout : '';
            await run('crontab', ['-u', job.systemUser, '-'], {
                sudo: true,
                input: existing + cronLine,
            });
        }
        else {
            const result = await run('crontab', ['-u', job.systemUser, '-l'], { sudo: true });
            if (result.success) {
                const updated = result.stdout
                    .split('\n')
                    .filter(line => !line.includes(`serverforge:${jobId}`))
                    .join('\n');
                await run('crontab', ['-u', job.systemUser, '-'], { sudo: true, input: updated });
            }
        }
        await db.update(cronJobs).set({ isActive: newActive }).where(eq(cronJobs.id, jobId));
        auditService.log({
            userId,
            action: 'cron.job.toggle',
            resource: `cron:${jobId}`,
            details: JSON.stringify({ isActive: newActive }),
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return { id: jobId, isActive: newActive };
    }
    /**
     * Run a cron job immediately
     */
    async runJob(jobId, userId, ipAddress) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        const startTime = new Date();
        const historyId = nanoid();
        // Mark as running
        await db.update(cronJobs).set({
            lastRun: startTime,
            lastStatus: 'running',
        }).where(eq(cronJobs.id, jobId));
        // Create history entry with start time
        await db.insert(cronJobHistory).values({
            id: historyId,
            jobId: jobId,
            startTime: startTime,
        });
        const result = await run('su', ['-c', job.command, job.systemUser], { sudo: true, timeout: 60_000 });
        const endTime = new Date();
        const durationMs = endTime.getTime() - startTime.getTime();
        // Update job with final status
        await db.update(cronJobs).set({
            lastRun: endTime,
            lastStatus: result.success ? 'success' : 'failed',
        }).where(eq(cronJobs.id, jobId));
        // Update history entry with final details
        await db.update(cronJobHistory).set({
            endTime: endTime,
            durationMs: durationMs,
            exitCode: result.exitCode ?? 0,
            outputPreview: result.stdout?.substring(0, 1000) || '',
            errorPreview: result.stderr?.substring(0, 500) || '',
        }).where(eq(cronJobHistory.id, historyId));
        auditService.log({
            userId,
            action: 'cron.job.run',
            resource: `cron:${jobId}`,
            details: JSON.stringify({ exitCode: result.exitCode, success: result.success }),
            ipAddress,
        }).catch(err => logger.error({ err }, 'Audit log failed'));
        return { exitCode: result.exitCode, stdout: result.stdout, stderr: result.stderr };
    }
    /**
     * Get cron job execution history
     */
    async getJobHistory(jobId, limit = 50) {
        const [job] = await db.select().from(cronJobs).where(eq(cronJobs.id, jobId)).limit(1);
        if (!job)
            throw new AppError(404, 'CRON_NOT_FOUND', 'Cron job not found');
        const history = await db.select().from(cronJobHistory)
            .where(eq(cronJobHistory.jobId, jobId))
            .orderBy(desc(cronJobHistory.startTime))
            .limit(limit);
        return history.map(h => ({
            id: h.id,
            jobId: h.jobId,
            startTime: h.startTime?.toISOString() || '',
            endTime: h.endTime?.toISOString() || null,
            durationMs: h.durationMs || null,
            exitCode: h.exitCode || null,
            outputPreview: h.outputPreview || null,
            errorPreview: h.errorPreview || null,
        }));
    }
    /**
     * List cron jobs by websiteId
     */
    async listByWebsite(websiteId) {
        return db.select().from(cronJobs).where(eq(cronJobs.websiteId, websiteId));
    }
}
//# sourceMappingURL=cron.service.js.map