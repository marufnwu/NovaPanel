export declare class CronService {
    /**
     * List all cron jobs
     */
    listJobs(_domainId?: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        systemUser: string;
        domainId: string | null;
        websiteId: string | null;
        command: string;
        schedule: string;
        lastRun: Date | null;
        lastStatus: "success" | "failed" | "running" | null;
    }[]>;
    /**
     * Get a single cron job by ID
     */
    getJob(jobId: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        systemUser: string;
        domainId: string | null;
        websiteId: string | null;
        command: string;
        schedule: string;
        lastRun: Date | null;
        lastStatus: "success" | "failed" | "running" | null;
    }>;
    /**
     * Create a cron job
     */
    createJob(data: {
        command: string;
        schedule: string;
        systemUser?: string;
        domainId?: string;
        websiteId?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        command: string;
        schedule: string;
        systemUser: string;
    }>;
    /**
     * Update a cron job
     */
    updateJob(jobId: string, data: {
        schedule?: string;
        command?: string;
        systemUser?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        schedule: string;
        command: string;
        systemUser: string;
    }>;
    /**
     * Delete a cron job
     */
    deleteJob(jobId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Toggle a cron job on/off
     */
    toggleJob(jobId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        isActive: boolean;
    }>;
    /**
     * Run a cron job immediately
     */
    runJob(jobId: string, userId?: string, ipAddress?: string): Promise<{
        exitCode: number;
        stdout: string;
        stderr: string;
    }>;
    /**
     * Get cron job execution history
     */
    getJobHistory(jobId: string, limit?: number): Promise<Array<{
        id: string;
        jobId: string;
        startTime: string;
        endTime: string | null;
        durationMs: number | null;
        exitCode: number | null;
        outputPreview: string | null;
        errorPreview: string | null;
    }>>;
    /**
     * List cron jobs by websiteId
     */
    listByWebsite(websiteId: string): Promise<{
        id: string;
        isActive: boolean | null;
        createdAt: Date;
        systemUser: string;
        domainId: string | null;
        websiteId: string | null;
        command: string;
        schedule: string;
        lastRun: Date | null;
        lastStatus: "success" | "failed" | "running" | null;
    }[]>;
}
//# sourceMappingURL=cron.service.d.ts.map