import { z } from 'zod';
export declare const createDomainSchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["primary", "addon", "parked", "subdomain", "redirect", "mail-only"]>>;
    siteId: z.ZodOptional<z.ZodString>;
    parentDomainId: z.ZodOptional<z.ZodString>;
    redirectTarget: z.ZodOptional<z.ZodString>;
    websiteMode: z.ZodDefault<z.ZodEnum<["none", "create", "existing"]>>;
    websiteName: z.ZodOptional<z.ZodString>;
    documentRoot: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
    phpHandler: z.ZodDefault<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodDefault<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
    createDns: z.ZodDefault<z.ZodBoolean>;
    createMail: z.ZodDefault<z.ZodBoolean>;
    makePublic: z.ZodDefault<z.ZodBoolean>;
    tunnelId: z.ZodOptional<z.ZodString>;
    skipDnsVerification: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    type: "primary" | "addon" | "parked" | "subdomain" | "redirect" | "mail-only";
    name: string;
    phpHandler: "php-fpm" | "cgi" | "disabled";
    webServer: "nginx" | "apache" | "nginx+apache";
    websiteMode: "create" | "none" | "existing";
    createDns: boolean;
    createMail: boolean;
    makePublic: boolean;
    skipDnsVerification: boolean;
    siteId?: string | undefined;
    parentDomainId?: string | undefined;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
    redirectTarget?: string | undefined;
    tunnelId?: string | undefined;
    websiteName?: string | undefined;
}, {
    name: string;
    type?: "primary" | "addon" | "parked" | "subdomain" | "redirect" | "mail-only" | undefined;
    siteId?: string | undefined;
    parentDomainId?: string | undefined;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    redirectTarget?: string | undefined;
    tunnelId?: string | undefined;
    websiteMode?: "create" | "none" | "existing" | undefined;
    websiteName?: string | undefined;
    createDns?: boolean | undefined;
    createMail?: boolean | undefined;
    makePublic?: boolean | undefined;
    skipDnsVerification?: boolean | undefined;
}>;
export declare const verifyDomainDnsSchema: z.ZodObject<{
    domain: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domain: string;
}, {
    domain: string;
}>;
export declare const updateDomainSchema: z.ZodObject<{
    phpVersion: z.ZodOptional<z.ZodString>;
    phpHandler: z.ZodOptional<z.ZodEnum<["php-fpm", "cgi", "disabled"]>>;
    webServer: z.ZodOptional<z.ZodEnum<["nginx", "apache", "nginx+apache"]>>;
    redirectHttpToHttps: z.ZodOptional<z.ZodBoolean>;
    hsts: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
}, {
    phpVersion?: string | undefined;
    phpHandler?: "php-fpm" | "cgi" | "disabled" | undefined;
    webServer?: "nginx" | "apache" | "nginx+apache" | undefined;
    redirectHttpToHttps?: boolean | undefined;
    hsts?: boolean | undefined;
}>;
export declare const deleteDomainSchema: z.ZodObject<{
    deleteWebsite: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    deleteWebsite: boolean;
}, {
    deleteWebsite?: boolean | undefined;
}>;
export declare const createSubdomainSchema: z.ZodObject<{
    name: z.ZodString;
    documentRoot: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
}, {
    name: string;
    documentRoot?: string | undefined;
    phpVersion?: string | undefined;
}>;
export declare const createAliasSchema: z.ZodObject<{
    alias: z.ZodString;
}, "strip", z.ZodTypeAny, {
    alias: string;
}, {
    alias: string;
}>;
export declare const createRedirectSchema: z.ZodObject<{
    sourcePath: z.ZodString;
    targetUrl: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["301", "302"]>>;
}, "strip", z.ZodTypeAny, {
    type: "301" | "302";
    sourcePath: string;
    targetUrl: string;
}, {
    sourcePath: string;
    targetUrl: string;
    type?: "301" | "302" | undefined;
}>;
export type CreateDomainInput = z.infer<typeof createDomainSchema>;
export type UpdateDomainInput = z.infer<typeof updateDomainSchema>;
export type DeleteDomainInput = z.infer<typeof deleteDomainSchema>;
//# sourceMappingURL=domains.schema.d.ts.map