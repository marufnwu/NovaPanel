export declare class MailService {
    /**
     * Enable mail for a domain
     */
    enableMail(domainId: string, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
        mailDomainId: string;
    }>;
    /**
     * Disable mail for a domain
     */
    disableMail(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Create a mailbox
     */
    createMailbox(domainId: string, data: {
        username: string;
        password: string;
        quotaMb: number;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        email: string;
        quotaMb: number;
    }>;
    /**
     * Update a mailbox
     */
    updateMailbox(mailboxId: string, data: {
        password?: string;
        quotaMb?: number;
        isActive?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
    }>;
    /**
     * Delete a mailbox
     */
    deleteMailbox(mailboxId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List mailboxes for a domain
     */
    listMailboxes(domainId: string): Promise<{
        id: string;
        username: string;
        passwordHash: string;
        isActive: boolean | null;
        createdAt: Date;
        mailDomainId: string;
        quotaMb: number | null;
        usedMb: number | null;
        isSuspended: boolean | null;
        autoresponder: boolean | null;
        autoresponderMessage: string | null;
    }[]>;
    /**
     * Create an email alias
     */
    createAlias(domainId: string, alias: string, destination: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        alias: string;
        destination: string;
    }>;
    /**
     * Delete an email alias
     */
    deleteAlias(aliasId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List aliases for a domain
     */
    listAliases(domainId: string): Promise<{
        id: string;
        createdAt: Date;
        mailDomainId: string;
        alias: string;
        destination: string;
    }[]>;
    /**
     * Generate DKIM keys for a domain
     */
    generateDKIM(domainId: string, userId?: string, ipAddress?: string): Promise<{
        publicKey: string;
        dnsRecord: string;
    }>;
    /**
     * Get DKIM status
     */
    getDKIMStatus(domainId: string): Promise<{
        enabled: boolean;
        hasPublicKey?: undefined;
        spfRecord?: undefined;
        dmarcPolicy?: undefined;
    } | {
        enabled: boolean;
        hasPublicKey: boolean;
        spfRecord: string | null;
        dmarcPolicy: string | null;
    }>;
    /**
     * Set SPF record for a domain
     */
    setSPF(domainId: string, serverIp?: string, userId?: string, ipAddress?: string): Promise<{
        spfRecord: string;
    }>;
    /**
     * Set DMARC policy
     */
    setDMARC(domainId: string, policy: 'none' | 'quarantine' | 'reject', reportEmail?: string, userId?: string, ipAddress?: string): Promise<{
        policy: "none" | "reject" | "quarantine";
        dmarcRecord: string;
    }>;
    /**
     * Get full mail domain info including aliases
     */
    getMailDomainInfo(domainId: string): Promise<{
        enabled: boolean;
        mailDomain: null;
        mailboxes: never[];
        aliases: never[];
        forwards: never[];
    } | {
        enabled: boolean;
        mailDomain: {
            id: string;
            isActive: boolean | null;
            spfRecord: string | null;
            dmarcPolicy: string | null;
            hasDkimKey: boolean;
        };
        mailboxes: {
            id: string;
            email: string;
            quotaMb: number | null;
            usedMb: number | null;
            isActive: boolean | null;
            autoresponder: boolean | null;
            autoresponderMessage: string | null;
        }[];
        aliases: {
            id: string;
            alias: string;
            destination: string;
        }[];
        forwards: {
            id: string;
            fromMailbox: string;
            forwardTo: string;
            keepCopy: boolean | null;
        }[];
    }>;
    /**
     * Set catch-all destination for a domain
     */
    setCatchAll(domainId: string, destination: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Set SpamAssassin settings for a domain
     */
    setSpamAssassin(domainId: string, enabled: boolean, spamScoreThreshold?: number, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        enabled: boolean;
        spamScoreThreshold: number;
    }>;
}
//# sourceMappingURL=mail.service.d.ts.map