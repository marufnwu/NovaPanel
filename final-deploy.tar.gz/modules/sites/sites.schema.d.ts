import { z } from 'zod';
export declare const runtimeConfigSchema: z.ZodObject<{
    schemaVersion: z.ZodDefault<z.ZodNumber>;
    runtime: z.ZodEnum<["php", "node", "python", "static", "docker"]>;
    version: z.ZodOptional<z.ZodString>;
    buildCommand: z.ZodOptional<z.ZodString>;
    startCommand: z.ZodOptional<z.ZodString>;
    healthCheckPath: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
    nodeVersion: z.ZodOptional<z.ZodString>;
    pythonVersion: z.ZodOptional<z.ZodString>;
    venvPath: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    runtime: "php" | "node" | "python" | "static" | "docker";
    schemaVersion: number;
    phpVersion?: string | undefined;
    startCommand?: string | undefined;
    healthCheckPath?: string | undefined;
    version?: string | undefined;
    buildCommand?: string | undefined;
    nodeVersion?: string | undefined;
    pythonVersion?: string | undefined;
    venvPath?: string | undefined;
}, {
    runtime: "php" | "node" | "python" | "static" | "docker";
    phpVersion?: string | undefined;
    startCommand?: string | undefined;
    healthCheckPath?: string | undefined;
    version?: string | undefined;
    schemaVersion?: number | undefined;
    buildCommand?: string | undefined;
    nodeVersion?: string | undefined;
    pythonVersion?: string | undefined;
    venvPath?: string | undefined;
}>;
export declare const createSiteSchema: z.ZodObject<{
    name: z.ZodString;
    runtime: z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodNumber>;
        runtime: z.ZodEnum<["php", "node", "python", "static", "docker"]>;
        version: z.ZodOptional<z.ZodString>;
        buildCommand: z.ZodOptional<z.ZodString>;
        startCommand: z.ZodOptional<z.ZodString>;
        healthCheckPath: z.ZodOptional<z.ZodString>;
        phpVersion: z.ZodOptional<z.ZodString>;
        nodeVersion: z.ZodOptional<z.ZodString>;
        pythonVersion: z.ZodOptional<z.ZodString>;
        venvPath: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        runtime: "php" | "node" | "python" | "static" | "docker";
        schemaVersion: number;
        phpVersion?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
        version?: string | undefined;
        buildCommand?: string | undefined;
        nodeVersion?: string | undefined;
        pythonVersion?: string | undefined;
        venvPath?: string | undefined;
    }, {
        runtime: "php" | "node" | "python" | "static" | "docker";
        phpVersion?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
        version?: string | undefined;
        schemaVersion?: number | undefined;
        buildCommand?: string | undefined;
        nodeVersion?: string | undefined;
        pythonVersion?: string | undefined;
        venvPath?: string | undefined;
    }>;
    primaryDomain: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    runtime: {
        runtime: "php" | "node" | "python" | "static" | "docker";
        schemaVersion: number;
        phpVersion?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
        version?: string | undefined;
        buildCommand?: string | undefined;
        nodeVersion?: string | undefined;
        pythonVersion?: string | undefined;
        venvPath?: string | undefined;
    };
    primaryDomain?: string | undefined;
}, {
    name: string;
    runtime: {
        runtime: "php" | "node" | "python" | "static" | "docker";
        phpVersion?: string | undefined;
        startCommand?: string | undefined;
        healthCheckPath?: string | undefined;
        version?: string | undefined;
        schemaVersion?: number | undefined;
        buildCommand?: string | undefined;
        nodeVersion?: string | undefined;
        pythonVersion?: string | undefined;
        venvPath?: string | undefined;
    };
    primaryDomain?: string | undefined;
}>;
export declare const updateSiteSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
}, {
    name?: string | undefined;
}>;
export declare const attachDomainToSiteSchema: z.ZodObject<{
    domainId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domainId: string;
}, {
    domainId: string;
}>;
export declare const detachDomainFromSiteSchema: z.ZodObject<{
    domainId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domainId: string;
}, {
    domainId: string;
}>;
export type CreateSiteInput = z.infer<typeof createSiteSchema>;
export type UpdateSiteInput = z.infer<typeof updateSiteSchema>;
export type RuntimeConfig = z.infer<typeof runtimeConfigSchema>;
//# sourceMappingURL=sites.schema.d.ts.map