import { type Site } from '../../db/schema/index.js';
import type { RuntimeConfig } from '../../db/schema/site_runtimes.js';
export declare class SitesService {
    /**
     * List all sites
     */
    list(): Promise<Site[]>;
    /**
     * Get site by ID with full details
     */
    get(id: string): Promise<(Site & {
        runtime?: any;
        process?: any;
        domains: any[];
    }) | null>;
    /**
     * Create a new site with runtime configuration
     */
    create(data: {
        name: string;
        runtime: RuntimeConfig;
        primaryDomain?: string;
        userId?: string;
        ipAddress?: string;
    }): Promise<Site>;
    /**
     * Update site
     */
    update(id: string, data: {
        name?: string;
    }, userId?: string, ipAddress?: string): Promise<Site>;
    /**
     * Delete site with full cascade
     */
    delete(id: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Suspend site
     */
    suspend(id: string, userId?: string, ipAddress?: string): Promise<Site>;
    /**
     * Activate site
     */
    activate(id: string, userId?: string, ipAddress?: string): Promise<Site>;
    /**
     * Attach domain to site
     */
    attachDomain(siteId: string, domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Detach domain from site
     */
    detachDomain(siteId: string, domainId: string, userId?: string, ipAddress?: string): Promise<void>;
}
export declare const sitesService: SitesService;
//# sourceMappingURL=sites.service.d.ts.map