export declare class SslService {
    /**
     * List all SSL certificates with domain info
     */
    listAll(): Promise<{
        id: string;
        domainId: string | null;
        domain: string;
        type: "custom" | "letsencrypt" | "self-signed";
        enabled: boolean;
        expiresAt: Date | null;
        autoRenew: boolean | null;
        daysUntilExpiry: number | null;
    }[]>;
    /**
     * Get SSL certificate info for a domain
     */
    getCertificate(domainId: string): Promise<{
        enabled: boolean;
        certificate: null;
        type?: undefined;
        expiresAt?: undefined;
        autoRenew?: undefined;
        lastRenewedAt?: undefined;
        daysUntilExpiry?: undefined;
    } | {
        enabled: boolean;
        type: "custom" | "letsencrypt" | "self-signed";
        expiresAt: Date | null;
        autoRenew: boolean | null;
        lastRenewedAt: Date | null;
        daysUntilExpiry: number | null;
        certificate?: undefined;
    }>;
    /**
     * Issue a Let's Encrypt certificate via HTTP-01 challenge
     */
    issueLetsEncrypt(domainId: string, email: string, userId?: string, ipAddress?: string, challengeType?: 'http-01' | 'dns-01'): Promise<{
        type: string;
        expiresAt: Date;
        autoRenew: boolean;
        challengeType: "http-01" | "dns-01";
    }>;
    /**
     * Get Cloudflare API token from an existing tunnel configuration
     */
    private getCloudflareApiToken;
    /**
     * Upload a custom SSL certificate
     */
    uploadCustom(domainId: string, certificate: string, privateKey: string, chain?: string, userId?: string, ipAddress?: string): Promise<{
        type: string;
        expiresAt: Date;
    }>;
    /**
     * Generate a self-signed certificate
     */
    generateSelfSigned(domainId: string, days?: number, userId?: string, ipAddress?: string): Promise<{
        type: string;
        expiresAt: Date;
    }>;
    /**
     * Remove SSL from a domain
     */
    removeCertificate(domainId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Renew a certificate
     */
    renewCertificate(domainId: string, userId?: string, ipAddress?: string): Promise<{
        renewed: boolean;
        expiresAt: Date;
    }>;
    /**
     * List all expiring certificates (admin view)
     */
    listExpiring(days?: number): Promise<{
        domainName: string;
        daysUntilExpiry: number | null;
        id: string;
        domainId: string | null;
        type: "custom" | "letsencrypt" | "self-signed";
        expiresAt: Date | null;
        autoRenew: boolean | null;
    }[]>;
    /**
     * Toggle auto-renew for a certificate
     */
    toggleAutoRenew(domainId: string, autoRenew: boolean, userId?: string, ipAddress?: string): Promise<{
        autoRenew: boolean;
    }>;
    /**
     * Download a certificate file (cert, key, or chain)
     */
    downloadCert(domainId: string, file: 'cert' | 'key' | 'chain'): Promise<string>;
    /**
     * Get detailed certificate info including parsed fields
     */
    getCertDetails(domainId: string): Promise<{
        enabled: boolean;
        certificate: null;
        id?: undefined;
        domainId?: undefined;
        domain?: undefined;
        type?: undefined;
        issuer?: undefined;
        sanDomains?: undefined;
        fingerprint?: undefined;
        issuedAt?: undefined;
        expiresAt?: undefined;
        autoRenew?: undefined;
        lastRenewedAt?: undefined;
        daysUntilExpiry?: undefined;
        hasChain?: undefined;
        hasPrivateKey?: undefined;
    } | {
        enabled: boolean;
        id: string;
        domainId: string | null;
        domain: string;
        type: "custom" | "letsencrypt" | "self-signed";
        issuer: string;
        sanDomains: string[];
        fingerprint: string | null;
        issuedAt: string | null;
        expiresAt: Date | null;
        autoRenew: boolean | null;
        lastRenewedAt: Date | null;
        daysUntilExpiry: number | null;
        hasChain: boolean;
        hasPrivateKey: boolean;
        certificate?: undefined;
    }>;
    /**
     * Validate certificate chain
     */
    validateChain(domainId: string): Promise<{
        valid: boolean;
        issues: string[];
        chainComplete: boolean;
        intermediateCount: number;
        rootTrusted: boolean;
        expiresAt: string | null;
    }>;
    /**
     * Check for mixed content issues - scans domain files for HTTP resources loaded on HTTPS page
     */
    checkMixedContent(domainId: string): Promise<{
        url: string;
        issues: Array<{
            resourceUrl: string;
            type: string;
            line?: number;
            file: string;
        }>;
        totalIssues: number;
        scannedAt: string;
    }>;
    /**
     * Recursively get list of files with specific extensions using find command
     */
    private getFilesRecursively;
    /**
     * Update HSTS settings
     */
    updateHsts(domainId: string, enabled: boolean, maxAge: number, includeSubdomains: boolean): Promise<{
        enabled: boolean;
        maxAge: number;
        includeSubdomains: boolean;
    }>;
    /**
     * Update OCSP stapling settings
     */
    updateOcspStapling(domainId: string, enabled: boolean): Promise<{
        enabled: boolean;
    }>;
}
//# sourceMappingURL=ssl.service.d.ts.map