import type { SystemService, ServiceInfo } from './types.js';
export declare class PhpFpmService implements SystemService {
    private version;
    constructor(version: string);
    readonly name: string;
    readonly displayName: string;
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    static getInstalledVersions(): Promise<string[]>;
    /**
     * Resolve PHP version from site config.
     * In v4: sites + site_runtimes.runtimeConfig JSON holds PHP config.
     */
    private static getSiteInfo;
    static generateWebsitePool(siteId: string): Promise<void>;
    static removeWebsitePool(siteId: string): Promise<void>;
    static reloadPhpFpm(phpVersion: string): Promise<void>;
    private getPoolDir;
    /** @deprecated Use PhpFpmService.generateWebsitePool() instead. */
    createPool(domain: string, systemUser: string, documentRoot: string): Promise<void>;
    /** @deprecated Use PhpFpmService.removeWebsitePool() instead. */
    deletePool(domain: string): Promise<void>;
}
export declare const phpFpmServices: {
    '8.1': PhpFpmService;
    '8.2': PhpFpmService;
    '8.3': PhpFpmService;
    '8.4': PhpFpmService;
};
//# sourceMappingURL=php-fpm.service.d.ts.map