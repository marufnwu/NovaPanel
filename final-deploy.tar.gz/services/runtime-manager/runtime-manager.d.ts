import { type SiteRuntime, type RuntimeConfig } from '../../db/schema/site_runtimes.js';
export declare class RuntimeManager {
    /**
     * Get runtime configuration for a site
     */
    getRuntime(siteId: string): Promise<SiteRuntime | null>;
    /**
     * Create runtime configuration for a site
     */
    createRuntime(siteId: string, config: RuntimeConfig): Promise<SiteRuntime>;
    /**
     * Update runtime configuration
     */
    updateRuntime(siteId: string, config: Partial<RuntimeConfig>): Promise<SiteRuntime>;
    /**
     * Allocate an internal port for a site
     * Ports are auto-assigned from ephemeral range to avoid conflicts
     */
    allocatePort(siteId: string): Promise<number>;
    /**
     * Get default start command based on runtime
     */
    private getDefaultStartCommand;
    /**
     * Install runtime if needed (e.g., install Node.js version)
     */
    ensureRuntimeInstalled(siteId: string): Promise<boolean>;
    private ensureNodeInstalled;
    private ensurePythonInstalled;
    private ensurePhpInstalled;
    /**
     * Validate runtime configuration
     */
    validateConfig(config: RuntimeConfig): {
        valid: boolean;
        errors: string[];
    };
    /**
     * Get parsed runtime config
     */
    parseRuntimeConfig(runtime: SiteRuntime): RuntimeConfig;
}
export declare const runtimeManager: RuntimeManager;
//# sourceMappingURL=runtime-manager.d.ts.map