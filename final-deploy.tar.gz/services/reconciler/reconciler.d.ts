export declare class Reconciler {
    private isRunning;
    private interval;
    /**
     * Start the reconciler loop
     */
    start(): void;
    /**
     * Stop the reconciler loop
     */
    stop(): void;
    /**
     * Reconcile all sites
     */
    reconcileAll(): Promise<void>;
    /**
     * Reconcile a single site
     */
    reconcileSite(siteId: string): Promise<void>;
    /**
     * Get desired state from database
     */
    private getDesiredState;
    /**
     * Get actual state from infrastructure
     */
    private getActualState;
    /**
     * Detect drift between desired and actual state
     */
    private detectDrift;
    /**
     * Repair drift by enqueueing appropriate jobs
     */
    private repairDrift;
    /**
     * Update observed state in database
     */
    private updateObservedState;
}
export declare const reconciler: Reconciler;
//# sourceMappingURL=reconciler.d.ts.map