import { NginxRenderer, SiteModel } from './types.js';
export declare class DefaultNginxRenderer implements NginxRenderer {
    private readonly NGINX_SITES_AVAILABLE;
    constructor();
    getConfigPath(siteId: string): string;
    render(model: SiteModel): string;
    private renderMainBlock;
    private renderRedirectBlock;
    validate(config: string): Promise<boolean>;
}
export declare const nginxRenderer: DefaultNginxRenderer;
//# sourceMappingURL=nginx.renderer.d.ts.map