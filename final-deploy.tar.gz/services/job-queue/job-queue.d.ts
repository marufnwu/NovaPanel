import { type BackgroundJob } from '../../db/schema/background_jobs.js';
declare class JobQueueService {
    private isRunning;
    private workerInterval;
    private processingCount;
    /**
     * Start the job queue worker
     */
    start(): void;
    /**
     * Stop the job queue worker
     */
    stop(): void;
    /**
     * Enqueue a new job
     */
    enqueue(type: string, payload: Record<string, unknown>, options?: {
        dedupeKey?: string;
        maxRetries?: number;
    }): Promise<string>;
    /**
     * Process pending jobs
     */
    private processJobs;
    /**
     * Process a single job
     */
    private processJob;
    /**
     * Handle job failure with retry logic
     */
    private handleJobFailure;
    /**
     * Mark job as completed
     */
    private completeJob;
    /**
     * Get job status
     */
    getJob(jobId: string): Promise<BackgroundJob | null>;
    /**
     * Cancel a pending job
     */
    cancelJob(jobId: string): Promise<boolean>;
    /**
     * List jobs with filters
     */
    listJobs(filters?: {
        status?: string;
        type?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        items: BackgroundJob[];
        total: number;
    }>;
}
export declare const jobQueue: JobQueueService;
export {};
//# sourceMappingURL=job-queue.d.ts.map