import type { SystemService, ServiceInfo } from './types.js';
export interface VhostContext {
    domain: string;
    documentRoot: string;
    phpVersion?: string;
    ssl?: {
        certPath: string;
        keyPath: string;
    };
    aliases?: string[];
    redirectHttpToHttps?: boolean;
    hsts?: boolean;
    upstreamPort?: number;
}
export declare class NginxService implements SystemService {
    readonly name = "nginx";
    readonly displayName = "Nginx";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    /**
     * Test Nginx configuration syntax without applying
     * Uses `nginx -T` directly instead of `nginx -t` or `systemctl configtest` because:
     * 1. nginx -t with sudo can have issues on systems with read-only /run or permission problems
     * 2. nginx -T dumps configuration without forking (no pid file needed)
     * 3. systemctl configtest is not supported on all systems (Unknown command verb)
     */
    testConfig(): Promise<{
        valid: boolean;
        output: string;
    }>;
    /**
     * Resolve the document root for a domain based on its type.
     * - primary: {website.homeDir}/httpdocs
     * - addon: {website.homeDir}/addons/{domainId}/httpdocs
     * - parked: NULL (uses primary's docroot)
     * - subdomain: {website.homeDir}/subdomains/{domainId}/httpdocs
     * - redirect/mail-only: NULL
     */
    private resolveDocumentRoot;
    /**
     * Resolve effective PHP version for a domain (inherit from website if null).
     */
    private resolvePhpVersion;
    /**
     * Generate a single nginx config file for a website containing type-aware server blocks.
     * Per v3 architecture:
     * - Primary domain + parked domains share one server block (parked merged into server_name)
     * - Each addon domain gets its own server block
     * - Each subdomain gets its own server block
     * - Suspended domains get a 503 block instead of their normal block
     */
    generateWebsiteConfig(websiteId: string): Promise<void>;
    private generateConfigHeader;
    /**
     * Build primary domain server block with parked domains merged into server_name.
     * Both HTTP and HTTPS blocks are included if SSL is enabled.
     */
    private buildPrimaryServerBlock;
    /**
     * Build addon domain server block with its own docroot under addons/.
     */
    private buildAddonServerBlock;
    /**
     * Build subdomain server block with its own docroot under subdomains/.
     */
    private buildSubdomainServerBlock;
    /**
     * Build a 503 suspended block for a single domain.
     * This replaces only that domain's server block within the website conf.
     */
    private buildSuspendedBlock;
    /**
     * Generate nginx config for a subdomain (v3: subdomain is now a domain type).
     * Since subdomains are now stored in the domains table with type='subdomain',
     * this method regenerates the website config which now includes subdomain blocks.
     */
    generateSubdomainConfig(subdomainDomainId: string): Promise<void>;
    /**
     * Generate nginx config for a site (v4 architecture - alias for generateWebsiteConfig).
     * In v4, "site" replaces "website" as the primary entity.
     * This method delegates to generateWebsiteConfig for backward compatibility.
     */
    generateSiteConfig(siteId: string): Promise<void>;
    /**
     * Generate a "suspended" nginx config for a website — all domains return 503.
     * The original config is backed up with a `.active` suffix before overwriting.
     */
    generateSuspendedConfig(websiteId: string): Promise<void>;
    /**
     * Remove the nginx config file for a website and reload nginx.
     */
    removeWebsiteConfig(websiteId: string): Promise<void>;
    /**
     * Generate a suspended config for a single domain within a website.
     * Unlike generateSuspendedConfig which suspends all domains in a website,
     * this method only suspends ONE domain by replacing its server block with a 503.
     * The original server block is stored in domains.suspendedConfig for restoration.
     */
    generateSingleDomainSuspendedConfig(domainId: string): Promise<void>;
    /**
     * Test nginx config and reload if valid.
     * Throws if nginx -t fails.
     */
    reloadNginx(): Promise<void>;
    /**
     * @deprecated Use generateWebsiteConfig() instead.
     * Add a virtual host configuration (per-domain).
     */
    addVhost(context: VhostContext): Promise<void>;
    /**
     * @deprecated Use removeWebsiteConfig() instead.
     * Remove a virtual host configuration (per-domain).
     */
    removeVhost(domain: string): Promise<void>;
    /**
     * Render Nginx vhost config from template
     */
    private renderVhost;
    private renderPhpLocation;
}
export declare const nginxService: NginxService;
//# sourceMappingURL=nginx.service.d.ts.map