import { type Deployment } from '../db/schema/index.js';
export declare class DeploymentService {
    /**
     * Get deployments for a site
     */
    getDeployments(siteId: string): Promise<Deployment[]>;
    /**
     * Get deployment by ID
     */
    getDeployment(id: string): Promise<Deployment | null>;
    /**
     * Get current active deployment for a site
     */
    getCurrentDeployment(siteId: string): Promise<Deployment | null>;
    /**
     * Create a new deployment
     */
    create(data: {
        siteId: string;
        sourceType: 'git' | 'archive' | 'empty';
        gitRepo?: string;
        gitBranch?: string;
        archivePath?: string;
        userId?: string;
        ipAddress?: string;
    }): Promise<Deployment>;
    /**
     * Build a deployment (called by job worker)
     */
    build(data: {
        deploymentId: string;
        siteId: string;
        sourceType: string;
        gitRepo?: string;
        gitBranch?: string;
        archivePath?: string;
    }): Promise<void>;
    /**
     * Deploy (switch symlink to new deployment)
     */
    deploy(deploymentId: string): Promise<void>;
    /**
     * Rollback to previous deployment
     */
    rollback(siteId: string, userId?: string, ipAddress?: string): Promise<Deployment>;
    /**
     * Delete old deployment (cleanup)
     */
    deleteDeployment(id: string): Promise<void>;
}
export declare const deploymentService: DeploymentService;
//# sourceMappingURL=deployment.service.d.ts.map