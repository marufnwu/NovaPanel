import type { FastifyInstance } from 'fastify';
export declare function registerContainerExecWs(fastify: FastifyInstance): Promise<void>;
export declare function registerContainerLogsWs(fastify: FastifyInstance): Promise<void>;
export declare function cleanupContainerSessions(): void;
//# sourceMappingURL=container.ws.d.ts.map