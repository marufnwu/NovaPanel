export declare class StorageService {
    listBuckets(orgId?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        publicAccess: boolean;
        region: string | null;
        versioning: boolean;
        corsRules: unknown;
    }[]>;
    getBucket(id: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        publicAccess: boolean;
        region: string | null;
        versioning: boolean;
        corsRules: unknown;
    }>;
    createBucket(data: {
        orgId: string;
        name: string;
        region?: string;
        publicAccess?: boolean;
        versioning?: boolean;
        corsRules?: unknown[];
    }): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        publicAccess: boolean;
        region: string | null;
        versioning: boolean;
        corsRules: unknown;
    }>;
    updateBucket(id: string, data: Partial<{
        name: string;
        publicAccess: boolean;
        versioning: boolean;
        corsRules: unknown[];
    }>): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        publicAccess: boolean;
        region: string | null;
        versioning: boolean;
        corsRules: unknown;
    }>;
    deleteBucket(id: string): Promise<{
        success: boolean;
    }>;
    listAccessKeys(orgId: string): Promise<{
        secretKeyHash: undefined;
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        permissions: unknown;
        accessKeyId: string;
    }[]>;
    createAccessKey(data: {
        orgId: string;
        name: string;
        permissions?: string[];
    }): Promise<{
        secretKey: string;
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        permissions: unknown;
        accessKeyId: string;
        secretKeyHash: string;
    }>;
    deleteAccessKey(id: string): Promise<{
        success: boolean;
    }>;
}
export declare const storageService: StorageService;
//# sourceMappingURL=storage.service.d.ts.map