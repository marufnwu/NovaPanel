import { db } from '../../db/index.js';
import { projects } from '../../db/schema/organizations.js';
import { eq } from 'drizzle-orm';
import { AppError } from '../../errors.js';
import { nanoid } from 'nanoid';
export class ProjectsService {
    async listByOrg(orgId) {
        return db.select().from(projects).where(eq(projects.orgId, orgId));
    }
    async get(id) {
        const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
        return project || null;
    }
    async create(data, _userId) {
        const id = nanoid();
        const env = data.environment || 'production';
        const [project] = await db.insert(projects).values({
            id,
            orgId: data.orgId,
            name: data.name,
            slug: data.slug,
            environment: env,
            settings: '{}',
        }).returning();
        return project;
    }
    async update(id, data) {
        const [updated] = await db.update(projects).set(data).where(eq(projects.id, id)).returning();
        if (!updated)
            throw new AppError(404, 'NOT_FOUND', 'Project not found');
        return updated;
    }
    async delete(id) {
        await db.delete(projects).where(eq(projects.id, id));
        return { success: true };
    }
}
export const projectsService = new ProjectsService();
//# sourceMappingURL=projects.service.js.map