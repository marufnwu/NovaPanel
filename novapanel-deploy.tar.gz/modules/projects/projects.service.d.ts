export declare class ProjectsService {
    listByOrg(orgId: string): Promise<{
        [x: string]: any;
    }[]>;
    get(id: string): Promise<{
        [x: string]: any;
    }>;
    create(data: {
        name: string;
        slug: string;
        orgId: string;
        environment?: 'production' | 'staging' | 'development';
    }, _userId?: string): Promise<any>;
    update(id: string, data: {
        name?: string;
        environment?: 'production' | 'staging' | 'development';
    }): Promise<any>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
}
export declare const projectsService: ProjectsService;
//# sourceMappingURL=projects.service.d.ts.map