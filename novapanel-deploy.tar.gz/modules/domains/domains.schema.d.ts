import { z } from 'zod';
export declare const createDomainSchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["apex", "subdomain", "wildcard"]>>;
    siteId: z.ZodOptional<z.ZodString>;
    projectId: z.ZodOptional<z.ZodString>;
    dnsZoneId: z.ZodOptional<z.ZodString>;
    skipDnsVerification: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    type: "apex" | "subdomain" | "wildcard";
    name: string;
    skipDnsVerification: boolean;
    siteId?: string | undefined;
    dnsZoneId?: string | undefined;
    projectId?: string | undefined;
}, {
    name: string;
    type?: "apex" | "subdomain" | "wildcard" | undefined;
    siteId?: string | undefined;
    dnsZoneId?: string | undefined;
    projectId?: string | undefined;
    skipDnsVerification?: boolean | undefined;
}>;
export declare const verifyDomainDnsSchema: z.ZodObject<{
    domain: z.ZodString;
}, "strip", z.ZodTypeAny, {
    domain: string;
}, {
    domain: string;
}>;
export declare const updateDomainSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    sslStatus: z.ZodOptional<z.ZodEnum<["pending", "active", "expired", "error"]>>;
    sslAutoRenew: z.ZodOptional<z.ZodBoolean>;
    forceHttps: z.ZodOptional<z.ZodBoolean>;
    hstsEnabled: z.ZodOptional<z.ZodBoolean>;
    proxyEnabled: z.ZodOptional<z.ZodBoolean>;
    customNginxConfig: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<["active", "suspended", "pending"]>>;
}, "strip", z.ZodTypeAny, {
    status?: "active" | "suspended" | "pending" | undefined;
    name?: string | undefined;
    sslStatus?: "error" | "active" | "pending" | "expired" | undefined;
    sslAutoRenew?: boolean | undefined;
    forceHttps?: boolean | undefined;
    hstsEnabled?: boolean | undefined;
    proxyEnabled?: boolean | undefined;
    customNginxConfig?: string | undefined;
}, {
    status?: "active" | "suspended" | "pending" | undefined;
    name?: string | undefined;
    sslStatus?: "error" | "active" | "pending" | "expired" | undefined;
    sslAutoRenew?: boolean | undefined;
    forceHttps?: boolean | undefined;
    hstsEnabled?: boolean | undefined;
    proxyEnabled?: boolean | undefined;
    customNginxConfig?: string | undefined;
}>;
export declare const deleteDomainSchema: z.ZodObject<{
    deleteWebsite: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    deleteWebsite: boolean;
}, {
    deleteWebsite?: boolean | undefined;
}>;
export declare const createSubdomainSchema: z.ZodObject<{
    name: z.ZodString;
    documentRoot: z.ZodOptional<z.ZodString>;
    phpVersion: z.ZodOptional<z.ZodString>;
    siteId: z.ZodOptional<z.ZodString>;
    websiteId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    siteId?: string | undefined;
    phpVersion?: string | undefined;
    documentRoot?: string | undefined;
    websiteId?: string | undefined;
}, {
    name: string;
    siteId?: string | undefined;
    phpVersion?: string | undefined;
    documentRoot?: string | undefined;
    websiteId?: string | undefined;
}>;
export declare const createAliasSchema: z.ZodObject<{
    alias: z.ZodString;
}, "strip", z.ZodTypeAny, {
    alias: string;
}, {
    alias: string;
}>;
export declare const createRedirectSchema: z.ZodObject<{
    sourcePath: z.ZodString;
    targetUrl: z.ZodString;
    type: z.ZodDefault<z.ZodEnum<["301", "302"]>>;
}, "strip", z.ZodTypeAny, {
    type: "301" | "302";
    sourcePath: string;
    targetUrl: string;
}, {
    sourcePath: string;
    targetUrl: string;
    type?: "301" | "302" | undefined;
}>;
export declare const makePublicSchema: z.ZodObject<{
    tunnelId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    tunnelId?: string | undefined;
}, {
    tunnelId?: string | undefined;
}>;
export declare const domainLogsQuerySchema: z.ZodObject<{
    lines: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    lines: number;
}, {
    lines?: number | undefined;
}>;
export type CreateDomainInput = z.infer<typeof createDomainSchema>;
export type UpdateDomainInput = z.infer<typeof updateDomainSchema>;
export type DeleteDomainInput = z.infer<typeof deleteDomainSchema>;
export type CreateSubdomainInput = z.infer<typeof createSubdomainSchema>;
export type CreateAliasInput = z.infer<typeof createAliasSchema>;
export type CreateRedirectInput = z.infer<typeof createRedirectSchema>;
export type MakePublicInput = z.infer<typeof makePublicSchema>;
export type DomainLogsQuery = z.infer<typeof domainLogsQuerySchema>;
//# sourceMappingURL=domains.schema.d.ts.map