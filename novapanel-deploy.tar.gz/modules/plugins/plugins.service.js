import { db } from '../../db/index.js';
import { plugins } from '../../db/schema/plugins.js';
import { eq, desc } from 'drizzle-orm';
import { nanoid } from 'nanoid';
import { VM } from 'vm2';
export class PluginsService {
    async list() {
        return db.select().from(plugins).orderBy(desc(plugins.createdAt));
    }
    async get(id) {
        const [p] = await db.select().from(plugins).where(eq(plugins.id, id)).limit(1);
        return p ?? null;
    }
    async create(data) {
        const plugin = {
            id: nanoid(),
            name: data.name,
            version: data.version,
            description: data.description,
            author: data.author,
            manifest: data.manifest ?? {},
            enabled: data.enabled ?? false,
            config: data.config ?? {},
            createdAt: new Date(),
        };
        await db.insert(plugins).values(plugin);
        const [created] = await db.select().from(plugins).where(eq(plugins.id, plugin.id)).limit(1);
        if (created.enabled) {
            this.executeHook(created.id, 'onEnable').catch(() => { });
        }
        this.executeHook(created.id, 'onInstall').catch(() => { });
        return created;
    }
    async update(id, data) {
        await db.update(plugins).set({ ...data, updatedAt: new Date() }).where(eq(plugins.id, id));
        const [updated] = await db.select().from(plugins).where(eq(plugins.id, id)).limit(1);
        if (!updated)
            throw new Error('Plugin not found');
        return updated;
    }
    async delete(id) {
        const plugin = await this.get(id);
        if (plugin) {
            this.executeHook(id, 'onUninstall').catch(() => { });
        }
        await db.delete(plugins).where(eq(plugins.id, id));
    }
    async toggle(id) {
        const plugin = await this.get(id);
        if (!plugin)
            throw new Error('Plugin not found');
        const wasEnabled = plugin.enabled;
        const updated = await this.update(id, { enabled: !plugin.enabled });
        if (!wasEnabled && updated.enabled) {
            this.executeHook(updated.id, 'onEnable').catch(() => { });
        }
        else if (wasEnabled && !updated.enabled) {
            this.executeHook(updated.id, 'onDisable').catch(() => { });
        }
        return updated;
    }
    async updateConfig(id, config) {
        const updated = await this.update(id, { config });
        this.executeHook(id, 'onConfigChange', { config }).catch(() => { });
        return updated;
    }
    async executeHook(pluginId, hookName, hookData = {}) {
        const plugin = await this.get(pluginId);
        if (!plugin)
            throw new Error('Plugin not found');
        if (!plugin.enabled)
            throw new Error('Plugin is disabled');
        const manifest = plugin.manifest;
        const hook = manifest[hookName];
        if (!hook)
            return undefined;
        if (hook.language !== 'javascript')
            throw new Error(`Unsupported hook language: ${hook.language}`);
        const vm = new VM({
            timeout: 5000,
            eval: false,
            wasm: false,
            sandbox: { hookData },
        });
        return vm.run(hook.code);
    }
}
export const pluginsService = new PluginsService();
//# sourceMappingURL=plugins.service.js.map