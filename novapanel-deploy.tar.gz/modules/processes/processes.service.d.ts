import { ProcessStatus, ProcessConfig } from '../../services/process-manager/types.js';
export interface ProcessInfo {
    name: string;
    status: ProcessStatus;
}
export declare class ProcessesService {
    /**
     * Get all processes managed by the process manager
     */
    listProcesses(): Promise<ProcessInfo[]>;
    /**
     * Get status of a specific process
     */
    getProcess(name: string): Promise<ProcessInfo | null>;
    /**
     * Start a process
     */
    startProcess(config: ProcessConfig): Promise<void>;
    /**
     * Stop a process
     */
    stopProcess(name: string): Promise<void>;
    /**
     * Restart a process
     */
    restartProcess(name: string): Promise<void>;
    /**
     * Delete a process
     */
    deleteProcess(name: string): Promise<void>;
    /**
     * Get process logs
     */
    getProcessLogs(name: string, lines?: number): Promise<string>;
    /**
     * Check if process manager is available
     */
    isAvailable(): Promise<boolean>;
}
export declare const processesService: ProcessesService;
//# sourceMappingURL=processes.service.d.ts.map