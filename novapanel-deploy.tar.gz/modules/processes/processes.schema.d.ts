import { z } from 'zod';
export declare const processStatusSchema: z.ZodEnum<["online", "stopped", "errored", "launching"]>;
export declare const processStatusResponseSchema: z.ZodObject<{
    running: z.ZodBoolean;
    pid: z.ZodOptional<z.ZodNumber>;
    uptime: z.ZodOptional<z.ZodNumber>;
    memoryMb: z.ZodOptional<z.ZodNumber>;
    cpuPercent: z.ZodOptional<z.ZodNumber>;
    restartCount: z.ZodNumber;
    status: z.ZodEnum<["online", "stopped", "errored", "launching"]>;
}, "strip", z.ZodTypeAny, {
    status: "stopped" | "online" | "errored" | "launching";
    running: boolean;
    restartCount: number;
    cpuPercent?: number | undefined;
    pid?: number | undefined;
    uptime?: number | undefined;
    memoryMb?: number | undefined;
}, {
    status: "stopped" | "online" | "errored" | "launching";
    running: boolean;
    restartCount: number;
    cpuPercent?: number | undefined;
    pid?: number | undefined;
    uptime?: number | undefined;
    memoryMb?: number | undefined;
}>;
export declare const processInfoSchema: z.ZodObject<{
    name: z.ZodString;
    status: z.ZodObject<{
        running: z.ZodBoolean;
        pid: z.ZodOptional<z.ZodNumber>;
        uptime: z.ZodOptional<z.ZodNumber>;
        memoryMb: z.ZodOptional<z.ZodNumber>;
        cpuPercent: z.ZodOptional<z.ZodNumber>;
        restartCount: z.ZodNumber;
        status: z.ZodEnum<["online", "stopped", "errored", "launching"]>;
    }, "strip", z.ZodTypeAny, {
        status: "stopped" | "online" | "errored" | "launching";
        running: boolean;
        restartCount: number;
        cpuPercent?: number | undefined;
        pid?: number | undefined;
        uptime?: number | undefined;
        memoryMb?: number | undefined;
    }, {
        status: "stopped" | "online" | "errored" | "launching";
        running: boolean;
        restartCount: number;
        cpuPercent?: number | undefined;
        pid?: number | undefined;
        uptime?: number | undefined;
        memoryMb?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    status: {
        status: "stopped" | "online" | "errored" | "launching";
        running: boolean;
        restartCount: number;
        cpuPercent?: number | undefined;
        pid?: number | undefined;
        uptime?: number | undefined;
        memoryMb?: number | undefined;
    };
    name: string;
}, {
    status: {
        status: "stopped" | "online" | "errored" | "launching";
        running: boolean;
        restartCount: number;
        cpuPercent?: number | undefined;
        pid?: number | undefined;
        uptime?: number | undefined;
        memoryMb?: number | undefined;
    };
    name: string;
}>;
export declare const listProcessesResponseSchema: z.ZodObject<{
    success: z.ZodLiteral<true>;
    data: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        status: z.ZodObject<{
            running: z.ZodBoolean;
            pid: z.ZodOptional<z.ZodNumber>;
            uptime: z.ZodOptional<z.ZodNumber>;
            memoryMb: z.ZodOptional<z.ZodNumber>;
            cpuPercent: z.ZodOptional<z.ZodNumber>;
            restartCount: z.ZodNumber;
            status: z.ZodEnum<["online", "stopped", "errored", "launching"]>;
        }, "strip", z.ZodTypeAny, {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        }, {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        }>;
    }, "strip", z.ZodTypeAny, {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }, {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    data: {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }[];
    success: true;
}, {
    data: {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }[];
    success: true;
}>;
export declare const getProcessResponseSchema: z.ZodObject<{
    success: z.ZodLiteral<true>;
    data: z.ZodNullable<z.ZodObject<{
        name: z.ZodString;
        status: z.ZodObject<{
            running: z.ZodBoolean;
            pid: z.ZodOptional<z.ZodNumber>;
            uptime: z.ZodOptional<z.ZodNumber>;
            memoryMb: z.ZodOptional<z.ZodNumber>;
            cpuPercent: z.ZodOptional<z.ZodNumber>;
            restartCount: z.ZodNumber;
            status: z.ZodEnum<["online", "stopped", "errored", "launching"]>;
        }, "strip", z.ZodTypeAny, {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        }, {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        }>;
    }, "strip", z.ZodTypeAny, {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }, {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    }>>;
}, "strip", z.ZodTypeAny, {
    data: {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    } | null;
    success: true;
}, {
    data: {
        status: {
            status: "stopped" | "online" | "errored" | "launching";
            running: boolean;
            restartCount: number;
            cpuPercent?: number | undefined;
            pid?: number | undefined;
            uptime?: number | undefined;
            memoryMb?: number | undefined;
        };
        name: string;
    } | null;
    success: true;
}>;
export declare const processConfigSchema: z.ZodObject<{
    name: z.ZodString;
    command: z.ZodString;
    cwd: z.ZodOptional<z.ZodString>;
    env: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    replicas: z.ZodOptional<z.ZodNumber>;
    healthCheckPath: z.ZodOptional<z.ZodString>;
    logFile: z.ZodOptional<z.ZodString>;
    errorFile: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    command: string;
    replicas?: number | undefined;
    healthCheckPath?: string | undefined;
    env?: Record<string, string> | undefined;
    cwd?: string | undefined;
    logFile?: string | undefined;
    errorFile?: string | undefined;
}, {
    name: string;
    command: string;
    replicas?: number | undefined;
    healthCheckPath?: string | undefined;
    env?: Record<string, string> | undefined;
    cwd?: string | undefined;
    logFile?: string | undefined;
    errorFile?: string | undefined;
}>;
export declare const startProcessSchema: z.ZodObject<{
    config: z.ZodObject<{
        name: z.ZodString;
        command: z.ZodString;
        cwd: z.ZodOptional<z.ZodString>;
        env: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        replicas: z.ZodOptional<z.ZodNumber>;
        healthCheckPath: z.ZodOptional<z.ZodString>;
        logFile: z.ZodOptional<z.ZodString>;
        errorFile: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        name: string;
        command: string;
        replicas?: number | undefined;
        healthCheckPath?: string | undefined;
        env?: Record<string, string> | undefined;
        cwd?: string | undefined;
        logFile?: string | undefined;
        errorFile?: string | undefined;
    }, {
        name: string;
        command: string;
        replicas?: number | undefined;
        healthCheckPath?: string | undefined;
        env?: Record<string, string> | undefined;
        cwd?: string | undefined;
        logFile?: string | undefined;
        errorFile?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    config: {
        name: string;
        command: string;
        replicas?: number | undefined;
        healthCheckPath?: string | undefined;
        env?: Record<string, string> | undefined;
        cwd?: string | undefined;
        logFile?: string | undefined;
        errorFile?: string | undefined;
    };
}, {
    config: {
        name: string;
        command: string;
        replicas?: number | undefined;
        healthCheckPath?: string | undefined;
        env?: Record<string, string> | undefined;
        cwd?: string | undefined;
        logFile?: string | undefined;
        errorFile?: string | undefined;
    };
}>;
export declare const processActionResponseSchema: z.ZodObject<{
    success: z.ZodLiteral<true>;
}, "strip", z.ZodTypeAny, {
    success: true;
}, {
    success: true;
}>;
export declare const processLogsResponseSchema: z.ZodObject<{
    success: z.ZodLiteral<true>;
    data: z.ZodObject<{
        logs: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        logs: string;
    }, {
        logs: string;
    }>;
}, "strip", z.ZodTypeAny, {
    data: {
        logs: string;
    };
    success: true;
}, {
    data: {
        logs: string;
    };
    success: true;
}>;
export declare const processNameParamsSchema: z.ZodObject<{
    name: z.ZodString;
}, "strip", z.ZodTypeAny, {
    name: string;
}, {
    name: string;
}>;
export declare const processLogsQuerySchema: z.ZodObject<{
    lines: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    lines: number;
}, {
    lines?: number | undefined;
}>;
//# sourceMappingURL=processes.schema.d.ts.map