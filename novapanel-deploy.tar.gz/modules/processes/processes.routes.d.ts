import type { FastifyInstance } from 'fastify';
export default function processesRoutes(fastify: FastifyInstance): Promise<void>;
//# sourceMappingURL=processes.routes.d.ts.map