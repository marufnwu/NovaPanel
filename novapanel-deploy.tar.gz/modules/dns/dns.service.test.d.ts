export {};
//# sourceMappingURL=dns.service.test.d.ts.map