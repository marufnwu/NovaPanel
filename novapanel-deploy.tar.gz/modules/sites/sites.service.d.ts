import { sites } from '../../db/schema/index.js';
import type { CreateSiteInput } from './sites.schema.js';
export declare class SitesService {
    list(_options?: {
        includeRuntime?: boolean;
    }): Promise<typeof sites.$inferSelect[]>;
    get(id: string): Promise<{
        domains: {
            type: "apex" | "subdomain" | "wildcard";
            status: "active" | "suspended" | "pending";
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date | null;
            orgId: string | null;
            siteId: string | null;
            dnsZoneId: string | null;
            nameservers: unknown;
            dnssecEnabled: boolean;
            sslStatus: "error" | "active" | "pending" | "expired";
            sslCertId: string | null;
            sslAutoRenew: boolean;
            forceHttps: boolean;
            hstsEnabled: boolean;
            proxyEnabled: boolean;
            customNginxConfig: string | null;
        }[];
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        orgId: string | null;
        description: string | null;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    } | null>;
    create(data: CreateSiteInput, _userId?: string, _ipAddress?: string): Promise<{
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        orgId: string | null;
        description: string | null;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    }>;
    update(id: string, data: Partial<typeof sites.$inferInsert>, _userId?: string, _ipAddress?: string): Promise<{
        status: "error" | "active" | "suspended" | "building" | "deploying" | "stopped";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        slug: string;
        orgId: string | null;
        description: string | null;
        runtime: "docker" | "node" | "python" | "php" | "go" | "ruby" | "rust" | "static";
        runtimeVersion: string | null;
        sourceType: "git" | "docker_registry" | "upload" | "empty";
        gitRepo: string | null;
        gitBranch: string | null;
        gitWebhookSecret: string | null;
        buildCommand: string | null;
        outputDirectory: string | null;
        installCommand: string | null;
        startCommand: string | null;
        port: number | null;
        replicas: number;
        autoRestart: boolean;
        memoryLimit: number | null;
        cpuLimit: number | null;
        lastDeploymentId: string | null;
        healthCheckPath: string | null;
    }>;
    delete(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    suspend(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    } | null>;
    activate(id: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    } | null>;
    attachDomain(siteId: string, domainId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    detachDomain(siteId: string, domainId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getStats(id: string): Promise<{
        visitorsToday: number;
        bandwidthToday: string;
        diskUsage: string;
        cpuUsage: number;
        memoryUsage: number;
        requestsPerMinute: number;
        avgResponseTime: string;
        uptime: string;
    }>;
    getHealth(id: string): Promise<{
        status: string;
        webServer: string;
        phpFpm: string;
        database: string;
        lastCheck: string;
        issues: string[];
    }>;
    build(siteId: string): Promise<{
        deploymentId: string;
    }>;
    deploy(siteId: string): Promise<{
        deploymentId: string;
    }>;
    rollbackToDeployment(siteId: string, deploymentId: string): Promise<{
        deploymentId: string;
    }>;
    getLogs(siteId: string, lines?: number): Promise<{
        logs: string;
    }>;
    getStatus(siteId: string): Promise<{
        running: boolean;
        containerId?: string;
    }>;
    stop(id: string): Promise<{
        success: boolean;
    }>;
    getDockerfile(siteId: string): Promise<{
        dockerfile: string;
    }>;
    getCronJobs(siteId: string): Promise<{
        status: "error" | "active" | "paused";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        siteId: string | null;
        command: string;
        schedule: string;
        user: string | null;
        workingDir: string | null;
        lastRunAt: Date | null;
        lastExitCode: number | null;
        nextRunAt: Date | null;
    }[]>;
    getDatabase(siteId: string): Promise<{
        id: string;
        name: string;
        engine: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
    } | null>;
    getSsl(siteId: string): Promise<{
        domain: string;
        expiresAt: Date | null;
        validFrom: Date;
        autoRenew: boolean;
        status: "error" | "active" | "pending" | "expired" | "revoked";
    } | null>;
    getDns(siteId: string): Promise<{
        items: {
            id: string;
            name: string;
            type: string;
            value: string;
            proxied: boolean;
        }[];
    }>;
    getPhp(siteId: string): Promise<{
        version: string;
        configPath: string;
        poolPath: string;
    }>;
    getWebserver(siteId: string): Promise<{
        type: string;
        configPath: string;
        enabledPath: string;
        documentRoot: string;
    }>;
    private getBuiltInEnvVars;
    getEnvVars(siteId: string): Promise<{
        id: string;
        key: string;
        value: string;
        isSecret: boolean;
        source: "builtin";
        createdAt: string;
        updatedAt: string;
    }[]>;
    createEnvVar(siteId: string, data: {
        key: string;
        value: string;
        isSecret?: boolean;
    }): Promise<{
        id: string;
        key: string;
        value: string;
        isSecret: boolean;
        source: "database";
        createdAt: string;
        updatedAt: string;
    }>;
    updateEnvVar(siteId: string, envId: string, data: {
        key?: string;
        value?: string;
        isSecret?: boolean;
    }): Promise<{
        id: string;
        key: string;
        value: string;
        isSecret: boolean;
        source: "database";
        createdAt: string;
        updatedAt: string;
    }>;
    deleteEnvVar(siteId: string, envId: string): Promise<{
        success: boolean;
    }>;
    getActivities(siteId: string, options?: {
        type?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        items: {
            id: string;
            siteId: string;
            type: string;
            action: string;
            description: string;
            details?: Record<string, any>;
            userId?: string;
            userName?: string;
            timestamp: string;
            metadata?: {
                ipAddress?: string;
                userAgent?: string;
                resourceType?: string;
                resourceId?: string;
            };
        }[];
        total: number;
    }>;
    getRecentActivities(siteId: string, limit?: number): Promise<{
        id: string;
        siteId: string;
        type: string;
        action: string;
        description: string;
        details?: Record<string, any>;
        userId?: string;
        userName?: string;
        timestamp: string;
        metadata?: {
            ipAddress?: string;
            userAgent?: string;
            resourceType?: string;
            resourceId?: string;
        };
    }[]>;
    private formatUptime;
}
export declare const sitesService: SitesService;
//# sourceMappingURL=sites.service.d.ts.map