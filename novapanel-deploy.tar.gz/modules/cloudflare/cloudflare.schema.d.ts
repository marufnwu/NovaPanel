import { z } from 'zod';
export declare const linkZoneSchema: z.ZodObject<{
    zoneId: z.ZodOptional<z.ZodString>;
    zoneName: z.ZodOptional<z.ZodString>;
    apiToken: z.ZodString;
    accountId: z.ZodOptional<z.ZodString>;
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    apiToken: string;
    domainId?: string | undefined;
    zoneId?: string | undefined;
    accountId?: string | undefined;
    zoneName?: string | undefined;
}, {
    apiToken: string;
    domainId?: string | undefined;
    zoneId?: string | undefined;
    accountId?: string | undefined;
    zoneName?: string | undefined;
}>;
export declare const updateZoneSettingsSchema: z.ZodObject<{
    sslMode: z.ZodOptional<z.ZodEnum<["off", "flexible", "full", "strict"]>>;
    alwaysUseHttps: z.ZodOptional<z.ZodBoolean>;
    automaticHttpsRewrites: z.ZodOptional<z.ZodBoolean>;
    minTlsVersion: z.ZodOptional<z.ZodEnum<["1.0", "1.1", "1.2", "1.3"]>>;
    http2: z.ZodOptional<z.ZodBoolean>;
    http3: z.ZodOptional<z.ZodBoolean>;
    browserCacheTtl: z.ZodOptional<z.ZodNumber>;
    developmentMode: z.ZodOptional<z.ZodBoolean>;
    emailObfuscation: z.ZodOptional<z.ZodBoolean>;
    hotlinkProtection: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    http2?: boolean | undefined;
    hotlinkProtection?: boolean | undefined;
    alwaysUseHttps?: boolean | undefined;
    automaticHttpsRewrites?: boolean | undefined;
    minTlsVersion?: "1.0" | "1.1" | "1.2" | "1.3" | undefined;
    http3?: boolean | undefined;
    sslMode?: "full" | "strict" | "off" | "flexible" | undefined;
    browserCacheTtl?: number | undefined;
    developmentMode?: boolean | undefined;
    emailObfuscation?: boolean | undefined;
}, {
    http2?: boolean | undefined;
    hotlinkProtection?: boolean | undefined;
    alwaysUseHttps?: boolean | undefined;
    automaticHttpsRewrites?: boolean | undefined;
    minTlsVersion?: "1.0" | "1.1" | "1.2" | "1.3" | undefined;
    http3?: boolean | undefined;
    sslMode?: "full" | "strict" | "off" | "flexible" | undefined;
    browserCacheTtl?: number | undefined;
    developmentMode?: boolean | undefined;
    emailObfuscation?: boolean | undefined;
}>;
export declare const createDnsRecordSchema: z.ZodObject<{
    type: z.ZodEnum<["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA", "PTR"]>;
    name: z.ZodString;
    content: z.ZodString;
    proxied: z.ZodOptional<z.ZodBoolean>;
    ttl: z.ZodOptional<z.ZodNumber>;
    priority: z.ZodOptional<z.ZodNumber>;
    comment: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
    name: string;
    content: string;
    ttl?: number | undefined;
    priority?: number | undefined;
    proxied?: boolean | undefined;
    comment?: string | undefined;
}, {
    type: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR";
    name: string;
    content: string;
    ttl?: number | undefined;
    priority?: number | undefined;
    proxied?: boolean | undefined;
    comment?: string | undefined;
}>;
export declare const updateDnsRecordSchema: z.ZodObject<{
    type: z.ZodOptional<z.ZodEnum<["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA", "PTR"]>>;
    name: z.ZodOptional<z.ZodString>;
    content: z.ZodOptional<z.ZodString>;
    proxied: z.ZodOptional<z.ZodBoolean>;
    ttl: z.ZodOptional<z.ZodNumber>;
    priority: z.ZodOptional<z.ZodNumber>;
    comment: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    type?: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR" | undefined;
    name?: string | undefined;
    ttl?: number | undefined;
    priority?: number | undefined;
    proxied?: boolean | undefined;
    comment?: string | undefined;
    content?: string | undefined;
}, {
    type?: "A" | "AAAA" | "CNAME" | "MX" | "TXT" | "SRV" | "CAA" | "NS" | "PTR" | undefined;
    name?: string | undefined;
    ttl?: number | undefined;
    priority?: number | undefined;
    proxied?: boolean | undefined;
    comment?: string | undefined;
    content?: string | undefined;
}>;
export declare const createFirewallRuleSchema: z.ZodObject<{
    action: z.ZodEnum<["block", "challenge", "allow", "js_challenge", "log"]>;
    expression: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    paused: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    action: "allow" | "block" | "log" | "challenge" | "js_challenge";
    expression: string;
    description?: string | undefined;
    paused?: boolean | undefined;
}, {
    action: "allow" | "block" | "log" | "challenge" | "js_challenge";
    expression: string;
    description?: string | undefined;
    paused?: boolean | undefined;
}>;
export declare const updateFirewallRuleSchema: z.ZodObject<{
    action: z.ZodOptional<z.ZodEnum<["block", "challenge", "allow", "js_challenge", "log"]>>;
    expression: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    paused: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    paused?: boolean | undefined;
    action?: "allow" | "block" | "log" | "challenge" | "js_challenge" | undefined;
    expression?: string | undefined;
}, {
    description?: string | undefined;
    paused?: boolean | undefined;
    action?: "allow" | "block" | "log" | "challenge" | "js_challenge" | undefined;
    expression?: string | undefined;
}>;
export declare const createAccessRuleSchema: z.ZodObject<{
    mode: z.ZodEnum<["block", "challenge", "whitelist", "js_challenge"]>;
    target: z.ZodEnum<["ip", "ip_range", "country", "asn"]>;
    value: z.ZodString;
    notes: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    value: string;
    target: "ip" | "ip_range" | "country" | "asn";
    mode: "block" | "whitelist" | "challenge" | "js_challenge";
    notes?: string | undefined;
}, {
    value: string;
    target: "ip" | "ip_range" | "country" | "asn";
    mode: "block" | "whitelist" | "challenge" | "js_challenge";
    notes?: string | undefined;
}>;
export declare const createRedirectRuleSchema: z.ZodObject<{
    sourcePattern: z.ZodString;
    destinationUrl: z.ZodString;
    redirectType: z.ZodDefault<z.ZodEnum<["301", "302"]>>;
}, "strip", z.ZodTypeAny, {
    sourcePattern: string;
    destinationUrl: string;
    redirectType: "301" | "302";
}, {
    sourcePattern: string;
    destinationUrl: string;
    redirectType?: "301" | "302" | undefined;
}>;
export declare const updateRedirectRuleSchema: z.ZodObject<{
    sourcePattern: z.ZodOptional<z.ZodString>;
    destinationUrl: z.ZodOptional<z.ZodString>;
    redirectType: z.ZodOptional<z.ZodEnum<["301", "302"]>>;
    isActive: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    isActive?: boolean | undefined;
    sourcePattern?: string | undefined;
    destinationUrl?: string | undefined;
    redirectType?: "301" | "302" | undefined;
}, {
    isActive?: boolean | undefined;
    sourcePattern?: string | undefined;
    destinationUrl?: string | undefined;
    redirectType?: "301" | "302" | undefined;
}>;
export declare const purgeCacheSchema: z.ZodObject<{
    purgeEverything: z.ZodOptional<z.ZodBoolean>;
    files: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    tags?: string[] | undefined;
    purgeEverything?: boolean | undefined;
    files?: string[] | undefined;
}, {
    tags?: string[] | undefined;
    purgeEverything?: boolean | undefined;
    files?: string[] | undefined;
}>;
export declare const applyMailPresetSchema: z.ZodObject<{
    provider: z.ZodEnum<["google", "microsoft", "zoho", "custom"]>;
    customRecords: z.ZodOptional<z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        name: z.ZodString;
        content: z.ZodString;
        priority: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        type: string;
        name: string;
        content: string;
        priority?: number | undefined;
    }, {
        type: string;
        name: string;
        content: string;
        priority?: number | undefined;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    provider: "custom" | "google" | "microsoft" | "zoho";
    customRecords?: {
        type: string;
        name: string;
        content: string;
        priority?: number | undefined;
    }[] | undefined;
}, {
    provider: "custom" | "google" | "microsoft" | "zoho";
    customRecords?: {
        type: string;
        name: string;
        content: string;
        priority?: number | undefined;
    }[] | undefined;
}>;
export declare const verifyDomainSchema: z.ZodObject<{
    domainId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    domainId?: string | undefined;
}, {
    domainId?: string | undefined;
}>;
//# sourceMappingURL=cloudflare.schema.d.ts.map