export {};
//# sourceMappingURL=ftp.service.test.d.ts.map