export declare class CronService {
    listJobs(_orgId?: string): Promise<{
        status: "error" | "active" | "paused";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        siteId: string | null;
        command: string;
        schedule: string;
        user: string | null;
        workingDir: string | null;
        lastRunAt: Date | null;
        lastExitCode: number | null;
        nextRunAt: Date | null;
    }[]>;
    getJob(jobId: string): Promise<{
        status: "error" | "active" | "paused";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        siteId: string | null;
        command: string;
        schedule: string;
        user: string | null;
        workingDir: string | null;
        lastRunAt: Date | null;
        lastExitCode: number | null;
        nextRunAt: Date | null;
    }>;
    createJob(data: {
        command: string;
        schedule: string;
        siteId?: string;
        name?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        command: string;
        schedule: string;
        user: string;
    }>;
    updateJob(jobId: string, data: {
        schedule?: string;
        command?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        schedule: string;
        command: string;
    }>;
    deleteJob(jobId: string, userId?: string, ipAddress?: string): Promise<void>;
    toggleJob(jobId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        status: string;
    }>;
    runJob(jobId: string, userId?: string, ipAddress?: string): Promise<{
        exitCode: number;
        stdout: string;
        stderr: string;
    }>;
    getJobHistory(jobId: string, limit?: number): Promise<{
        id: string;
        jobId: string;
        startTime: string;
        endTime: string | null;
        exitCode: number | null;
        output: string | null;
        error: string | null;
    }[]>;
    listBySite(siteId: string): Promise<{
        status: "error" | "active" | "paused";
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        siteId: string | null;
        command: string;
        schedule: string;
        user: string | null;
        workingDir: string | null;
        lastRunAt: Date | null;
        lastExitCode: number | null;
        nextRunAt: Date | null;
    }[]>;
}
export declare const cronService: CronService;
//# sourceMappingURL=cron.service.d.ts.map