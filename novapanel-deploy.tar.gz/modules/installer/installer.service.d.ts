interface InstalledAppRecord {
    id: string;
    appId: string;
    appName: string;
    siteId: string | null;
    domainId: string | null;
    domain: string | null;
    installPath: string | null;
    status: string;
    progress: number | null;
    adminEmail: string | null;
    adminPassword: string | null;
    adminUrl: string | null;
    databaseHost: string | null;
    databaseName: string | null;
    databaseUser: string | null;
    databasePassword: string | null;
    installedAt: string | null;
    updatedAt: string | null;
    createdAt: string;
}
export declare class InstallerService {
    getAvailableApps(): Promise<{
        id: string;
        name: string;
        description: string;
        category: string;
        phpVersion?: string;
        requirements: string[];
        installCommand: string;
        installPath: string;
        configFiles: string[];
        adminPath?: string;
        adminUrlPattern?: string;
        needsDatabase?: boolean;
    }[]>;
    getApp(appId: string): Promise<{
        id: string;
        name: string;
        description: string;
        category: string;
        phpVersion?: string;
        requirements: string[];
        installCommand: string;
        installPath: string;
        configFiles: string[];
        adminPath?: string;
        adminUrlPattern?: string;
        needsDatabase?: boolean;
    } | null>;
    installApp(appId: string, siteId: string, domainId: string, path: string, adminEmail: string, adminPassword: string, _userId?: string, _ipAddress?: string): Promise<InstalledAppRecord>;
    getInstalledApps(siteId?: string): Promise<never[]>;
    getInstalledApp(installId: string): Promise<null>;
    uninstallApp(_installId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    updateApp(_installId: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getInstallLogs(_installId: string, _limit?: number): Promise<never[]>;
    getAppConfigs(_installId: string): Promise<never[]>;
    setAppConfig(_installId: string, _configKey: string, _configValue: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    deleteAppConfig(_installId: string, _configKey: string, _userId?: string, _ipAddress?: string): Promise<{
        success: boolean;
    }>;
    checkPath(_path: string): Promise<{
        exists: boolean;
        isEmpty: boolean;
        files: never[];
    }>;
    getPostInstallChecklist(_installId: string): Promise<{
        appInstalled: boolean;
        databaseConfigured: boolean;
        adminUrl: null;
        sslConfigured: boolean;
        backupsConfigured: boolean;
    }>;
}
export declare const installerService: InstallerService;
export {};
//# sourceMappingURL=installer.service.d.ts.map