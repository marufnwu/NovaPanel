export declare class MailService {
    enableMail(domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        domain: string;
    }>;
    disableMail(domainId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getMailDomains(domainId: string): Promise<{
        id: string;
        name: string;
        status: "active" | "suspended" | "pending";
    }[]>;
    createMailbox(domainId: string, data: {
        username: string;
        password: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        domainId: string;
        password: string | null;
        quota: number | null;
        aliases: unknown;
        forwards: unknown;
    }>;
    listMailboxes(domainId: string): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        domainId: string;
        password: string | null;
        quota: number | null;
        aliases: unknown;
        forwards: unknown;
    }[]>;
    deleteMailbox(mailboxId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    createAlias(domainId: string, data: {
        source: string;
        destination: string;
    }, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    listAliases(domainId: string): Promise<{
        mailboxId: string;
        source: string;
        destination: string;
    }[]>;
    updateMailbox(mailboxId: string, data: {
        password?: string;
        quotaMb?: number;
        isActive?: boolean;
        isSuspended?: boolean;
        autoresponder?: boolean;
        autoresponderSubject?: string;
        autoresponderMessage?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        domainId: string;
        password: string | null;
        quota: number | null;
        aliases: unknown;
        forwards: unknown;
    }>;
    deleteAlias(domainId: string, aliasId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    createForward(domainId: string, data: {
        source: string;
        destinations: string[];
    }, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    listForwards(domainId: string): Promise<{
        mailboxId: string;
        source: string;
        destinations: string[];
    }[]>;
    deleteForward(domainId: string, forwardId: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    getStats(domainId: string): Promise<{
        mailboxCount: number;
        aliasCount: number;
        forwardCount: number;
    }>;
}
export declare const mailService: MailService;
//# sourceMappingURL=mail.service.d.ts.map