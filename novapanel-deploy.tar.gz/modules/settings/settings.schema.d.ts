import { z } from 'zod';
export declare const updateIdentitySchema: z.ZodObject<{
    hostname: z.ZodOptional<z.ZodString>;
    domain: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    domain?: string | undefined;
    hostname?: string | undefined;
}, {
    domain?: string | undefined;
    hostname?: string | undefined;
}>;
export declare const updateTimezoneSchema: z.ZodObject<{
    timezone: z.ZodString;
}, "strip", z.ZodTypeAny, {
    timezone: string;
}, {
    timezone: string;
}>;
export declare const updateBackupSettingsSchema: z.ZodObject<{
    backupPath: z.ZodOptional<z.ZodString>;
    retentionDays: z.ZodOptional<z.ZodNumber>;
    schedule: z.ZodOptional<z.ZodString>;
    enabled: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    enabled?: boolean | undefined;
    schedule?: string | undefined;
    retentionDays?: number | undefined;
    backupPath?: string | undefined;
}, {
    enabled?: boolean | undefined;
    schedule?: string | undefined;
    retentionDays?: number | undefined;
    backupPath?: string | undefined;
}>;
export declare const updateSshPortSchema: z.ZodObject<{
    port: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    port: number;
}, {
    port: number;
}>;
export declare const updatePanelSettingsSchema: z.ZodObject<{
    panelUrl: z.ZodOptional<z.ZodString>;
    adminEmail: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    panelUrl?: string | undefined;
    adminEmail?: string | undefined;
}, {
    panelUrl?: string | undefined;
    adminEmail?: string | undefined;
}>;
export declare const updateNameserversSchema: z.ZodObject<{
    ns1: z.ZodOptional<z.ZodString>;
    ns2: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    ns1?: string | undefined;
    ns2?: string | undefined;
}, {
    ns1?: string | undefined;
    ns2?: string | undefined;
}>;
export declare const updateSessionSchema: z.ZodObject<{
    timeout: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    timeout?: number | undefined;
}, {
    timeout?: number | undefined;
}>;
export declare const updatePasswordPolicySchema: z.ZodObject<{
    minLength: z.ZodOptional<z.ZodNumber>;
    requireUppercase: z.ZodOptional<z.ZodBoolean>;
    requireLowercase: z.ZodOptional<z.ZodBoolean>;
    requireNumbers: z.ZodOptional<z.ZodBoolean>;
    requireSpecialChars: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    minLength?: number | undefined;
    requireUppercase?: boolean | undefined;
    requireLowercase?: boolean | undefined;
    requireNumbers?: boolean | undefined;
    requireSpecialChars?: boolean | undefined;
}, {
    minLength?: number | undefined;
    requireUppercase?: boolean | undefined;
    requireLowercase?: boolean | undefined;
    requireNumbers?: boolean | undefined;
    requireSpecialChars?: boolean | undefined;
}>;
export declare const updateSshSettingsSchema: z.ZodObject<{
    port: z.ZodOptional<z.ZodNumber>;
    permitRootLogin: z.ZodOptional<z.ZodBoolean>;
    passwordAuth: z.ZodOptional<z.ZodBoolean>;
    pubkeyAuth: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    port?: number | undefined;
    permitRootLogin?: boolean | undefined;
    passwordAuth?: boolean | undefined;
    pubkeyAuth?: boolean | undefined;
}, {
    port?: number | undefined;
    permitRootLogin?: boolean | undefined;
    passwordAuth?: boolean | undefined;
    pubkeyAuth?: boolean | undefined;
}>;
export declare const updatePanelPortSchema: z.ZodObject<{
    port: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    port: number;
}, {
    port: number;
}>;
export declare const updateDefaultWebserverSchema: z.ZodObject<{
    mode: z.ZodEnum<["nginx", "apache", "nginx+apache"]>;
}, "strip", z.ZodTypeAny, {
    mode: "nginx" | "apache" | "nginx+apache";
}, {
    mode: "nginx" | "apache" | "nginx+apache";
}>;
export declare const updateSslEmailSchema: z.ZodObject<{
    email: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
}, {
    email: string;
}>;
export declare const updateMaintenanceSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    enabled: boolean;
}, {
    enabled: boolean;
}>;
export declare const importConfigSchema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
export declare const updateDataRetentionSchema: z.ZodObject<{
    auditLogRetentionDays: z.ZodOptional<z.ZodNumber>;
    logRetentionDays: z.ZodOptional<z.ZodNumber>;
    backupRetentionCount: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    auditLogRetentionDays?: number | undefined;
    logRetentionDays?: number | undefined;
    backupRetentionCount?: number | undefined;
}, {
    auditLogRetentionDays?: number | undefined;
    logRetentionDays?: number | undefined;
    backupRetentionCount?: number | undefined;
}>;
export declare const updatePhpVersionSchema: z.ZodObject<{
    version: z.ZodEnum<["default", "php8.1", "php8.2", "php8.3", "php8.4"]>;
}, "strip", z.ZodTypeAny, {
    version: "default" | "php8.1" | "php8.2" | "php8.3" | "php8.4";
}, {
    version: "default" | "php8.1" | "php8.2" | "php8.3" | "php8.4";
}>;
export declare const updateSmtpSchema: z.ZodObject<{
    host: z.ZodString;
    port: z.ZodNumber;
    username: z.ZodString;
    password: z.ZodOptional<z.ZodString>;
    fromAddress: z.ZodUnion<[z.ZodString, z.ZodString]>;
    encryption: z.ZodEnum<["none", "tls", "ssl"]>;
}, "strip", z.ZodTypeAny, {
    username: string;
    port: number;
    host: string;
    fromAddress: string;
    encryption: "none" | "tls" | "ssl";
    password?: string | undefined;
}, {
    username: string;
    port: number;
    host: string;
    fromAddress: string;
    encryption: "none" | "tls" | "ssl";
    password?: string | undefined;
}>;
//# sourceMappingURL=settings.schema.d.ts.map