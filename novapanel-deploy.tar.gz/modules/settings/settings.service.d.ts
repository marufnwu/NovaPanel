export declare class SettingsService {
    /**
     * Get server identity settings
     */
    getServerIdentity(): Promise<{
        hostname: string;
        domain: string;
    }>;
    /**
     * Update server identity — persists to settings file
     */
    updateServerIdentity(data: {
        hostname?: string;
        domain?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        hostname: string;
        domain: string;
    }>;
    /**
     * Get timezone settings
     */
    getTimezone(): Promise<{
        timezone: string;
    }>;
    /**
     * Update timezone
     */
    setTimezone(timezone: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get available timezones
     */
    getAvailableTimezones(): Promise<string[]>;
    /**
     * Get backup settings
     */
    getBackupSettings(): Promise<{
        backupPath: string;
        retentionDays: number;
        schedule: string;
        enabled: boolean;
    }>;
    /**
     * Update backup settings
     */
    updateBackupSettings(data: {
        backupPath?: string;
        retentionDays?: number;
        schedule?: string;
        enabled?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    /**
     * Get security settings
     */
    getSecuritySettings(): Promise<{
        sshPort: number;
        sshPasswordAuth: boolean;
        sshPermitRootLogin: boolean;
        fail2banEnabled: boolean;
        ufwEnabled: boolean;
    }>;
    /**
     * Update SSH port
     */
    updateSshPort(port: number, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        message?: string;
    }>;
    /**
     * Get system update info
     */
    getSystemUpdates(): Promise<{
        updatesAvailable: number;
        lastCheck: string;
        autoUpdate: boolean;
    }>;
    /**
     * Check for system updates
     */
    checkForUpdates(): Promise<{
        updatesAvailable: number;
    }>;
    getPanelSettings(): Promise<{
        panelUrl: string;
        adminEmail: string;
    }>;
    updatePanelSettings(data: {
        panelUrl?: string;
        adminEmail?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        panelUrl: string;
        adminEmail: string;
    }>;
    getNameserverSettings(): Promise<{
        ns1: string;
        ns2: string;
    }>;
    updateNameserverSettings(data: {
        ns1?: string;
        ns2?: string;
    }, userId?: string, ipAddress?: string): Promise<{
        ns1: string;
        ns2: string;
    }>;
    getSessionSettings(): Promise<{
        timeout: number;
    }>;
    updateSessionSettings(data: {
        timeout?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        timeout: number;
    }>;
    getPasswordPolicy(): Promise<{
        minLength: number;
        requireUppercase: boolean;
        requireLowercase: boolean;
        requireNumbers: boolean;
        requireSpecialChars: boolean;
    }>;
    updatePasswordPolicy(data: {
        minLength?: number;
        requireUppercase?: boolean;
        requireLowercase?: boolean;
        requireNumbers?: boolean;
        requireSpecialChars?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        minLength: number;
        requireUppercase: boolean;
        requireLowercase: boolean;
        requireNumbers: boolean;
        requireSpecialChars: boolean;
    }>;
    getSystemInfo(): Promise<{
        os: string;
        kernel: string;
        arch: string;
        hostname: string;
        cpu: {
            model: string;
            cores: number;
        };
        ram: {
            total: number;
            used: number;
            available: number;
        };
        disk: {
            total: number;
            used: number;
            available: number;
        };
        uptime: number;
        softwareVersions: Record<string, string>;
    }>;
    getPhpVersion(): Promise<{
        version: string;
    }>;
    updatePhpVersion(version: string, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        version: string;
    }>;
    getSmtpConfig(): Promise<{
        host: string;
        port: number;
        username: string;
        fromAddress: string;
        encryption: 'none' | 'tls' | 'ssl';
    }>;
    updateSmtpConfig(data: {
        host: string;
        port: number;
        username: string;
        password?: string;
        fromAddress: string;
        encryption: 'none' | 'tls' | 'ssl';
    }, userId?: string, ipAddress?: string): Promise<{
        success: boolean;
    }>;
    sendTestEmail(userId?: string, ipAddress?: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getSshSettings(): Promise<{
        port: number;
        permitRootLogin: boolean;
        passwordAuth: boolean;
        pubkeyAuth: boolean;
    }>;
    updateSshSettings(data: {
        port?: number;
        permitRootLogin?: boolean;
        passwordAuth?: boolean;
        pubkeyAuth?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        port: number;
        permitRootLogin: boolean;
        passwordAuth: boolean;
        pubkeyAuth: boolean;
    } | {
        warning: string;
        port: number;
        permitRootLogin: boolean;
        passwordAuth: boolean;
        pubkeyAuth: boolean;
    }>;
    getPanelPort(): Promise<{
        port: number;
    }>;
    updatePanelPort(port: number): Promise<{
        port: number;
    }>;
    getDefaultWebServer(): Promise<{
        mode: string;
    }>;
    updateDefaultWebServer(mode: string): Promise<{
        mode: string;
    }>;
    getSslEmail(): Promise<{
        email: string;
    }>;
    updateSslEmail(email: string): Promise<{
        email: string;
    }>;
    getCloudflareConfig(): Promise<{
        apiToken: string;
        accountId: string;
    } | null>;
    setCloudflareConfig(data: {
        apiToken: string;
        accountId: string;
    }, userId?: string, ipAddress?: string): Promise<{
        apiToken: string;
        accountId: string;
    }>;
    rebootServer(): Promise<{
        success: boolean;
        message: string;
    }>;
    shutdownServer(): Promise<{
        success: boolean;
        message: string;
    }>;
    getMaintenanceMode(): Promise<{
        enabled: boolean;
    }>;
    updateMaintenanceMode(enabled: boolean, userId?: string, ipAddress?: string): Promise<{
        enabled: boolean;
    }>;
    exportConfig(): Promise<Record<string, unknown>>;
    importConfig(config: Record<string, unknown>): Promise<{
        success: boolean;
    }>;
    getDataRetention(): Promise<{
        auditLogRetentionDays: number;
        logRetentionDays: number;
        backupRetentionCount: number;
    }>;
    updateDataRetention(data: {
        auditLogRetentionDays?: number;
        logRetentionDays?: number;
        backupRetentionCount?: number;
    }, userId?: string, ipAddress?: string): Promise<{
        auditLogRetentionDays: number;
        logRetentionDays: number;
        backupRetentionCount: number;
    }>;
}
export declare const settingsService: SettingsService;
//# sourceMappingURL=settings.service.d.ts.map