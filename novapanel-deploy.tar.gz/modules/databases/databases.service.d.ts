import { databases } from '../../db/schema/index.js';
export declare class DatabasesService {
    list(orgId?: string): Promise<{
        items: typeof databases.$inferSelect[];
        total: number;
    }>;
    get(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    create(data: {
        orgId: string;
        name: string;
        type: 'postgresql' | 'mysql' | 'mariadb' | 'mongodb' | 'redis' | 'sqlite';
        version?: string;
        host?: string;
        port?: number;
        databaseName?: string;
        username?: string;
        password?: string;
        backupsEnabled?: boolean;
        backupSchedule?: string;
        publicAccess?: boolean;
    }): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    update(id: string, data: Partial<{
        name: string;
        backupsEnabled: boolean;
        backupSchedule: string;
        publicAccess: boolean;
        status: 'running' | 'stopped' | 'error';
    }>): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    delete(id: string): Promise<{
        success: boolean;
    }>;
    start(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    stop(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    restart(id: string): Promise<{
        type: "sqlite" | "mysql" | "postgresql" | "mariadb" | "mongodb" | "redis";
        status: "error" | "stopped" | "running" | "creating";
        id: string;
        username: string | null;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        port: number | null;
        version: string | null;
        host: string | null;
        databaseName: string | null;
        password: string | null;
        containerId: string | null;
        volumeId: string | null;
        backupsEnabled: boolean;
        backupSchedule: string | null;
        publicAccess: boolean;
    }>;
    listUsers(databaseId: string): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }[]>;
    createUser(data: {
        databaseId: string;
        username: string;
        password?: string;
        privileges?: string[];
    }): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }>;
    deleteUser(id: string): Promise<{
        success: boolean;
    }>;
    updateUserPrivileges(id: string, privileges: string[]): Promise<{
        id: string;
        username: string;
        createdAt: Date;
        password: string | null;
        databaseId: string;
        privileges: unknown;
    }>;
    /**
     * Get database service based on database type
     */
    private getDbService;
    /**
     * Change password for database user
     */
    changePassword(databaseId: string, password: string): Promise<{
        success: boolean;
    }>;
    /**
     * Change password for a specific database user
     */
    changeUserPassword(databaseId: string, userId: string, password: string): Promise<{
        success: boolean;
    }>;
    /**
     * Export database to SQL
     */
    exportDatabase(databaseId: string, outputPath?: string): Promise<{
        success: boolean;
        data: string;
    }>;
    /**
     * Import SQL into database
     */
    importDatabase(databaseId: string, sql: string): Promise<{
        success: boolean;
    }>;
    /**
     * Repair database tables
     */
    repairDatabase(databaseId: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Optimize database tables
     */
    optimizeDatabase(databaseId: string): Promise<{
        success: boolean;
        output: string;
    }>;
    /**
     * Clone/duplicate database
     */
    cloneDatabase(databaseId: string, targetName: string): Promise<{
        success: boolean;
    }>;
    /**
     * Run SQL query (with safety restrictions)
     * [P3-3] Security note: LIMIT is applied in the query itself to prevent fetching
     * excessive rows from the database when only a subset is needed.
     */
    runQuery(databaseId: string, sql: string, limit?: number): Promise<{
        columns: string[];
        rows: Record<string, unknown>[];
        rowCount: number;
        totalRows: number;
        truncated: boolean;
    }>;
}
export declare const databasesService: DatabasesService;
//# sourceMappingURL=databases.service.d.ts.map