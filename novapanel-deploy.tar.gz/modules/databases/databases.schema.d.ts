import { z } from 'zod';
export declare const createDbSchema: z.ZodEffects<z.ZodEffects<z.ZodObject<{
    domainId: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    engine: z.ZodDefault<z.ZodEnum<["mariadb", "postgresql"]>>;
    charset: z.ZodOptional<z.ZodString>;
    /** When true, also create a database user with access to this database */
    createUser: z.ZodDefault<z.ZodBoolean>;
    /** Username for the auto-created user (required if createUser is true) */
    username: z.ZodOptional<z.ZodString>;
    /** Password for the auto-created user (required if createUser is true) */
    password: z.ZodOptional<z.ZodString>;
    /** Host for the auto-created user */
    host: z.ZodDefault<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name: string;
    host: string;
    engine: "postgresql" | "mariadb";
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    password?: string | undefined;
    charset?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    engine?: "postgresql" | "mariadb" | undefined;
    charset?: string | undefined;
    createUser?: boolean | undefined;
}>, {
    name: string;
    host: string;
    engine: "postgresql" | "mariadb";
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    password?: string | undefined;
    charset?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    engine?: "postgresql" | "mariadb" | undefined;
    charset?: string | undefined;
    createUser?: boolean | undefined;
}>, {
    name: string;
    host: string;
    engine: "postgresql" | "mariadb";
    createUser: boolean;
    username?: string | undefined;
    domainId?: string | undefined;
    password?: string | undefined;
    charset?: string | undefined;
}, {
    name: string;
    username?: string | undefined;
    domainId?: string | undefined;
    host?: string | undefined;
    password?: string | undefined;
    engine?: "postgresql" | "mariadb" | undefined;
    charset?: string | undefined;
    createUser?: boolean | undefined;
}>;
export declare const createUserSchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    host: z.ZodDefault<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    username: string;
    host: string;
    password: string;
}, {
    username: string;
    password: string;
    host?: string | undefined;
}>;
export declare const importDbSchema: z.ZodObject<{
    sql: z.ZodString;
}, "strip", z.ZodTypeAny, {
    sql: string;
}, {
    sql: string;
}>;
export declare const changePasswordSchema: z.ZodObject<{
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    password: string;
}, {
    password: string;
}>;
export declare const exportSchema: z.ZodObject<{
    outputPath: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    outputPath?: string | undefined;
}, {
    outputPath?: string | undefined;
}>;
export declare const repairSchema: z.ZodObject<{}, "strip", z.ZodTypeAny, {}, {}>;
export declare const optimizeSchema: z.ZodObject<{}, "strip", z.ZodTypeAny, {}, {}>;
export declare const cloneSchema: z.ZodObject<{
    targetName: z.ZodString;
}, "strip", z.ZodTypeAny, {
    targetName: string;
}, {
    targetName: string;
}>;
export declare const querySchema: z.ZodObject<{
    sql: z.ZodString;
    limit: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
}, "strip", z.ZodTypeAny, {
    limit: number;
    sql: string;
}, {
    sql: string;
    limit?: number | undefined;
}>;
//# sourceMappingURL=databases.schema.d.ts.map