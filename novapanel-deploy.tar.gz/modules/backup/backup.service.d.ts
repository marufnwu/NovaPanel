export declare class BackupService {
    /**
     * List all backups
     */
    listBackups(): Promise<{
        path: string | null;
        type: "full" | "incremental" | "snapshot";
        status: "pending" | "success" | "failed" | "running";
        id: string;
        createdAt: Date;
        orgId: string | null;
        completedAt: Date | null;
        size: number | null;
        resourceType: "config" | "site" | "database" | "container";
        resourceId: string | null;
        storageBackend: "local" | "s3" | "b2" | "wasabi";
        storagePath: string | null;
        retentionDays: number;
    }[]>;
    /**
     * Get a single backup record by ID
     */
    getBackup(backupId: string): Promise<{
        path: string | null;
        type: "full" | "incremental" | "snapshot";
        status: "pending" | "success" | "failed" | "running";
        id: string;
        createdAt: Date;
        orgId: string | null;
        completedAt: Date | null;
        size: number | null;
        resourceType: "config" | "site" | "database" | "container";
        resourceId: string | null;
        storageBackend: "local" | "s3" | "b2" | "wasabi";
        storagePath: string | null;
        retentionDays: number;
    }>;
    /**
     * Create a backup
     */
    createBackup(data: {
        resourceType: 'site' | 'database' | 'container' | 'config';
        type?: 'full' | 'incremental' | 'snapshot';
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        filename: string;
        sizeBytes: number;
    }>;
    /**
     * Restore a backup
     */
    restoreBackup(backupId: string, options?: {
        files?: boolean;
        databases?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        restored: boolean;
    }>;
    /**
     * Delete a backup
     */
    deleteBackup(backupId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * List backup schedules
     */
    listSchedules(): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        lastRunAt: Date | null;
        nextRunAt: Date | null;
        resourceType: string;
        resourceId: string | null;
        storageBackend: string;
        retentionDays: number;
        cronExpression: string;
    }[]>;
    /**
     * Create a backup schedule
     */
    createSchedule(data: {
        name: string;
        resourceType: string;
        resourceId?: string;
        cronExpression: string;
        retentionDays: number;
        storageBackend: string;
        enabled?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        cronExpression: string;
        nextRunAt: Date;
    }>;
    /**
     * Toggle a backup schedule
     */
    toggleSchedule(scheduleId: string, userId?: string, ipAddress?: string): Promise<{
        id: string;
        enabled: boolean;
    }>;
    /**
     * Delete a backup schedule
     */
    deleteSchedule(scheduleId: string, userId?: string, ipAddress?: string): Promise<void>;
    /**
     * Update a backup schedule
     */
    updateSchedule(scheduleId: string, data: {
        name?: string;
        cronExpression?: string;
        retentionDays?: number;
        storageBackend?: string;
        enabled?: boolean;
    }, userId?: string, ipAddress?: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        lastRunAt: Date | null;
        nextRunAt: Date | null;
        resourceType: string;
        resourceId: string | null;
        storageBackend: string;
        retentionDays: number;
        cronExpression: string;
    }>;
    /**
     * Get a backup schedule by ID
     */
    getSchedule(scheduleId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date | null;
        orgId: string | null;
        enabled: boolean;
        lastRunAt: Date | null;
        nextRunAt: Date | null;
        resourceType: string;
        resourceId: string | null;
        storageBackend: string;
        retentionDays: number;
        cronExpression: string;
    }>;
    /**
     * Run a backup immediately for a schedule
     */
    runBackupNow(scheduleId: string, userId?: string, ipAddress?: string): Promise<{
        backupId: string;
        nextRunAt: Date;
    }>;
    /**
     * Prepare a backup file for download.
     */
    prepareDownload(backupId: string): Promise<{
        tmpPath: string;
        filename: string;
        sizeBytes: number;
    }>;
    /**
     * Get download URL/path for a backup
     */
    getDownloadUrl(backupId: string): Promise<string>;
    /**
     * Verify a backup's integrity
     */
    verifyBackup(backupId: string): Promise<{
        valid: boolean;
        checksum: string;
        sizeBytes: number;
        checkedAt: string;
        errors?: string[];
    }>;
    /**
     * Execute all backup schedules that are due
     */
    executeDueBackups(): Promise<void>;
    /**
     * Calculate the next run time from a cron expression
     */
    private calculateNextRun;
    /**
     * Enforce retention policy for a backup schedule
     */
    private enforceRetention;
    /**
     * List backups by resourceId
     */
    listByResource(resourceType: string, resourceId: string): Promise<{
        path: string | null;
        type: "full" | "incremental" | "snapshot";
        status: "pending" | "success" | "failed" | "running";
        id: string;
        createdAt: Date;
        orgId: string | null;
        completedAt: Date | null;
        size: number | null;
        resourceType: "config" | "site" | "database" | "container";
        resourceId: string | null;
        storageBackend: "local" | "s3" | "b2" | "wasabi";
        storagePath: string | null;
        retentionDays: number;
    }[]>;
}
export declare const backupService: BackupService;
//# sourceMappingURL=backup.service.d.ts.map