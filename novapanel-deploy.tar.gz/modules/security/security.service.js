import { db } from '../../db/index.js';
import { wafRules, ipAllowlists } from '../../db/schema/security.js';
import { eq } from 'drizzle-orm';
import { nanoid } from 'nanoid';
import { nginxService } from '../../services/nginx.service.js';
import { logger } from '../../config/logger.js';
export class SecurityService {
    async listWafRules(orgId) {
        return db.select().from(wafRules).where(eq(wafRules.orgId, orgId)).orderBy(wafRules.priority);
    }
    async createWafRule(orgId, data) {
        const rule = {
            id: nanoid(),
            orgId,
            name: data.name,
            type: data.type,
            enabled: data.enabled ?? true,
            priority: data.priority ?? 100,
            config: data.config ?? {},
            createdAt: new Date(),
        };
        await db.insert(wafRules).values(rule);
        const [created] = await db.select().from(wafRules).where(eq(wafRules.id, rule.id)).limit(1);
        await nginxService.applySecurityRules(orgId).catch((err) => logger.warn({ err, orgId }, 'Failed to apply nginx security rules'));
        return created;
    }
    async updateWafRule(id, orgId, data) {
        await db.update(wafRules).set({ ...data, updatedAt: new Date() }).where(eq(wafRules.id, id));
        const [updated] = await db.select().from(wafRules).where(eq(wafRules.id, id)).limit(1);
        if (!updated)
            throw new Error('WAF rule not found');
        await nginxService.applySecurityRules(orgId).catch(() => { });
        return updated;
    }
    async deleteWafRule(id, orgId) {
        await db.delete(wafRules).where(eq(wafRules.id, id));
        await nginxService.applySecurityRules(orgId).catch(() => { });
    }
    async listIpAllowlists(orgId) {
        return db.select().from(ipAllowlists).where(eq(ipAllowlists.orgId, orgId)).orderBy(ipAllowlists.createdAt);
    }
    async createIpAllowlist(orgId, data) {
        const allowlist = {
            id: nanoid(),
            orgId,
            name: data.name,
            ips: data.ips ?? [],
            type: data.type,
            createdAt: new Date(),
        };
        await db.insert(ipAllowlists).values(allowlist);
        const [created] = await db.select().from(ipAllowlists).where(eq(ipAllowlists.id, allowlist.id)).limit(1);
        await nginxService.applySecurityRules(orgId).catch((err) => logger.warn({ err, orgId }, 'Failed to apply nginx security rules'));
        return created;
    }
    async updateIpAllowlist(id, orgId, data) {
        await db.update(ipAllowlists).set({ ...data, updatedAt: new Date() }).where(eq(ipAllowlists.id, id));
        const [updated] = await db.select().from(ipAllowlists).where(eq(ipAllowlists.id, id)).limit(1);
        if (!updated)
            throw new Error('IP allowlist not found');
        await nginxService.applySecurityRules(orgId).catch(() => { });
        return updated;
    }
    async deleteIpAllowlist(id, orgId) {
        await db.delete(ipAllowlists).where(eq(ipAllowlists.id, id));
        await nginxService.applySecurityRules(orgId).catch(() => { });
    }
}
export const securityService = new SecurityService();
//# sourceMappingURL=security.service.js.map