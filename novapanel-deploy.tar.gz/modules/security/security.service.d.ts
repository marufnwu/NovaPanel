import { type WafRule, type NewWafRule, type IpAllowlist, type NewIpAllowlist } from '../../db/schema/security.js';
export declare class SecurityService {
    listWafRules(orgId: string): Promise<WafRule[]>;
    createWafRule(orgId: string, data: Omit<NewWafRule, 'id' | 'orgId' | 'createdAt'>): Promise<WafRule>;
    updateWafRule(id: string, orgId: string, data: Partial<Pick<WafRule, 'name' | 'type' | 'enabled' | 'priority' | 'config'>>): Promise<WafRule>;
    deleteWafRule(id: string, orgId: string): Promise<void>;
    listIpAllowlists(orgId: string): Promise<IpAllowlist[]>;
    createIpAllowlist(orgId: string, data: Omit<NewIpAllowlist, 'id' | 'orgId' | 'createdAt'>): Promise<IpAllowlist>;
    updateIpAllowlist(id: string, orgId: string, data: Partial<Pick<IpAllowlist, 'name' | 'ips' | 'type'>>): Promise<IpAllowlist>;
    deleteIpAllowlist(id: string, orgId: string): Promise<void>;
}
export declare const securityService: SecurityService;
//# sourceMappingURL=security.service.d.ts.map