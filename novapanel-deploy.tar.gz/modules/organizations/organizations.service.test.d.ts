export {};
//# sourceMappingURL=organizations.service.test.d.ts.map