export declare class CertbotService {
    /**
     * Issue a Let's Encrypt certificate using certbot
     */
    issueCertificate(domain: string, email: string, webroot?: string): Promise<{
        certPath: string;
        keyPath: string;
        chainPath: string;
    }>;
    /**
     * Check if the Cloudflare DNS plugin for certbot is installed
     */
    hasCloudflareDnsPlugin(): Promise<boolean>;
    /**
     * Issue a Let's Encrypt certificate using DNS-01 challenge via Cloudflare
     * Requires the python3-certbot-dns-cloudflare package to be installed.
     *
     * @param params.domain - The primary domain for the certificate (e.g., example.com)
     * @param params.email - Email for Let's Encrypt notifications
     * @param params.wildcard - Whether to include *.domain in the certificate
     * @param params.cloudflareApiToken - Cloudflare API token with DNS edit permissions
     * @returns Certificate paths on success
     * @throws Error if certbot fails or credentials file cannot be written
     */
    issueCertificateDns01(params: {
        domain: string;
        email: string;
        wildcard: boolean;
        cloudflareApiToken: string;
    }): Promise<{
        certPath: string;
        keyPath: string;
        fullChainPath: string;
    }>;
    /**
     * Renew all certificates that are due for renewal
     */
    renewDueCertificates(): Promise<{
        renewed: string[];
        failed: string[];
    }>;
    /**
     * Renew all Let's Encrypt certificates system-wide (legacy)
     */
    renewAll(): Promise<{
        renewed: string[];
        failed: string[];
    }>;
    /**
     * Renew a single domain's certificate
     */
    renew(domain: string): Promise<boolean>;
    /**
     * Revoke and delete a certificate
     */
    deleteCertificate(domain: string): Promise<void>;
    /**
     * Get certificate expiry date from a PEM file using openssl
     */
    getCertExpiry(certPath: string): Promise<Date>;
    /**
     * Generate a self-signed certificate using openssl
     */
    generateSelfSigned(domain: string, outputDir: string, days?: number): Promise<{
        certPath: string;
        keyPath: string;
    }>;
}
export declare const certbotService: CertbotService;
//# sourceMappingURL=certbot.service.d.ts.map