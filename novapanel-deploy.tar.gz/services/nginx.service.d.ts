import type { SystemService, ServiceInfo } from './types.js';
export interface VhostContext {
    domain: string;
    documentRoot: string;
    phpVersion?: string;
    ssl?: {
        certPath: string;
        keyPath: string;
    };
    aliases?: string[];
    redirectHttpToHttps?: boolean;
    hsts?: boolean;
    upstreamPort?: number;
    orgId?: string;
    ipAllow?: string[];
    ipBlock?: string[];
}
export declare class NginxService implements SystemService {
    readonly name = "nginx";
    readonly displayName = "Nginx";
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    reload(): Promise<void>;
    status(): Promise<ServiceInfo>;
    isInstalled(): Promise<boolean>;
    testConfig(): Promise<{
        valid: boolean;
        output: string;
    }>;
    generateSiteConfig(siteId: string): Promise<void>;
    addVhost(ctx: VhostContext): Promise<void>;
    removeVhost(domain: string): Promise<void>;
    reloadNginx(): Promise<void>;
    renderVhostConfig(ctx: VhostContext): string;
    private renderVhost;
    generateWebsiteConfig(_websiteId: string): Promise<void>;
    generateSubdomainConfig(_subdomainDomainId: string): Promise<void>;
    generateSuspendedConfig(_websiteId: string): Promise<void>;
    removeWebsiteConfig(_websiteId: string): Promise<void>;
    generateSingleDomainSuspendedConfig(_domainId: string): Promise<void>;
    private renderPhpLocation;
    private resolveDocumentRoot;
    private resolvePhpVersion;
    private buildPrimaryServerBlock;
    private buildAddonServerBlock;
    private buildSubdomainServerBlock;
    private buildSuspendedBlock;
    private generateConfigHeader;
    private getSslPaths;
    private getWafRulesForProject;
    private getIpAllowlistForProject;
    applySecurityRules(orgId: string): Promise<void>;
}
export declare const nginxService: NginxService;
//# sourceMappingURL=nginx.service.d.ts.map